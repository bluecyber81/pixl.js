# Allmiibo-Dateimanager im Browser

## Dateimanager 3.58.2 · kleine Dateien sichern und Ordner fortsetzen

Unter **Dateien** kannst du einen lokalen Ordner vergleichen und die gewählten Dateien übertragen. Bei einem Bluetooth-Abbruch den Tab offen lassen, dasselbe Gerät erneut verbinden und den angehaltenen Auftrag fortsetzen. App662 überprüft geschriebene Daten durch Zurücklesen. Für eine Sicherung kann der Dateimanager kleine Dateien in einer Leseanfrage abrufen. [Dateimanager öffnen](https://bluecyber81.github.io/pixl.js/) · [Web-Downloads](https://github.com/bluecyber81/pixl.js/releases/tag/web3.58.2) · [LCD-Geräteprüfung](validation/DE3_89_LCD_READBACK.json)

## Dateimanager 3.58.1 · OLED Test 6

Unter **Update → OLED** findest du App86 für das Handy und für die Übertragung mit Chrome oder Edge am Computer. Öffne am dreitastigen OLED für die Fernbedienung **Einstellungen → Fernsteuern → bis Aus**, lass es wach und wähle im Browser **Pixl.Remote**. Dateitransfer und AmiiboLink vorher verlassen. [Dateimanager öffnen](https://bluecyber81.github.io/pixl.js/) · [OLED-Anleitung](https://bluecyber81.github.io/pixl.js/guide/index.html#oled) · [Web-Downloads](https://github.com/bluecyber81/pixl.js/releases/tag/web3.58.1)

## Dateimanager 3.58.0 · kompakte Fernbedienung und Spielordner

Unter **Fernbedienung → Allmiibo DE** zeigt die Kompaktansicht am Handy Displayfoto und Tasten gemeinsam. Im Spielkatalog lassen sich alle Suchtreffer gemeinsam markieren. Vor dem Schreiben zeigt die Vorschau neue, vorhandene und konfliktbehaftete Figuren. DE3.87 / App660 ist die LCD-Vorabversion für ST7567, PFS1, Z21 und S112 7.3.0. Die Geräteabnahme steht aus. [Dateimanager und Web-Downloads](https://github.com/bluecyber81/pixl.js/releases/tag/web3.58.0) · [LCD-Prüfpaket](https://github.com/bluecyber81/pixl.js/releases/download/de3.87-lcd-test1/Allmiibo_LCD_DE3_87_App660_Pruefpaket.zip)

## Dateimanager 3.56.0 · Displayfoto nach bestätigten Tasten

Unter **Fernbedienung → Allmiibo DE** ist **Displayfoto nach Tastendruck automatisch aktualisieren** optional und anfangs ausgeschaltet. Nach bestätigtem Links/Mitte/Rechts/Zurück wird ein Bild gelesen; schnelle Folgen werden zusammengefasst. Es gibt keine Dauerabfrage oder Wiederholung von Tasten. Trennen, Dateiübergabe und Blockierung verwerfen wartende Aufnahmen. Alte Firmware ohne Foto-Funktion wird nicht abgefragt; manuelle Fotos bleiben möglich.

Die neue **LCD-Testversion DE3.85 / App658** ist für ST7567, PFS1, Z21 und S112 7.3.0 vorgesehen. Sie erweitert den Gerätetest um Fernbedienungsstatus und einen 5-/100-PWM-Lichttest mit Wiederherstellung. Wegen der eigenen Remote-Adresse **Pixl.Remote** frisch auswählen. Bootloader und SoftDevice bleiben installiert. Ein frischer Gerätetest steht aus; frühere Bestätigungen zu App657 gelten nicht automatisch für App658. [Handy-App](https://github.com/bluecyber81/pixl.js/releases/download/de3.85-lcd-test1/Allmiibo_LCD_DE3_85_658_NUR_APP.zip) · [Prüfpaket](https://github.com/bluecyber81/pixl.js/releases/download/de3.85-lcd-test1/Allmiibo_LCD_DE3_85_App658_Pruefpaket.zip) · [Anleitung](https://bluecyber81.github.io/pixl.js/guide/index.html#lcd-de385). **DE3.81 / App654 bleibt die reguläre LCD-Firmware.**

English: File manager 3.56.0 offers opt-in screenshots after acknowledged navigation keys, with coalescing and cancellation. LCD DE3.85 / App658 adds remote diagnostics and a reversible backlight PWM test; new hardware acceptance is pending. [English instructions](https://bluecyber81.github.io/pixl.js/guide/en.html#lcd-de385).

## Dateimanager 3.55.8 · OLED direkt im Browser aktualisieren

Unter Update → OLED öffnet „OLED im Browser flashen“ das geprüfte App84-Paket. Die DFU-Seite zeigt das Zielgerät und verwendet die passende Paketliste. Der Browser lädt die signierte ZIP vom gleichen Seitenursprung und prüft Größe, Hash und App-Daten vor der Übertragung. Aktuelle Bootdaten werden zum Vergleich weitergereicht.

Die Anleitung beschreibt den Computerablauf mit Chrome oder Edge auf Deutsch und Englisch. Für ein verbundenes OLED steht der vorhandene Befehl zum Wechsel in den DFU-Modus bereit. Der reale OLED-Gerätetest bleibt offen.

## Dateimanager 3.55.7 · OLED DE3.84 / App84

App84 meldet über die Diagnose ihre OLED-Buildkennung und eine gegebenenfalls erhaltene Fehlernotiz. Displayfoto, Flashkennung und Startwerte erkennen den neuen Teststand. Die Geräteauswahl führt zum passenden [OLED-Download](https://github.com/bluecyber81/pixl.js/releases/download/de3.84-oled-t4/Allmiibo_OLED_DE3_84_Test4_APP.zip) und zur [Handy-Anleitung](https://bluecyber81.github.io/pixl.js/guide/index.html#oled).

## Dateimanager 3.55.6 · Diagnose für LCD DE3.84 / App657

Unter **Gerät & Diagnose** meldet App657 ihre vollständige SourceID, das kompilierte Boardprofil und eine gegebenenfalls erhaltene Fehlernotiz vom vorigen Start. Der Startbericht zeigt die tatsächlich belegten Cache-Seiten beim letzten Einbinden des Dateisystems. Die Paketreferenz und der SHA-256-Wert der ausgelieferten App werden separat angezeigt. Der Prüfassistent enthält zusätzliche Fälle für Spiele, Drehung, Tasten, Dimmen und DFU. [Dateimanager öffnen](https://bluecyber81.github.io/pixl.js/) · [Windows-Version und Webquellen](https://github.com/bluecyber81/pixl.js/releases/tag/web3.55.6)

Das LCD-Testupdate setzt Z21, S112 7.3.0 und PFS1 voraus. Erfolgreicher Betrieb wurde auf einem LCD mit Z21 gemeldet. [DE3.84 nur App](https://github.com/bluecyber81/pixl.js/releases/download/de3.84-lcd-test1/Allmiibo_LCD_DE3_84_657_NUR_APP.zip) · [Prüfpaket](https://github.com/bluecyber81/pixl.js/releases/download/de3.84-lcd-test1/Allmiibo_LCD_DE3_84_App657_Pruefpaket.zip) · [Reguläres Android-Komplettpaket DE3.81](https://github.com/bluecyber81/pixl.js/releases/download/de3.81/Allmiibo_LCD_S112_7_3_0_Z21_DE3_81_654_KOMPLETT.zip)

## Archiv · Dateimanager 3.55.5 und LCD-Firmware DE3.81

DE3.81 / App654 ist die reguläre LCD-Firmware. Mit eingerichtetem Packed LittleFS (PFS1), S112 7.3.0 und Z19, Z20 oder Z21 genügt die [App-ZIP](https://github.com/bluecyber81/pixl.js/releases/download/de3.81/Allmiibo_LCD_DE3_81_654_NUR_APP.zip). Für ein kompatibles LCD mit älterem Bootloader enthält das [Android-Komplettpaket](https://github.com/bluecyber81/pixl.js/releases/download/de3.81/Allmiibo_LCD_S112_7_3_0_Z21_DE3_81_654_KOMPLETT.zip) S112 7.3.0, Z21 und App654. [Installationsanleitung für LCD](https://bluecyber81.github.io/pixl.js/guide/index.html#flash) · [Separate OLED-Testversion](https://bluecyber81.github.io/pixl.js/guide/index.html#oled)

## Archiv · Dateimanager 3.55.4

Die Firmware-Auswahl und die Anleitung führen zum passenden Paket für das eigene Gerät. Bei Veröffentlichung von 3.55.4 standen DE3.75 Final und die Vorschau DE3.81 zur Wahl. Das OLED-Testpaket DE3.81 für S112 7.2.0 wird am Handy als App-Update installiert. [LCD-Freigabe](https://github.com/bluecyber81/pixl.js/releases/tag/de3.75) · [OLED-Testversion und Anleitung](https://github.com/bluecyber81/pixl.js/releases/tag/de3.81-oled-t1) · [Dateimanager 3.55.4](https://github.com/bluecyber81/pixl.js/releases/tag/web3.55.4)

## Dateimanager 3.55.3

Im Akkuverlauf unter **Gerät & Diagnose** siehst du Messdauer, Spannweite und Unterbrechungen. Der erste neue Messwert nach einer Pause markiert die Fortsetzung. Der CSV-Export enthält den Pausengrund in der fünften Spalte `pause_reason`. [Dateimanager öffnen](https://bluecyber81.github.io/pixl.js/) · [Windows-Paket und Quellcode](https://github.com/bluecyber81/pixl.js/releases/tag/web3.55.3)

## Dateimanager 3.55.2

Unter **Gerät & Diagnose → Startzeiten der Anwendung** lassen sich jetzt die Scanzeit von PackedFS, die Anzahl der Flash-Lesezugriffe und die gelesenen Bytes mit einem früheren Bericht vergleichen. Nach dem erneuten Lesen der JEDEC-Kennung bleibt die bereits ermittelte Laufwerksgröße in derselben Geräteverbindung sichtbar. Ein kontrollierter Vergleich setzt dasselbe Gerät und denselben Speicherbestand voraus. Die Diagnose kann auch Versionsbezeichnungen mit einem Testsuffix wie DE3.71t1 oder der Endung -PREP übernehmen. [Dateimanager öffnen](https://bluecyber81.github.io/pixl.js/) · [3.55.2 für Windows und als Quellcode](https://github.com/bluecyber81/pixl.js/releases/tag/web3.55.2)

## Dateimanager 3.55.1

Zum Aktualisieren eines kompatiblen LCD mit Z19 oder Z20 und vorhandenem PFS1 steht die App DE3.80 im Firmwarebereich bereit. Der externe Flash-Kapazitätscode wird anhand der Tabelle des Treibers eingeordnet. [Android ZIP](https://github.com/bluecyber81/pixl.js/releases/download/de3.80/Allmiibo_LCD_S112_7_3_0_Z20_DE3_80_653_KOMPLETT.zip) · [App ZIP](https://github.com/bluecyber81/pixl.js/releases/download/de3.80/Allmiibo_LCD_DE3_80_653_NUR_APP.zip) · [Web 3.55.1](https://github.com/bluecyber81/pixl.js/releases/tag/web3.55.1)

## Hardwarediagnose und Akkuverlauf · Dateimanager 3.55.0

Unter **Gerät & Diagnose** kannst du den Akkuverlauf starten. Der Browser liest alle zehn Sekunden die zuletzt gemeldete Spannung und die Ladeanzeige aus. Die letzten 120 Einträge gelten für die aktuelle Verbindung. Während einer Dateiübertragung oder bei verborgenem Tab pausiert die Aufzeichnung. Steht „551520 · 180 mAh · 3,8 V · 0,684 Wh“ auf deinem Akku, kannst du das unter **Hardwareprofil → Akkuetikett diesem Gerät zuordnen** bestätigen. Der Diagnoseexport kennzeichnet diese Angabe als Akkuaufdruck.
Der CSV-Export enthält Empfangszeit, Millivolt, Ladeanzeige und Unterbrechungen. Die drei JEDEC-Bytes geben Herstellerkennung, Speichertyp und Kapazitätscode an. Der Herstellername ist eine Zuordnung des ersten Bytes. Der genaue Bestellcode bleibt offen. [TsingTeng TH25Q-16HB, Abschnitte 7.26 und SFDP](https://offer-product.oss-cn-beijing.aliyuncs.com/product/offer/attachment/2212322333372/file/subPdf_76047_40067_20210821-152646801.pdf) · [Winbond W25Q16JV, Herstellerkennung](https://www.mouser.com/catalog/specsheets/Winbond%20Electronics%20Corporation_08-25-2025_W25Q16JV.pdf)


Am LCD zeigt der Kontrastregler den wirksamen Bereich von 60 bis 100 %. Bei langen Listen verarbeitet die Zeichnung nur die sichtbaren Zeilen einschließlich der angeschnittenen Ränder. Im Dateimanager kannst du das Displayfoto in Originalgröße, 2× oder 3× ansehen und als PNG mit 128 × 64 Pixeln speichern.

Die LCD-Testfirmware **DE3.79 / App652** meldet die drei Kennbytes des externen Flashs. Der Dateimanager zeigt damit Herstellerkennung, Speichertyp und Kapazitätscode. Die Abfrage nutzt die beim Einrichten des Speichers gelesenen Bytes. Geräte mit älterer Firmware können die übrige Diagnose weiterhin nutzen. [App-ZIP fürs LCD mit PFS1, Z19 und S112 7.3.0](https://github.com/bluecyber81/pixl.js/releases/download/de3.79/Allmiibo_LCD_DE3_79_652_NUR_APP.zip) · [Dateimanager öffnen](https://bluecyber81.github.io/pixl.js/) · [Windows-Paket und Quellcode](https://github.com/bluecyber81/pixl.js/releases/tag/web3.55.0)

## Akkuanzeige · LCD-Firmware DE3.77 und Dateimanager 3.54.1

Auf dem LCD erscheinen Spannung und achtstufiges Akkusymbol größer. Ein Blitz zeigt den Ladevorgang an. Bei niedrigem Stand erscheint „Niedrig“, bei fehlendem Messwert ein Strich. Der Dateimanager zeigt die Spannung in beiden Diagnoseansichten einheitlich in Volt, auf Deutsch zum Beispiel **3,870 V**.

Die signierte App650 ist eine Testversion für das Allmiibo LCD mit PFS1, Z19 und S112 7.3.0. [App-ZIP fürs Handy](https://github.com/bluecyber81/pixl.js/releases/download/de3.77/Allmiibo_LCD_DE3_77_650_NUR_APP.zip) · [Dateimanager öffnen](https://bluecyber81.github.io/pixl.js/) · [Stabile Firmware DE3.75](https://github.com/bluecyber81/pixl.js/releases/tag/de3.75)

## Junger Link und Junge Zelda · Dateimanager 3.54.0

Im Figurenkatalog findest du beide für 2027 angekündigten Figuren über ihren deutschen oder englischen Namen und über das Switch-2-Spiel *The Legend of Zelda: Ocarina of Time*. Jede Figur hat ein eigenes Bild und einen deutschen Spielhinweis. Nintendo nennt besondere Masken, die Link tragen kann. [Spielinformationen bei Nintendo](https://www.nintendo.com/de-de/Spiele/Nintendo-Switch-2-Spiele/The-Legend-of-Zelda-Ocarina-of-Time-3115664.html)

Auch alle sieben Figuren aus *Kirby Air Riders* haben jetzt auf dem LCD ein eigenes Bild und deutsche Spielhinweise, darunter Kirby mit Schwert & Dragoon und Dedede Noir & Hydra. [Versionshinweise zu Kirby Air Riders](https://www.nintendo.com/de-de/Support/Kaufe-und-Mitgliedschaften/Spiele/Das-Aktualisieren-von-Kirby-Air-Riders--2967700.html)

Für die eingebaute Datenbank auf dem **Allmiibo LCD** gibt es die signierte **DE3.76 / App649** als Testversion für PFS1 mit Z19 und S112 7.3.0. Im Dateimanager findest du die ZIP unter **Update**. [App-ZIP fürs Handy](https://github.com/bluecyber81/pixl.js/releases/download/de3.76/Allmiibo_LCD_DE3_76_649_NUR_APP.zip) · [Stabile Firmware DE3.75](https://github.com/bluecyber81/pixl.js/releases/tag/de3.75)

## Web 3.53.0 · 15.11.2026

Ordnersicherungen lassen sich mit einer früheren ZIP beschleunigen. Der Dateimanager vergleicht kleine Dateien mit der aktuellen Prüfsumme vom Gerät. Du kannst die ZIP komprimieren, die Dauer je Sicherungsphase sehen und einen gesicherten Figurenordner offline prüfen. Beim Umbenennen und vor dem ZIP-Import wird die verbleibende Pfadlänge angezeigt. Unter Gerät & Diagnose lassen sich MIFARE-Mini-Slots lesend prüfen.

Für die Folgesicherung öffnest du denselben Geräteordner wie beim letzten Mal. Unter **Sicherung → Sicherungsoptionen** wählst du die frühere ZIP und klickst auf **Ordner sichern (ZIP)**. Auf kompatibler DE-Firmware werden Dateien bis 572 Byte mit der aktuellen Geräteprüfsumme verglichen. Geänderte, neue und größere Dateien liest der Dateimanager vollständig. Die fertige ZIP lässt sich eigenständig wiederherstellen.

Unter **Messwerte der letzten Sicherung** stehen Verzeichnisabfragen, Dateiübertragung, abschließende Ordnerprüfung und das Erstellen der ZIP. Die Gesamtzeit endet, sobald die ZIP zum Speichern bereitsteht. [Prüfergebnisse](validation/WEB3_53_0.json)

Auf einem LCD-Allmiibo mit DE3.75 dauerte die Folgesicherung über Windows-Bluetooth **5:21 Minuten** für 1.081 Dateien. Davon wurden 1.052 per Geräteprüfsumme bestätigt und 29 neu gelesen, einschließlich einer gleich großen, inhaltlich geänderten Datei. Die vollständige komprimierte ZIP war 891.938 Byte groß. Die frühere Sicherung derselben Sammlung brauchte laut Manifest **15:41 Minuten** bis zum Abschluss der Datenprüfung. Verbindung und Laufzeitumgebung beeinflussen die Dauer.

## Dateimanager 3.52.1

**DE3.75 / App648 war die damalige stabile LCD-Firmware** für Geräte mit PFS1, Z19 und S112 7.3.0. Auf einem LCD gelangen die Rückkehr zur gewählten Figur und das Aufwachen in beiden Apps. Die Switch erkannte außerdem eine bekannte Figur. Wer die signierte App648 bereits geflasht hat, kann sie weiterverwenden. [App-ZIP fürs Handy](https://github.com/bluecyber81/pixl.js/releases/download/de3.75/Allmiibo_LCD_DE3_75_648_NUR_APP.zip) · [Änderungen und Gerätetests](RELEASE_DE3_75.md)

Unter **Gerät & Diagnose** kannst du mehrere gespeicherte Geräteprüfungen vergleichen und das Ergebnis als JSON speichern. Bei gleichzeitiger Bearbeitung in zwei Tabs kannst du beide Entwürfe wieder öffnen. Der Prüftext passt auch bei großer Schrift auf ein schmales Display. Die Figuren-ID lässt sich direkt kopieren. [Downloads](https://github.com/bluecyber81/pixl.js/releases/tag/web3.52.1)

## Dateimanager 3.52.0

Unter **Gerät & Diagnose** dokumentierst du die Rückkehr zur letzten Figur und das Aufwachen. Die Figurenauswahl bleibt nach einer Onlineprüfung alphabetisch. Der Dateimanager lädt die Werkzeuge für Sicherung, Update und Fernbedienung beim ersten Öffnen. [Dateimanager öffnen](https://bluecyber81.github.io/pixl.js/) · [Downloads](https://github.com/bluecyber81/pixl.js/releases/tag/web3.52.0)

## Dateimanager 3.51.1 · Figurenbild beim Scrollen

Wähle unter **Dateien** eine Figur aus. Am Laptop bleibt die **Auswahl** mit Bild und Figurendaten rechts sichtbar, während du durch einen langen Ordner scrollst. Klickst du eine andere Figur an, erscheint dort ihre Vorschau. [Dateimanager öffnen](https://bluecyber81.github.io/pixl.js/) · [Windows und Quellcode](https://github.com/bluecyber81/pixl.js/releases/tag/web3.51.1)

Ordner stehen oben. Tippe eine Figurendatei an, um ihr Bild und ihre Informationen zu öffnen. Am Handy stehen Dateityp und Größe unter dem Namen, die Aktionen findest du rechts. Ist ein lokaler Name für das Allmiibo ungeeignet, kannst du den Zielnamen vor dem Hochladen korrigieren oder den Eintrag überspringen.

## DE3.74 / App647 und Dateimanager 3.50.0

**Finale LCD-Version.** Am 14. November 2026 bestätigte der Besitzer, dass das Displayfoto in der Fernbedienung auf seinem Allmiibo LCD mit DE3.74 und Dateimanager 3.50.0 funktioniert. Der Diagnoseexport weist App647, Bootloader Z19 und SoftDevice S112 7.3.0 aus. [Firmwarefreigabe](https://github.com/bluecyber81/pixl.js/releases/tag/de3.74)

Unter **Fernbedienung → Displaybild aktualisieren** zeigt das Handy das aktuelle Gerätemenü. Du kannst das Bild drehen, als PNG speichern und nach dem nächsten Tastendruck erneut aufnehmen. Aktiviere dazu am wachen LCD-Allmiibo die BLE-Fernbedienung und verbinde **Pixl.Remote**. DE3.74 fügt die Fotoaufnahme hinzu. Auch auf DE3.73 kannst du mit **Verbindung prüfen** die Uhrzeit der letzten angeforderten Geräteantwort sehen. Ein abgebrochener Verbindungsversuch kann eine neu aufgebaute Dateiübertragung nicht mehr versehentlich trennen.

[Signierte Android-DFU-ZIP für LCD mit PFS1, Z19 und S112 7.3.0](https://github.com/bluecyber81/pixl.js/releases/download/de3.74/Allmiibo_LCD_DE3_74_647_NUR_APP.zip) · [Dateimanager 3.50.0](https://github.com/bluecyber81/pixl.js/releases/tag/web3.50.0)

## Dateimanager 3.49.0

Auf dem iPhone erklärt der Dateimanager die Möglichkeiten für Katalog und Bluetooth. Beim erneuten Ordnerabgleich lassen sich Änderungen auf beiden Seiten erkennen. Für Geräte mit cylin577s Firmware gibt es einen eigenen PixLink-Zugang. [Veröffentlichung und Downloads](https://github.com/bluecyber81/pixl.js/releases/tag/web3.49.0)

## Dateimanager 3.48.4

Bei der Online-Katalogprüfung zeigt der Dateimanager an, wenn Spielhinweise oder Schreibangaben in der Quelle fehlen. Die geprüften Spielhinweise bleiben verfügbar. Die Fernbedienung unterstützt die Tastatur und zeigt an, welchen Befehl das Gerät bestätigt hat. Für Dragoon und Hydra nennt die Dateiprüfung beide möglichen Maschinen, weil sie den gleichen Platinencode verwenden. [Veröffentlichung und Downloads](https://github.com/bluecyber81/pixl.js/releases/tag/web3.48.4)

## Figurenkatalog ab 3.48.3

Der Offline-Katalog umfasst 954 Figuren. Unter **Figurenkatalog → Spiel → Kirby Air Riders** findest du sieben Fahrer, darunter Kirby mit Schwert & Dragoon sowie Dedede Noir & Hydra. Beide lassen sich auch unter ihrem deutschen Namen finden. Der Firmware-Namensfilter umfasst die 952 IDs der veröffentlichten App646. [Windows und Quellcode](https://github.com/bluecyber81/pixl.js/releases/tag/web3.48.3)

## Dateimanager 3.48.2

Die lokale Platzprüfung unterstützt App646. Beim Ändern des Schreibschutzes bleiben die vorhandenen Metadaten erhalten. Reservierte Namen im Stammordner werden bereits vor dem Schreiben erkannt. Die Sicherungsansicht erklärt, wann die ZIP im Browser gespeichert ist und wann sie heruntergeladen wurde. [Dateimanager und Quellcode](https://github.com/bluecyber81/pixl.js/releases/tag/web3.48.2) · [ChatGPT-Prüfpaket](https://github.com/bluecyber81/pixl.js/releases/download/de3.73-test646/Allmiibo_DE3_73_App646_Z19_Web3_48_2_ChatGPT_Pruefpaket.zip)

In Version 3.48.2 war DE3.65/App637 für LCD-Geräte mit Packed LittleFS die stabile Vorauswahl. Die optionale DE3.73/App646 gibt es mit vorhandenem Z19 als [Nur-App-ZIP](https://github.com/bluecyber81/pixl.js/releases/download/de3.73-test646/Allmiibo_LCD_DE3_73_App646_TEST_DFU.zip). Für kompatible Geräte mit älterem Bootloader gibt es die [zweiphasige Android-Kombi](https://github.com/bluecyber81/pixl.js/releases/download/de3.73-test646/Allmiibo_LCD_S112_7_3_0_Z19_DE3_73_646_KOMPLETT_TEST.zip). Die [Installationsanleitung](https://bluecyber81.github.io/pixl.js/guide/) beschreibt die Geräteprüfung und den separaten SPIFFS-Migrationsweg.

## DE3.72 / App645 und Dateimanager 3.48.1

Die LCD-Testanwendung merkt sich bei der Rückkehr den gewählten Datenplatz und die im Detail zuletzt angezeigte Figur. Vier deutsche und englische Spielhinweise zu Mipha und Urbosa wurden korrigiert. Im Dateimanager ist App645 jetzt auch für die lokale Platzprüfung auswählbar. [Änderungen und Prüfnachweise](https://github.com/bluecyber81/pixl.js/releases/tag/de3.72) · [Dateimanager öffnen](https://bluecyber81.github.io/pixl.js/)

| Ausgangslage beim LCD-Allmiibo | Passender Download |
| --- | --- |
| Packed LittleFS ist eingerichtet, Z19 und Nordic S112 7.3.0 sind vorhanden | [Nur die neue Gerätesoftware DE3.72](https://github.com/bluecyber81/pixl.js/releases/download/de3.72/Allmiibo_LCD_DE3_72_645_NUR_APP.zip) |
| Passendes nRF52832-LCD mit bekanntem Flashlayout und funktionierendem, signaturkompatiblem Secure DFU. Bootloaderzähler unter 19, S112-FWID 0x0103 oder 0x0126 | [Komplettpaket mit S112 7.3.0, Z19 und DE3.72](https://github.com/bluecyber81/pixl.js/releases/download/de3.72/Allmiibo_LCD_S112_7_3_0_Z19_DE3_72_645_KOMPLETT.zip). Am Android-Handy mit **nRF Device Firmware Update** beide Phasen abschließen. |
| Altes SPIFFS-Laufwerk steht vor der Umstellung | [Vorbereitungsfirmware DE3.30-PREP / 600](https://github.com/bluecyber81/pixl.js/releases/download/de3.72/Allmiibo_LCD_SPIFFS_DE3_30_PREP_600.zip). Zuerst die Originaldateien sichern. Vor dem Systemwechsel die vollständige Raw128-Sicherung frisch vergleichen und die Platzprüfung bestehen. [Schritt für Schritt zu LittleFS](https://bluecyber81.github.io/pixl.js/guide/#littlefs) |

Die Anleitung nennt die Geräte- und Zählervoraussetzungen. Die Einrichtung von LittleFS löscht das alte Laufwerk E:. Anschließend die bestätigte Sicherung wiederherstellen und vollständig am Ziel vergleichen. [Alle Installationswege](https://bluecyber81.github.io/pixl.js/guide/) · [Windows, Quellen und ChatGPT-Prüfpaket](https://github.com/bluecyber81/pixl.js/releases/tag/web3.48.1)

## Dateimanager 3.48.0 und LCD-Testfirmware DE3.71t1

Der Dateimanager schützt fertige Sicherungs-ZIPs vor versehentlichem Schließen. ZIP-Vergleiche lassen sich filtern und als CSV oder JSON exportieren. Favoriten und Suchfilter können in einen anderen Browser übernommen werden. Unter Windows funktioniert jetzt auch das Beenden des Hintergrundservers nach einer bestätigten Stoppanforderung.

Beim Gerätetest mit App644 kehrte die Auswahl auf den ausprobierten Wegen im Datei-Emulator und in der Amiibo-Datenbank zur richtigen Figur zurück, sowohl bei „Zurück zur Liste“ als auch nach dem Aufwachen. Die Testfirmware ist ein signiertes App-Update für passende LCD-Geräte mit Packed LittleFS. [Dateimanager öffnen](https://bluecyber81.github.io/pixl.js/) · [Versionshinweise und Downloads](https://github.com/bluecyber81/pixl.js/releases/tag/web3.48.0) · [LCD-Testfirmware](https://github.com/bluecyber81/pixl.js/releases/tag/de3.71t1)

## Dateimanager 3.47.0

Der Amiibo-Emulator sortiert die sichtbare Seite im Figurenordner einmal. Unter **Gerät & Diagnose → Alle Diagnosewerte auslesen** zeigt der Dateimanager mit DE3.70 die erkannten Mitteltastenereignisse bis zur ersten Auswahl im Hauptmenü und die Dauer des App-Aufrufs. Die Daten bleiben bis zum Neustart im RAM. [LCD DE3.70 (ZIP)](https://bluecyber81.github.io/pixl.js/firmware/Allmiibo_LCD_DE3_70_642_NUR_APP.zip) · [Web 3.47.0](https://github.com/bluecyber81/pixl.js/releases/tag/web3.47.0)

## Dateimanager 3.46.0

Unter **Sicherung** kannst du zwei gespeicherte Sicherungs-ZIPs auswählen. Die Ansicht zeigt neue, entfernte und geänderte Einträge. Der Vergleich läuft auch bei getrenntem Gerät. Unter **Update** öffnet „In nRF DFU öffnen“ das gewählte öffentliche LCD-Paket auf Android. Die LCD-Testversion DE3.69 zeigt die letzten fünf geöffneten Figuren in der Amiibo-Datenbank. [DE3.69 LCD (ZIP)](https://bluecyber81.github.io/pixl.js/firmware/Allmiibo_LCD_DE3_69_641_NUR_APP.zip) · [Web 3.46.0](https://github.com/bluecyber81/pixl.js/releases/tag/web3.46.0)

<a id="dateimanager-3450"></a>

## Dateimanager 3.45.0 · LCD DE3.68 / 640 · 2026-11-09

Im Figurenkatalog kannst du ein Spiel auswählen und die passenden Figuren aus deiner Sammlung anzeigen. Unter Sicherung zeigt der Ordnervergleich auch die Dateien, die nur auf dem Gerät liegen. Die LCD-Testversion DE3.68 merkt sich beim Zurückkehren ins Hauptmenü die zuletzt geöffnete App. Im Dateimanager lässt sich jedem verbundenen Gerät ein eigener Name für diesen Browser geben. Beim Gerätewechsel erscheint der jeweils zugeordnete Name. [DE3.68 LCD (ZIP)](https://bluecyber81.github.io/pixl.js/firmware/Allmiibo_LCD_DE3_68_640_NUR_APP.zip) · [Web 3.45.0](https://github.com/bluecyber81/pixl.js/releases/tag/web3.45.0)

**[Dateimanager öffnen](https://bluecyber81.github.io/pixl.js/)** ·
[Anleitung für Firmware, Bootloader und LittleFS](https://bluecyber81.github.io/pixl.js/guide/index.html) ·
[Firmware übertragen](https://bluecyber81.github.io/pixl.js/dfu/web.html) ·
[Downloads für 3.44.0](https://github.com/bluecyber81/pixl.js/releases/tag/web3.44.0) · [Versionsgeschichte mit Zwischenständen](VERSIONEN_WEB.md)

Wenn Bluetooth beim Hochladen einer Figur abbricht, zeigt der Dateimanager den betroffenen Speicherort und die ursprüngliche Sitzung an. Steht der Abschluss noch aus, verbinde dasselbe Gerät erneut und prüfe den Zielordner, bevor du den Upload wiederholst. Halte den Browsertab dafür geöffnet.

## Verbinden

1. Die Webseite in Chrome auf Android oder einem unterstützten Computer öffnen.
2. Am eigenen Allmiibo „Bluetooth-Dateiübertragung“ öffnen. Andere Verbindungen
   zu nRF, AmiLoop oder einem weiteren Dateimanager vorher trennen.
3. „Verbinden“ anklicken und das eigene Gerät im Browser auswählen.

Das Allmiibo muss sich beim verwendeten Handy oder Computer befinden. Die
Webseite verbindet sich über dessen Bluetooth; sie macht kein entferntes
Allmiibo über das Internet erreichbar. Der Laptop zu Hause kann ausgeschaltet
bleiben. Die Vorschau und der Figurenkatalog lassen sich ohne Gerät ansehen.

## Dateimanager 3.44.0

Beim Öffnen wählt der Dateimanager die erste unterstützte Sprache aus der Sprachliste des Browsers. Im Sprachmenü kannst du eine feste Sprache wählen.

Eine zuvor gespeicherte Sprache hat Vorrang. Mit „Automatisch (Browsersprache)“ folgt die Seite wieder deinem Browser. Gibt es für keine deiner bevorzugten Sprachen eine Übersetzung, erscheint die Seite auf Englisch.

- **3.44.0** · [Web-Quellcode (ZIP)](https://github.com/bluecyber81/pixl.js/releases/download/web3.44.0/Allmiibo_Dateimanager_3_44_0_Quellcode.zip) · [ChatGPT-Prüfpaket (ZIP)](https://github.com/bluecyber81/pixl.js/releases/download/web3.44.0/Allmiibo_DE3_67_Z19_Web3_44_0_ChatGPT_Pruefpaket.zip)

## Dateimanager 3.43.1

Die lokale LittleFS-Platzprüfung zeigt DE3.67 mit App-Zähler 639 als neueste geprüfte Firmware. Das Speicherprofil gilt für DE3.55 bis DE3.67. Unter **Sicherung → LittleFS: Umstellung & Wiederherstellung** ist dieses Profil vorausgewählt. Es berechnet, ob eine gewählte Sicherung mit der vorgesehenen Reserve auf das Ziellaufwerk passt.

- **3.43.1** · [Web-Quellcode (ZIP)](https://github.com/bluecyber81/pixl.js/releases/download/web3.43.1/Allmiibo_Dateimanager_3_43_1_Quellcode.zip) · [ChatGPT-Prüfpaket (ZIP)](https://github.com/bluecyber81/pixl.js/releases/download/web3.43.1/Allmiibo_DE3_67_Z19_Web3_43_1_ChatGPT_Pruefpaket.zip)

## Dateimanager 3.43.0

1. **Sicherung** öffnen. Vor dem Lesen einer normalen Ordnersicherung **Ordnersicherung nach Schließen des Browsers fortsetzen** einschalten. Nach einem Neustart dieselbe Webadresse im selben Browserprofil öffnen, dasselbe Gerät verbinden und denselben Ordner wählen. Der Dateimanager vergleicht die gespeicherten Dateien frisch mit dem Gerät. Die fertige ZIP über den Download sichern.
2. **Figurenkatalog → Webfavoriten und gespeicherte Filter** öffnen. Bei einer Figur den Stern wählen oder eine Suche unter einem eigenen Filternamen speichern. Die Rahmenfarben zeigen weiter den geprüften Gerätebestand.
3. Unter **Downloadlinks sichern und übertragen** Links als JSON speichern oder eine Datei für die Vorschau wählen. „Nur neue Links ergänzen“ erhält vorhandene Werte. „Geänderte Links aus der Datei übernehmen“ ersetzt die angezeigten Abweichungen. Der Export enthält die vollständigen URLs einschließlich etwaiger privater Zugangsparameter.
4. **Gerät & Diagnose → LCD-Displayfoto** aufnehmen. **Um 180° drehen** dreht Vorschau und gespeichertes PNG. Das funktioniert mit LCD-App DE3.66 oder neuer.

- **3.43.0** · [Web-Quellcode (ZIP)](https://github.com/bluecyber81/pixl.js/releases/download/web3.43.0/Allmiibo_Dateimanager_3_43_0_Quellcode.zip) · [ChatGPT-Prüfpaket (ZIP)](https://github.com/bluecyber81/pixl.js/releases/download/web3.43.0/Allmiibo_DE3_67_Z19_Web3_43_0_ChatGPT_Pruefpaket.zip)

## Dateimanager 3.42.2

Für die aktuelle Version tippe unten im Dateimanager auf **Quellcode (ZIP)** oder **Prüfpaket für ChatGPT (ZIP)**. Beide Downloads funktionieren auch ohne Geräteverbindung.

Die bebilderten Schaltflächen für Figurenimport und Firmwareupdate nehmen oben weniger Platz ein. Beide bleiben direkt antippbar. Am Handy kannst du für 3.42.2 und 3.42.1 jeweils den Web-Quellcode oder das ChatGPT-Prüfpaket herunterladen. Die Quellcode-ZIP ist für die Arbeit am Dateimanager gedacht. Wähle das Prüfpaket, wenn du ChatGPT die Quellen und Nachweise zu DE3.66, Z19 und dem jeweiligen Dateimanager übergeben möchtest.

- **3.42.2** · [Web-Quellcode (ZIP)](https://github.com/bluecyber81/pixl.js/releases/download/web3.42.2/Allmiibo_Dateimanager_3_42_2_Quellcode.zip) · [ChatGPT-Prüfpaket (ZIP)](https://github.com/bluecyber81/pixl.js/releases/download/web3.42.2/Allmiibo_DE3_66_Z19_Web3_42_2_ChatGPT_Pruefpaket.zip)
- **3.42.1 (Vorgängerversion)** · [Web-Quellcode (ZIP)](https://github.com/bluecyber81/pixl.js/releases/download/web3.42.1/Allmiibo_Dateimanager_3_42_1_Quellcode.zip) · [ChatGPT-Prüfpaket (ZIP)](https://github.com/bluecyber81/pixl.js/releases/download/web3.42.1/Allmiibo_DE3_66_Z19_Web3_42_1_ChatGPT_Pruefpaket.zip)

## Dateimanager 3.42.1

Die sechs Arbeitsbereiche haben eigene Farbakzente. Auf dem Handy führen zwei bebilderte Schaltflächen direkt zum Figurenimport und zum Firmwareupdate. Bei verbundenem Allmiibo zeigt „Dein Gerät“ den geöffneten Ordner, die Zahl seiner Einträge und die Speicherbelegung. Der breite Balken am unteren Rand zeigt den belegten Anteil mit einem Verlauf von Petrol zu Indigo. Neben dem Balken stehen freie und gesamte Kapazität sowie der belegte Prozentanteil. Auf dem Desktop findest du die Karte in der Seitenleiste, auf dem Handy unter den sechs Navigationsschaltflächen. Beide Beispielansichten aus **3.42.1** zeigen simulierte Gerätedaten. [Handy](images/web-3.42.1/mobile.png) · [Desktop](images/web-3.42.1/desktop.png)

Auch bei langsamer Verbindung genügt ein Klick auf **Ich möchte eine Figur hinzufügen**. Sobald die Ansicht geladen ist, springt der Dateimanager zur Figurenauswahl. Unter **Anleitung → Programme und Downloads** findest du den PC-Weg mit nRF Util für Bluetooth-DFU und die dafür erforderliche Nordic-Hardware. Für diesen Browser-Patch ist kein Flashen erforderlich.

## Dateimanager 3.42.0

1. **Ich möchte eine Figur hinzufügen** öffnet die Figurenauswahl und den Import. **Ich möchte die Firmware aktualisieren** öffnet die Geräte- und Paketübersicht für unterstützte LCD-Geräte.
2. Wenn ein eingetragener HTTPS-Link im Katalog nicht direkt geladen werden kann, öffne **Quelle im Browser öffnen**. Wähle anschließend bei derselben Figur **Heruntergeladene BIN prüfen** und die gespeicherte Datei. Bei passender ID kannst du dieselben geprüften Daten mit **Im Geräteimport öffnen** zur Übertragung vorbereiten.
3. Öffne unter **Dateien → Auf dem Gerät suchen** beim gewünschten Dateitreffer **Vom Gerät herunterladen**. Der angezeigte Ordnerpfad hilft bei gleichnamigen Dateien.
4. Unter **Figurenkatalog → Bestand prüfen** kannst du nach dem Vergleich das Ergebnis als CSV für Excel speichern. Dazu ist keine weitere Bluetooth-Abfrage nötig. Der Export enthält Pfad und Prüfbereich. Das Präfix `0x` hält die komplette Figuren-ID in Tabellenkalkulationen lesbar.

## Dateimanager 3.41.0

1. **Figurenkatalog** öffnen und bei der gewünschten Figur **Downloadlink eintragen** aufklappen. Bei gleichnamigen Figuren auf Serie und ID achten.
2. Den direkten HTTPS-Link zur BIN-Datei einfügen und **Link speichern** wählen. Der Link bleibt in diesem Browser auf dieser Website gespeichert.
3. Den **Figurennamen mit dem Pfeil ↓** antippen. Der Dateimanager lädt die Datei vom angegebenen Server, prüft Größe, Grundstruktur und Figuren-ID und startet den BIN-Download auf Handy oder Laptop. Dafür genügt der Browser.
4. Über **Downloadlink bearbeiten** lässt sich die Adresse austauschen oder entfernen.

Der Dateiserver muss die BIN direkt über HTTPS ausliefern und den Abruf aus dem Browser erlauben (CORS). Der Katalog enthält öffentliche Figurendaten. Persönliche Downloadadressen kommen vom Nutzer und werden beim Anzeigen des Katalogs nicht abgerufen. Wer zusätzlich auf sein Allmiibo übertragen möchte, öffnet die Figur über **Details und Bild** und nutzt unter **Figurendatei übernehmen** den bereits vorhandenen Import.

## Dateimanager 3.40.1

- **Update** – Beim Öffnen des Updaters über die Paketkarte ist die gewählte Version bereits markiert. Paketprüfung und Bluetooth-Übertragung startest du selbst.
- **Figurenkatalog → Filter → Serie** – Auch eine Serie, zu der erst Ankündigungen vorliegen, lässt sich auswählen. Ankündigungen zählen separat von den bestätigten Katalog-IDs.
- **Sicherung** – Nach einer abgeschlossenen Sicherung siehst du, wie viele Dateien frisch gelesen und wie viele aus dem geprüften Zwischenstand übernommen wurden.

## Dateimanager 3.40.0

Unter **Figurenkatalog → Angekündigte Figuren** sind neun Ankündigungen mit Regionsangaben aufgeführt. In der Gerätesuche öffnet ein Dateitreffer die Figurenbild-Vorschau. Mit der LCD-Testfirmware DE3.66 kannst du unter **Gerät & Diagnose → LCD-Displayfoto → Displayfoto aufnehmen** den aktuellen Bildschirm als PNG speichern. Die DFU-Seite schätzt während der Übertragung die verbleibende Zeit anhand bestätigter Bytes. [Anleitung für 3.40.0](RELEASE_DE3_66.md)

## Figurensammlung, Karten-Slots und Sicherungsimport

**Figurenkatalog → Details und Bild** und die **Dateivorschau** zeigen Katalogzuordnungen und vorhandene Nutzungshinweise. Der Quellenstand umfasst 952 Figuren und 1.344 Zuordnungen. Alle 54 unterschiedlichen englischen Nutzungshinweise liegen auch auf Deutsch vor. Übersetzte Hinweise bieten den englischen Originaltext zum Aufklappen. Das ist keine Bestätigung von Spielkompatibilität oder Belohnungen.

**Figurensammlung → Prüfung: Dateiinhalte prüfen (empfohlen) → Sammlung prüfen → Anzeigen → Gleiche Figuren-ID / Dateiinhalte** zeigt getrennte SHA-256-Gruppen innerhalb einer Figuren-ID. Der Vergleich nutzt bereits gelesene Bytes, ohne weitere BLE-Dateilesen. Gleiche ID allein genügt nicht: UID, Spielstand und Varianten können abweichen. Die Schnellprüfung sagt ausdrücklich, dass Inhalte ungeprüft sind. Es wird nichts automatisch gelöscht. Nach Schreibvorgängen den veralteten Bericht erneut prüfen.

Unter **Gerät & Diagnose → Karten-Slot lokal prüfen** zuerst `chameleon/slots/config.bin` im Format v8 aus der eigenen Sicherung laden. Dann den Slot auswählen und die dazugehörige Datei `NN.bin` aus derselben Sicherung öffnen. Slot 1 verwendet `00.bin`. Die Prüfung läuft im Browser.

- **MIFARE Mini** (ab Web 3.53.0) erkennt die 594-Byte-Slotdatei und zeigt UID-Länge, ATQA, SAK und Schreibmodus. Die gespeicherten Profilwerte werden mit dem Mini-Profil von DE3.75 verglichen, die 320 Byte Kartenspeicher mit dessen Werksvorlage. Weitere Profilwerte oder abweichende Kartendaten können beabsichtigt sein. Ein reines 320-Byte-Speicherabbild enthält keinen Slotkopf. Die Prüfung zeigt weder Schlüssel noch die UID an. Authentifizierung und Funktion am Lesegerät erfordern einen eigenen Gerätetest.
- **MF0ICU1, MF0ICU2, MF0UL11 und MF0UL21** unterstützen die Prüfung von UID und BCC. Nur das bekannte alte UID-Kopiermuster bei gültigen BCC0/BCC1 bietet **Korrigierte Kopie herunterladen** an. Die geprüfte `NN.uid-corrected.bin` kann sich an bis zu vier UID-Bytes unterscheiden. Die Quelldatei bleibt erhalten.

**Sicherung → ZIP importieren → Sicherungs-ZIP auswählen → Vergleichen:** Exakte inaktive Stamm-Journaldateien `.pixl_txn_old` und `.pixl_txn_new` bleiben in der Schema-1-Sicherung erhalten, werden aber als gesperrt angezeigt. Andere sichere Dateien bleiben auswählbar. Aktive oder unbekannte Stamm-Transaktionseinträge, darunter `.pixl_txn_pending` oder ein Ordner mit Journalnamen, sperren den gesamten Import. Quelle und Zielumleitung werden kontrolliert, der Zielzustand vor Schreiben erneut gelesen. Normale Unterordner mit gleichnamigen Dateien werden nicht pauschal ausgeschlossen. Schema 2 bleibt beim Migrationsassistenten. Keine automatische Journalbereinigung.

Sammlungsabgleich und lokale Slotprüfung wurden mit Web 3.39.0 eingeführt. [Versionshinweise zu 3.39.0](RELEASE_WEB3_39_0.de.md)

## Funktionen und Daten

* **Figurensammlung → Sammlung prüfen.** Beim Suchen der Ordner siehst du die verstrichene Zeit und die bisher gefundenen BIN-Dateien. Die Inhaltsprüfung zeigt anschließend „gelesen / gesamt“ und schätzt die Restzeit aus abgeschlossenen Dateilesevorgängen.
* **Sicherung & Wiederherstellung → Ordner sichern (ZIP).** Öffne den gewünschten Ordner oder für das ganze Laufwerk **E:/**. Nach der Ordnersuche erscheint die geschätzte Lesezeit. Falls das Handy die Bluetooth-Verbindung verliert, lass den Tab geöffnet, verbinde dasselbe Gerät erneut und tippe auf **Sicherung fortsetzen**. Der ursprüngliche Ordner ist bereits ausgewählt. Ab DE3.66 prüft das Gerät Dateien bis 572 Byte auf E: mit SHA-256. Stimmen die aktuellen Daten mit dem Zwischenstand überein, genügen 32 Byte Prüfsumme als Antwort. Größere Dateien und Dateien auf älteren Geräten liest der Dateimanager erneut. Nach dem abschließenden Ordnervergleich erstellt der Browser die ZIP.
* **Ordnersicherung nach Schließen des Browsers fortsetzen.** Aktiviere diese Option vor der Sicherung, wenn die gelesenen Dateien einen Browserneustart überstehen sollen. Öffne danach dieselbe Webadresse im selben Browserprofil, verbinde dasselbe Allmiibo mit derselben Firmware und wähle denselben Ordner. Unter **Sicherung** zeigt der Dateimanager den vorhandenen Zwischenstand an. Mit **Sicherung fortsetzen** werden Ordner und Dateiinhalte erneut mit dem Gerät abgeglichen. Auf einer gemeinsam genutzten Browserinstallation können andere Personen mit Zugang zu diesem Profil auf die gespeicherten Dateien zugreifen.
* Der Browser legt bis zu 16 MiB im lokalen Websitedatenspeicher ab. Die Anzeige meldet, ob er den angeforderten Speicherschutz gewährt hat. Bei Speicherplatzmangel kann der Browser ungeschützte Daten entfernen. Das Löschen der Websitedaten entfernt auch geschützte Zwischenstände. Ist der Speicher voll, bleiben die bis dahin erfolgreich gespeicherten Dateien als unvollständiger Zwischenstand erhalten. Ein zweiter Tab kann einen laufenden Zwischenstand erst bearbeiten, wenn der erste Tab ihn freigibt.
* Lade die fertige ZIP über **Sicherungs-ZIP speichern** herunter und prüfe sie im Downloadordner. Anschließend löscht **Zwischenstand verwerfen** die lokale Browserkopie. Die heruntergeladene ZIP ist eigenständig. Für eine LittleFS-Umstellung wird die Raw128-Quellsicherung weiterhin vollständig frisch eingelesen.
* **Orange im Figurenkatalog.** Zu dieser ID gibt es einen Eintrag mit einem Prüfhinweis. Ein Beispiel ist eine abweichende ID in Dateieigenschaften und Inhalt. Auf der Karte steht der konkrete Grund. Die Farbe allein sagt nichts über die Erkennung an einer Konsole aus.

Dateien und Ordner, Bilder und Figureninfos, Suche, ZIP-Sicherung und Import,
Diagnose, Fernbedienung sowie die DFU-Seite bleiben erhalten. Einzelne
Gerätefunktionen setzen eine passende Firmware und deren gemeldete Fähigkeiten
voraus. Der Dateimanager zeigt fehlende oder unbestätigte Werte entsprechend an.

Sicherungen und Figurendateien werden lokal im Browser verarbeitet und direkt
zwischen dem gewählten Gerät und dem verwendeten Handy/Computer übertragen.
Die Webseite lädt sie nicht zu GitHub hoch. Browser-Zwischenspeicher ist keine
dauerhafte Sicherung; benötigte ZIP-Dateien ausdrücklich herunterladen.
Die GitHub-Webadresse hat ihren eigenen Browser-Speicher. Eine unter localhost
begonnene Wiederherstellung wird daher nicht automatisch im Online-Tab fortgesetzt.
Eine laufende Übertragung zuerst abschließen; anschließend bei Bedarf dieselbe
gespeicherte Sicherungs-ZIP auf der Online-Seite erneut auswählen.

GitHub erhält die üblichen Abrufe der Webseite. Figurenbilder werden anhand
öffentlicher Figuren-IDs geladen. Persönliche UID, lokale Dateinamen und
Figurendateiinhalte sind dafür nicht erforderlich.

## Firmware-Update

Auf dem Handy und am PC zeigt Schritt 2 den Verlauf. Unter **Übertragen** bestätigt der Bootloader die empfangenen Bytes. **Prüfen** vergleicht die Prüfsumme der gesamten Anwendung. **Abschließen** wartet auf die Antwort des Bootloaders. Auch bei 100 % kann diese Antwort noch ausstehen. Nach seiner Bestätigung erscheint **Wiederverbinden**. Prüfe die Version im Gerätemenü, öffne die Bluetooth-Dateiübertragung und wähle auf der DFU-Seite **Dateimanager öffnen → Verbinden**.

Bricht die Verbindung ab, bevor der Bootloader den Abschluss bestätigt, zeigt die Seite den betroffenen Schritt und den letzten bestätigten Byte-Stand. Prüfe zuerst die Version am Gerät. Ein weiterer Updateversuch erfordert eine neue Geräteauswahl.

Im Dateimanager unter **Gerät & Diagnose → Alle Diagnosewerte auslesen** die Bootinformationen einlesen, wenn du sie beim Update zum Vergleich verwenden möchtest. Anschließend die Dateiverbindung trennen. Auf der DFU-Seite das Paket auswählen. Schritt 1 zeigt den Anwendungszähler, das Hardwarefeld und die erlaubten SoftDevice-FWIDs aus den Init-Daten der ZIP-Datei. Wenn eine höchstens zehn Minuten alte Bootdiagnose verfügbar ist, kommen die Vergleichswerte und eventuelle Hinweise hinzu. Vor dem Übertragen das gewünschte Gerät in den DFU-Modus versetzen und im Browser auswählen.

Für ein LCD-Allmiibo mit vorhandenem PFS1, Z19 und S112 7.3.0 ist DE3.74/App647 die finale Geräte-App. Wähle die signierte Nur-App-ZIP. [Pakete und Voraussetzungen](INSTALLATION.md) · [Migration von anderen Speicherformaten](MIGRATION_PFS1.md) · [Nachbau der Testversion](BUILD_DE3_67.md)


## Startzeiten vergleichen

**Gerät & Diagnose → Startzeiten lesen → Früheren Startbericht vergleichen** öffnet die lokale Dateiauswahl für einen früheren Startbericht oder eine Gesamtdiagnose. Die Unterschiede beziehen sich auf die sechs Zeitmarken seit Beginn der Speicherinitialisierung. Ein negativer Wert in Millisekunden bedeutet eine kürzere Zeit. Bootloader und frühe SDK-Initialisierung liegen davor. Verwende Berichte derselben Sammlung und desselben Geräts.

Gerät & Diagnose: DE3.59 meldet den unberührten Stack ab Anwendungseinstieg. Bei älteren Versionen ist das Feld unbekannt. Unter Startzeiten lassen sich 3 bis 20 gespeicherte Berichte unterschiedlicher Neustarts derselben Firmware bei gleicher Sammlung vergleichen (Median und Minimum–Maximum). Mehrfache Abrufe desselben Starts zählen nicht mehrfach.
