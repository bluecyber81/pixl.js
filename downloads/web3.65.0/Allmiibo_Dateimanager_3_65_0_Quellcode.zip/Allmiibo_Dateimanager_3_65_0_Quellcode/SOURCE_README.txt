ALLMIIBO DATEIMANAGER 3.65.0 – GEPRÜFTE WEB-QUELLENAUSWAHL

Öffentlicher Web-Quellcommit: c18bfb4665c493a37a807415cc2437ccddad4bbd
Vollständiger Git-Tree dieses Commits: c17ad0263285ee4e9304908c89bf551e121c2e62
Qualifizierter Buildcommit: a0f4fd3ac69fe6cd84ea14ef3e42cfc9a44d5fe4
Dessen Tree: 2efcb146aabdbbedd3d717a888f007e91435923c
Bytegleicher web/-Subtree beider Commits: 17920de14a71fc2a07b00b644e88e6956bfe7d06
Spätere Änderungen: RELEASE_INFO.json, docs/validation/WEB3_65_0.json, docs/validation/WEB3_65_0_METADATA_CORRECTION.json, docs/validation/WEB3_65_0_METADATA_CORRECTION_evidence/DEPLOYMENT_PATH_METADATA_FIX.log, docs/validation/WEB3_65_0_METADATA_CORRECTION_evidence/FAILED_WEB_CI_JOB_137754178877.log, docs/validation/WEB3_65_0_METADATA_CORRECTION_evidence/SHA256SUMS.txt, docs/validation/WEB3_65_0_evidence/Allmiibo_Web365_Bildsender.jpg, docs/validation/WEB3_65_0_evidence/CHECKER_USED.py, docs/validation/WEB3_65_0_evidence/CI_LOG_EXCERPTS.txt, docs/validation/WEB3_65_0_evidence/CI_PORTABLE_PACKAGE_FROM_LOG.json, docs/validation/WEB3_65_0_evidence/CI_PORTABLE_VERIFICATION_FROM_LOG.json, docs/validation/WEB3_65_0_evidence/CI_SUMMARY.json, docs/validation/WEB3_65_0_evidence/CI_WINDOWS_COUNTS.json, docs/validation/WEB3_65_0_evidence/EVIDENCE_SCOPE.txt, docs/validation/WEB3_65_0_evidence/FIRMWARE_SUBSET_JOB_137725847454.log, docs/validation/WEB3_65_0_evidence/GITHUB_JOBS.json, docs/validation/WEB3_65_0_evidence/GITHUB_RUN.json, docs/validation/WEB3_65_0_evidence/HTTP_RESULTS.json, docs/validation/WEB3_65_0_evidence/HTTP_STRICT_VALIDATION.json, docs/validation/WEB3_65_0_evidence/HTTP_SUMMARY.json, docs/validation/WEB3_65_0_evidence/LIVE_WEB_UI.json, docs/validation/WEB3_65_0_evidence/PAGES_DELIVERY_MANIFEST.json, docs/validation/WEB3_65_0_evidence/PAGES_DEPLOYMENT.json, docs/validation/WEB3_65_0_evidence/PAGES_INITIAL_PUBLICATION_RECEIPT.json, docs/validation/WEB3_65_0_evidence/PAGES_RUN_45189684248.json, docs/validation/WEB3_65_0_evidence/SHA256SUMS.txt, docs/validation/WEB3_65_0_evidence/WEB_JOB_137725847614.log, docs/validation/WEB3_65_0_evidence/WEB_PUBLICATION_RECEIPT.json, docs/validation/WEB3_65_0_evidence/WINDOWS_JOB_137725846959.log, docs/validation/WEB3_65_0_evidence/demo_lcd.bin
Veröffentlichungsstatus: public
Dieser Quellcommit ist öffentlich verfügbar.
Der unveränderte Web-Produktbaum ist durch Source-CI 45184306115 am öffentlichen Commit a0f4fd3a qualifiziert. Die 30 späteren Metadatendateien dokumentieren CI-, Pages-, HTTP- und UI-Nachweise sowie die geprüfte Korrektur des UI-Quellenlinks. Geräte- und Bluetoothabnahmen sind davon getrennt.

SOURCE_MANIFEST.json nennt jeden unveränderten Git-Blob, Pfad, Modus, Größe
und SHA-256 der Auswahl. Es bindet auch diese Anleitung und den Paketbuilder.
SOURCE_ARCHIVE_BUILD.py erzeugt aus demselben Git-Commit mit identischen
Parametern dieselbe Paketstruktur. Bytegleiche ZIP-Kompression setzt dieselbe
Python-/zlib-Laufzeit voraus; diese nennt der externe Paketbaubeleg.

ARCHIV IDENTISCH NEU ERZEUGEN
Der qualifizierte Buildcommit kann ein nur lokal vorhandener historischer
Commit sein. Zum erneuten Paketbau genügt der gebundene Quellcommit im Git-Repo
zusammen mit dem unveränderten SOURCE_MANIFEST.json dieses Pakets:
  python SOURCE_ARCHIVE_BUILD.py --repo /PFAD/pixl.js --commit c18bfb4665c493a37a807415cc2437ccddad4bbd --reproduction-manifest SOURCE_MANIFEST.json --output Allmiibo_Dateimanager_3_65_0_Quellcode.zip --manifest-output SOURCE_ZIP.json
Der Builder prüft jeden ausgewählten Git-Blob, Pfad, Modus, Größe und SHA-256
sowie den identischen web/-Subtree erneut. Er übernimmt dabei die ursprüngliche
Qualifikationsidentität aus dem Manifest; dies ist eine Archivreproduktion und
keine erneut ausgeführte Qualifikation des historischen Buildcommits.

UMFANG
Vollständige Webquellen einschließlich öffentlicher historischer Testreferenzen,
Simulator-Snapshots, Firmware-Test-ZIPs, Tests und Lizenzen; zugehörige Root-/
Dokumentationsdateien und die für Webtests/Katalogexport nötigen C-/CSV-/
Pythonquellen. web/tests/dist ist Testquellcode und absichtlich enthalten.
Erzeugte web/dist-Verzeichnisse, node_modules, Git-Verwaltung und private
Workspace-Dateien sind nicht Bestandteil. Keine lokal veränderte Datei wurde
statt des unveränderlichen Git-Blobs eingesetzt.

Dieses Paket dient der Reproduktion des Webbuilds, der vollständigen Webtests
und der Offline-Katalogexporte. Es ist kein vollständiges Firmware-/Bootloader-
Buildpaket. Die fw/-Dateien stammen aus dem gebundenen Webbranch und können
historisch sein. App675-Produktion ist separat gebunden:
https://github.com/bluecyber81/pixl.js/tree/658d43a7fe2777778d8efa8439f73aa48210e033

WEB REPRODUZIEREN
Node >=22.12.0 und npm gemäß web/package.json; Python und C-Compiler für
die entsprechenden Softwaretests. Abhängigkeiten mit npm ci aus dem Lockfile:
  cd web
  npm ci
  npm test
  npm run build
  npm run build:pages
Root-/Pages-Builds führen ihre Distributionsprüfungen automatisch aus.
Der Windows-Starter benötigt Python >=3.8 und wird separat geprüft.

KATALOG
Die gebündelten CSV-/JSON-Daten und lokalen Nintendo-Overlays sind enthalten.
Die normale Website, Tests und Offline-Katalogexporte brauchen keine neuen
Nutzerdumps oder Schlüssel. Der optionale Neuaufbau der indexierten originalen
Upstream-Spielhinweise benötigt zusätzlich diese unveränderte öffentliche Datei:
https://raw.githubusercontent.com/8bitDream/AmiiboAPI/855a0ff4308278de756bed01de1eca89936f456b/database/games_info.json
SHA-256: bd100324c3d62a02759f28fa7454af35b5699ec7a87642bdb0e7a92592a228ce
Danach: node web/scripts/build-usage-reference.mjs /PFAD/games_info.json
Diese externe Voraussetzung ist auch im ursprünglichen Git-Tree nicht enthalten;
web/third-party/amiiboapi/SOURCE.txt dokumentiert sie. Nicht blind auf dev wechseln.

Die drei SOURCE_*-Dateien wurden für das Archiv erzeugt und sind ausdrücklich
keine Dateien des ursprünglichen Quellcommits. Der endgültige ZIP-Hash wird
außerhalb des ZIPs im Downloadmanifest geführt.
