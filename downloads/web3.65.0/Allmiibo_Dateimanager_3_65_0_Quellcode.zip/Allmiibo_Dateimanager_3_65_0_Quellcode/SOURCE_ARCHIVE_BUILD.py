#!/usr/bin/env python3
"""Create the reviewed Web3.65 source selection from immutable Git blobs.

The package covers the Web build/tests and catalogue exporters, not a complete
firmware/bootloader build. No working-tree files or private workspace data enter
the archive. The qualified runtime commit and later metadata commit stay distinct.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import platform
import stat
import subprocess
import zipfile
import zlib


PREFIX = "Allmiibo_Dateimanager_3_65_0_Quellcode/"
DIRECTORIES = ["web/", "docs/", "LICENSES/", "assets/", "fw/application/",
    "fw/components/chameleon-ultra/firmware/application/src/rfid/nfctag/"]
EXACT_FILES = [".gitattributes", "LICENSE", "THIRD_PARTY_NOTICES.md", "README.md", "README.de.md",
    "README.upstream.md", "RELEASE_INFO.json", "RELEASE_NOTES_DE.md", "RELEASE_NOTES_EN.md",
    "CONTRIBUTING.md", "CHANGELOG_DE3_SERIES.md", "fw/scripts/amiibo_db_gen.py",
    "fw/scripts/amiibo_db_validate.py", "fw/scripts/amiibo_usage_export.py", "fw/scripts/LICENSE",
    "fw/bootloader/src/dfu_public_key.c", "fw/components/chameleon-ultra/LICENSE", "tools/check_readme_downloads.py"]
GENERATED_DIRECTORIES = ["web/node_modules/", "web/dist/", "web/dist-pages/", "web/dist-test-app670/"]
PINNED_GAME_INFO_SHA = "bd100324c3d62a02759f28fa7454af35b5699ec7a87642bdb0e7a92592a228ce"
PINNED_GAME_INFO_URL = "https://raw.githubusercontent.com/8bitDream/AmiiboAPI/855a0ff4308278de756bed01de1eca89936f456b/database/games_info.json"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode()


def git(repo, *items):
    return subprocess.check_output(["git", *items], cwd=repo)


def selected(path):
    if path.startswith(tuple(GENERATED_DIRECTORIES)):
        return False
    return path in EXACT_FILES or path.startswith(tuple(DIRECTORIES)) or (
        PurePosixPath(path).parent.as_posix() == "fw/data" and path.endswith(".csv"))


def metadata_allowlist(overrides, expected):
    explicit = sorted(set(["RELEASE_INFO.json", *(overrides or [])]))
    approved = expected["approvedMetadataDeltaPaths"] if expected is not None else explicit
    assert isinstance(approved, list) and all(isinstance(path, str) for path in approved)
    assert approved == sorted(set(approved)) and "RELEASE_INFO.json" in approved
    for path in approved:
        relative = PurePosixPath(path)
        assert str(relative) == path and not relative.is_absolute() and ".." not in relative.parts
        assert "\\" not in path and (path == "RELEASE_INFO.json" or path.startswith("docs/validation/")), path
    if expected is not None and overrides is not None:
        assert approved == explicit, "Explicit metadata allowance differs from the original archive manifest"
    return approved


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--commit", required=True, help="The immutable Web source commit, including an unpublished local commit")
    parser.add_argument("--publication-status", choices=["local-unpublished", "public"])
    parser.add_argument("--publication-note")
    parser.add_argument("--qualified-build-commit")
    parser.add_argument("--reproduction-manifest", type=Path,
        help="An existing SOURCE_MANIFEST.json; permits exact archive reproduction when the original qualification commit is local-only")
    parser.add_argument("--allow-metadata-delta", action="append",
        help="An individually reviewed docs/validation path; RELEASE_INFO.json is always allowed")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--manifest-output", type=Path, required=True)
    args = parser.parse_args()
    if not __debug__:
        raise RuntimeError("Optimized Python is not permitted: all source and archive integrity checks must remain enabled")
    expected = json.loads(args.reproduction_manifest.read_bytes()) if args.reproduction_manifest else None
    approved_metadata = metadata_allowlist(args.allow_metadata_delta, expected)
    args.publication_status = args.publication_status or (expected["publicationStatus"] if expected else "local-unpublished")
    args.publication_note = args.publication_note if args.publication_note is not None else (expected["publicationNote"] if expected else "")
    commit = git(args.repo, "rev-parse", args.commit + "^{commit}").decode().strip()
    tree = git(args.repo, "rev-parse", commit + "^{tree}").decode().strip()
    web_tree = git(args.repo, "rev-parse", commit + ":web").decode().strip()
    if expected is None:
        if not args.qualified_build_commit:
            parser.error("--qualified-build-commit is required unless --reproduction-manifest is supplied")
        qualified = git(args.repo, "rev-parse", args.qualified_build_commit + "^{commit}").decode().strip()
        qualified_tree = git(args.repo, "rev-parse", qualified + "^{tree}").decode().strip()
        qualified_web_tree = git(args.repo, "rev-parse", qualified + ":web").decode().strip()
        changes = git(args.repo, "diff", "--name-only", "-z", qualified, commit).decode().split("\0")[:-1]
        qualification_mode = "direct-git-comparison"
    else:
        assert expected["sourceCommit"] == commit and expected["sourceTree"] == tree
        assert expected["sourceWebSubtree"] == web_tree
        assert expected["publicationStatus"] == args.publication_status and expected["publicationNote"] == args.publication_note
        qualified = expected["qualifiedBuildCommit"]
        qualified_tree = expected["qualifiedBuildTree"]
        qualified_web_tree = expected["qualifiedWebSubtree"]
        assert args.qualified_build_commit is None or args.qualified_build_commit == qualified
        for identity in [qualified, qualified_tree, qualified_web_tree]:
            assert len(identity) == 40 and all(c in "0123456789abcdef" for c in identity)
        changes = expected["metadataChangesAfterQualifiedBuild"]
        qualification_mode = "existing-manifest-bound-archive-reproduction-not-new-qualification"
    assert web_tree == qualified_web_tree, "The Web runtime subtree differs from the qualified build"
    assert set(changes) <= set(approved_metadata), f"Unexpected runtime/source changes since the qualified build: {changes}"
    entries = []
    all_files = []
    for record in git(args.repo, "ls-tree", "-rz", "--full-tree", commit).split(b"\0"):
        if not record:
            continue
        identity, raw_name = record.split(b"\t", 1)
        mode, kind, blob = identity.decode().split()
        name = raw_name.decode()
        all_files.append(name)
        if not selected(name):
            continue
        path = PurePosixPath(name)
        assert not path.is_absolute() and ".." not in path.parts and "\\" not in name
        assert kind == "blob" and mode in ["100644", "100755"], (name, kind, mode)
        assert not ({"node_modules", ".git", "Private_Geraetedaten", "private_dumps"} & set(path.parts)), name
        entries.append({"path": name, "mode": mode, "gitBlob": blob})
    assert all(path in all_files for path in EXACT_FILES)
    assert any(item["path"] == "web/tests/dist/static-deployment.test.mjs" for item in entries)
    assert any(item["path"] == "web/.env" for item in entries)
    batch = subprocess.run(["git", "cat-file", "--batch"], cwd=args.repo,
        input=("\n".join(item["gitBlob"] for item in entries) + "\n").encode(),
        check=True, stdout=subprocess.PIPE).stdout
    offset, payload = 0, {}
    for item in entries:
        end = batch.index(b"\n", offset)
        blob, kind, size = batch[offset:end].decode().split()
        size = int(size)
        data = batch[end + 1:end + 1 + size]
        offset = end + 1 + size + 1
        assert blob == item["gitBlob"] and kind == "blob" and len(data) == size
        assert hashlib.sha1(b"blob " + str(size).encode() + b"\0" + data).hexdigest() == blob
        item.update(bytes=size, sha256=sha(data))
        payload[item["path"]] = data
    assert offset == len(batch)
    assert json.loads(payload["web/package.json"])["version"] == "3.65.0"
    assert payload["web/.env"].decode().strip() == 'VITE_BUILD_LABEL="LCD DE3.102 / App675"'
    source_url = "https://github.com/bluecyber81/pixl.js/tree/" + commit if args.publication_status == "public" else None
    provenance_title = "Öffentlicher Web-Quellcommit" if source_url else "Lokaler, unveröffentlichter Web-Quellcommit"
    provenance_note = ("Dieser Quellcommit ist öffentlich verfügbar." if source_url else
        "Dieser Quellcommit ist NICHT veröffentlicht. Für ihn wird keine öffentliche GitHub-URL behauptet.\n"
        "Website, GitHub-Release und Downloadlinks in unveränderten Quelldokumenten können geplante Ziele\n"
        "oder ältere Stände nennen; sie belegen keine Veröffentlichung von Web3.65.0.")
    instructions = f"""ALLMIIBO DATEIMANAGER 3.65.0 – GEPRÜFTE WEB-QUELLENAUSWAHL

{provenance_title}: {commit}
Vollständiger Git-Tree dieses Commits: {tree}
Qualifizierter Buildcommit: {qualified}
Dessen Tree: {qualified_tree}
Bytegleicher web/-Subtree beider Commits: {web_tree}
Spätere Änderungen: {', '.join(changes) if changes else 'keine'}
Veröffentlichungsstatus: {args.publication_status}
{provenance_note}
{args.publication_note}

SOURCE_MANIFEST.json nennt jeden unveränderten Git-Blob, Pfad, Modus, Größe
und SHA-256 der Auswahl. Es bindet auch diese Anleitung und den Paketbuilder.
SOURCE_ARCHIVE_BUILD.py erzeugt aus demselben Git-Commit mit identischen
Parametern dieselbe Paketstruktur. Bytegleiche ZIP-Kompression setzt dieselbe
Python-/zlib-Laufzeit voraus; diese nennt der externe Paketbaubeleg.

ARCHIV IDENTISCH NEU ERZEUGEN
Der qualifizierte Buildcommit kann ein nur lokal vorhandener historischer
Commit sein. Zum erneuten Paketbau genügt der gebundene Quellcommit im Git-Repo
zusammen mit dem unveränderten SOURCE_MANIFEST.json dieses Pakets:
  python SOURCE_ARCHIVE_BUILD.py --repo /PFAD/pixl.js --commit {commit} --reproduction-manifest SOURCE_MANIFEST.json --output Allmiibo_Dateimanager_3_65_0_Quellcode.zip --manifest-output SOURCE_ZIP.json
Der Builder prüft jeden ausgewählten Git-Blob, Pfad, Modus, Größe und SHA-256
sowie den identischen web/-Subtree erneut. Er übernimmt dabei die ursprüngliche
Qualifikationsidentität aus dem Manifest; dies ist eine Archivreproduktion und
keine erneut ausgeführte Qualifikation des historischen Buildcommits.

UMFANG
Vollständige Webquellen einschließlich öffentlicher historischer Testreferenzen,
Simulator-Snapshots, Firmware-Test-ZIPs, Tests und Lizenzen; zugehörige Root-/
Dokumentationsdateien und die für Webtests/Katalogexport nötigen C-/CSV-/
Pythonquellen. web/tests/dist ist Testquellcode und absichtlich enthalten.
Erzeugte web/dist-Verzeichnisse, node_modules, Git-Verwaltung und private
Workspace-Dateien sind nicht Bestandteil. Keine lokal veränderte Datei wurde
statt des unveränderlichen Git-Blobs eingesetzt.

Dieses Paket dient der Reproduktion des Webbuilds, der vollständigen Webtests
und der Offline-Katalogexporte. Es ist kein vollständiges Firmware-/Bootloader-
Buildpaket. Die fw/-Dateien stammen aus dem gebundenen Webbranch und können
historisch sein. App675-Produktion ist separat gebunden:
https://github.com/bluecyber81/pixl.js/tree/658d43a7fe2777778d8efa8439f73aa48210e033

WEB REPRODUZIEREN
Node >=22.12.0 und npm gemäß web/package.json; Python und C-Compiler für
die entsprechenden Softwaretests. Abhängigkeiten mit npm ci aus dem Lockfile:
  cd web
  npm ci
  npm test
  npm run build
  npm run build:pages
Root-/Pages-Builds führen ihre Distributionsprüfungen automatisch aus.
Der Windows-Starter benötigt Python >=3.8 und wird separat geprüft.

KATALOG
Die gebündelten CSV-/JSON-Daten und lokalen Nintendo-Overlays sind enthalten.
Die normale Website, Tests und Offline-Katalogexporte brauchen keine neuen
Nutzerdumps oder Schlüssel. Der optionale Neuaufbau der indexierten originalen
Upstream-Spielhinweise benötigt zusätzlich diese unveränderte öffentliche Datei:
{PINNED_GAME_INFO_URL}
SHA-256: {PINNED_GAME_INFO_SHA}
Danach: node web/scripts/build-usage-reference.mjs /PFAD/games_info.json
Diese externe Voraussetzung ist auch im ursprünglichen Git-Tree nicht enthalten;
web/third-party/amiiboapi/SOURCE.txt dokumentiert sie. Nicht blind auf dev wechseln.

Die drei SOURCE_*-Dateien wurden für das Archiv erzeugt und sind ausdrücklich
keine Dateien des ursprünglichen Quellcommits. Der endgültige ZIP-Hash wird
außerhalb des ZIPs im Downloadmanifest geführt.
""".encode()
    payload["SOURCE_README.txt"] = instructions
    payload["SOURCE_ARCHIVE_BUILD.py"] = Path(__file__).read_bytes()
    manifest = {"schema": 1, "application": "Allmiibo Dateimanager", "version": "3.65.0",
        "sourceCommit": commit, "sourceTree": tree,
        "sourceUrl": source_url, "publicationStatus": args.publication_status,
        "publicationNote": args.publication_note,
        "qualifiedBuildCommit": qualified, "qualifiedBuildTree": qualified_tree,
        "sourceWebSubtree": web_tree, "qualifiedWebSubtree": qualified_web_tree,
        "approvedMetadataDeltaPaths": approved_metadata,
        "metadataChangesAfterQualifiedBuild": changes,
        "selection": {"directories": DIRECTORIES, "files": EXACT_FILES, "additionalRule": "fw/data/*.csv on that directory level",
            "excludedGeneratedDirectories": GENERATED_DIRECTORIES,
            "scope": "Web build, full Web tests, catalogue exporters and public licensing; not a full firmware build"},
        "trackedFiles": entries, "trackedFileCount": len(entries), "trackedBytes": sum(item["bytes"] for item in entries),
        "generatedFiles": {name: {"bytes": len(payload[name]), "sha256": sha(payload[name])}
            for name in ["SOURCE_README.txt", "SOURCE_ARCHIVE_BUILD.py"]},
        "manifestSelfHashExcluded": True,
        "optionalExternalInput": {"url": PINNED_GAME_INFO_URL, "sha256": PINNED_GAME_INFO_SHA,
            "purpose": "Rebuild the indexed original AmiiboAPI game-note reference", "embedded": False}}
    payload["SOURCE_MANIFEST.json"] = encoded(manifest)
    if expected is not None:
        assert manifest == expected, "The reproduced source selection, generated files or provenance differ from the original manifest"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    modes = {item["path"]: int(item["mode"], 8) for item in entries}
    with zipfile.ZipFile(args.output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(payload.items()):
            info = zipfile.ZipInfo(PREFIX + name, (2026, 11, 23, 0, 0, 0))
            info.create_system = 3
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = modes.get(name, stat.S_IFREG | (0o755 if name.endswith("_BUILD.py") else 0o644)) << 16
            archive.writestr(info, data, compresslevel=9)
    with zipfile.ZipFile(args.output) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist()) == len(payload)
        for name, data in payload.items():
            assert archive.read(PREFIX + name) == data, name
    archive_data = args.output.read_bytes()
    summary = {"schema": 1, "filename": args.output.name, "bytes": len(archive_data), "sha256": sha(archive_data),
        "files": len(payload), "sourceCommit": commit, "sourceTree": tree,
        "sourceUrl": source_url, "publicationStatus": args.publication_status,
        "publicationNote": args.publication_note,
        "qualifiedBuildCommit": qualified, "qualifiedBuildTree": qualified_tree,
        "sourceWebSubtree": web_tree, "qualifiedWebSubtree": qualified_web_tree,
        "approvedMetadataDeltaPaths": approved_metadata,
        "metadataChangesAfterQualifiedBuild": changes, "trackedFiles": len(entries),
        "trackedBytes": manifest["trackedBytes"], "archiveCrcAndAllBytesVerified": True,
        "qualificationVerificationMode": qualification_mode,
        "sourceManifestSha256": sha(payload["SOURCE_MANIFEST.json"]), "builderSha256": sha(payload["SOURCE_ARCHIVE_BUILD.py"]),
        "compressionRuntime": {"python": platform.python_version(), "implementation": platform.python_implementation(),
            "zlibCompileVersion": zlib.ZLIB_VERSION, "zlibRuntimeVersion": zlib.ZLIB_RUNTIME_VERSION,
            "compression": "deflate", "level": 9, "zipCreateSystem": 3}}
    args.manifest_output.parent.mkdir(parents=True, exist_ok=True)
    args.manifest_output.write_bytes(encoded(summary))
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()
