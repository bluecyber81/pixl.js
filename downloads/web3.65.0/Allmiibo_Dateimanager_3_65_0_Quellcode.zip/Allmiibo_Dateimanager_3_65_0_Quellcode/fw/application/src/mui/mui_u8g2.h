#ifndef MUI_U8G2_H
#define MUI_U8G2_H

#include <stdbool.h>
#include "sdk_errors.h"

#include "mui_defines.h"
#include "hal_spi_bus.h"
#include "u8g2.h"

void mui_u8g2_init(u8g2_t* p_u8g2);
void mui_u8g2_deinit(u8g2_t* p_u8g2);

void mui_u8g2_set_backlight(uint8_t bl);
uint8_t mui_u8g2_get_backlight();

ret_code_t mui_u8g2_set_backlight_level(uint8_t bl);
int8_t mui_u8g2_get_backlight_level(void);
/* Temporary preview: suspends auto-dim without changing persisted settings.
 * Restore retries in foreground if the PWM SDK is temporarily busy. */
ret_code_t mui_u8g2_backlight_preview(uint8_t level);
ret_code_t mui_u8g2_backlight_restore(void);
void mui_u8g2_poll_dim(bool before_sleep);
void mui_u8g2_set_lcd_default_contrast_level(void);

void mui_u8g2_set_contrast_level(uint8_t value);
void mui_u8g2_set_flip_display(bool flip);

spi_device_t* mui_u8g2_get_spi_device();

#endif
