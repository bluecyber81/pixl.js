#include "mui_canvas.h"

void mui_canvas_flush(mui_canvas_t *p_canvas) { u8g2_SendBuffer(p_canvas->fb); }

void mui_canvas_clear(mui_canvas_t *p_canvas) { u8g2_ClearBuffer(p_canvas->fb); }

void mui_canvas_set_font(mui_canvas_t *p_canvas, const uint8_t *font) { u8g2_SetFont(p_canvas->fb, font); }

uint8_t mui_canvas_get_utf8_bytes(const char *p) {
    if (!p || !*p) return 0;
    const uint8_t *bytes = (const uint8_t *)p;
    uint8_t lead = bytes[0];
    uint8_t length;
    if (lead < 0x80) return 1;
    if (lead >= 0xC2 && lead <= 0xDF) length = 2;
    else if (lead >= 0xE0 && lead <= 0xEF) length = 3;
    else if (lead >= 0xF0 && lead <= 0xF4) length = 4;
    else return 1;

    /* Check each byte before advancing: a filename can end in an incomplete
     * sequence. Invalid bytes consume one byte so every text walker progresses
     * without copying beyond the terminating NUL. */
    for (uint8_t i = 1; i < length; ++i) {
        if ((bytes[i] & 0xC0) != 0x80) return 1;
    }
    if ((lead == 0xE0 && bytes[1] < 0xA0) ||
        (lead == 0xED && bytes[1] >= 0xA0) ||
        (lead == 0xF0 && bytes[1] < 0x90) ||
        (lead == 0xF4 && bytes[1] >= 0x90)) return 1;
    return length;
}

uint8_t mui_canvas_draw_utf8(mui_canvas_t *p_canvas, uint8_t x, uint8_t y, const char *str) {
    if (!str) return 0;
    x += p_canvas->offset_x;
    y += p_canvas->offset_y;
    return u8g2_DrawUTF8(p_canvas->fb, x, y, str);
}

int32_t mui_canvas_draw_utf8_clip(mui_canvas_t *p_canvas, int32_t x, int32_t y, const char *text) {
    int32_t xi = x;
    int32_t yi = y;
    int32_t w = 0;

    const char *p = text;
    char utf8[5];

    while (*p != 0) {
        uint8_t utf8_size = mui_canvas_get_utf8_bytes(p);
        memcpy(utf8, p, utf8_size);
        utf8[utf8_size] = '\0';
        if (xi >= 0 && xi <= p_canvas->width) {
            uint8_t utf8_w = mui_canvas_draw_utf8(p_canvas, xi, yi, utf8);
            xi += utf8_w;
            w += utf8_w;
        } else {
            uint8_t utf8_x = mui_canvas_get_utf8_width(p_canvas, utf8);
            xi += utf8_x + 1; // 1 pix for margin
            w += utf8_x + 1;
        }
        p += utf8_size;
    }

    return w;
}

uint8_t mui_canvas_draw_glyph(mui_canvas_t *p_canvas, uint8_t x, uint8_t y, uint16_t encoding) {
    x += p_canvas->offset_x;
    y += p_canvas->offset_y;
    return u8g2_DrawGlyph(p_canvas->fb, x, y, encoding);
}

uint16_t mui_canvas_draw_utf8_truncate(mui_canvas_t* p_canvas, uint8_t x, uint8_t y, uint8_t max_width, const char *str) {
    const char *p = str;
    char utf8[5];

    if (max_width < mui_canvas_get_utf8_width(p_canvas, str)) {
        while (*p != 0) {
            uint8_t utf8_size = mui_canvas_get_utf8_bytes(p);
            memcpy(utf8, p, utf8_size);
            utf8[utf8_size] = '\0';
            if (x >= 0 && x <= max_width - 8) {
                uint8_t utf8_w = mui_canvas_draw_utf8(p_canvas, x, y, utf8);
                x += utf8_w;
            } else {
                const uint8_t *font = u8g2_GetFont(p_canvas->fb);
                u8g2_SetFont(p_canvas->fb, u8g2_font_siji_t_6x10);
                uint8_t utf8_w = mui_canvas_draw_glyph(p_canvas, x, y - 1, 0xe21f);
                u8g2_SetFont(p_canvas->fb, font);
                x += utf8_w + 1;

                break;
            }
            p += utf8_size;
        }
    } else {
        x = mui_canvas_draw_utf8(p_canvas, x, y, str) + 1;
    }

    return x;
}

uint16_t mui_canvas_get_utf8_width(mui_canvas_t *p_canvas, const char *s) { return u8g2_GetUTF8Width(p_canvas->fb, s); }

/* Unlike visual string width, glyph advance includes the space before the
 * next glyph. Use the same decoder and delta values as u8g2_DrawUTF8. */
uint16_t mui_canvas_get_utf8_advance(mui_canvas_t *p_canvas, const char *text) {
    if (!text) return 0;
    u8x8_t *u8x8 = u8g2_GetU8x8(p_canvas->fb);
    u8x8_utf8_init(u8x8);
    uint32_t width = 0;
    for (;;) {
        uint16_t encoding = u8x8_utf8_next(u8x8, (uint8_t)*text++);
        if (encoding == 0xffff) break;
        if (encoding != 0xfffe) {
            int8_t advance = u8g2_GetGlyphWidth(p_canvas->fb, encoding);
            if (advance > 0) width += (uint8_t)advance;
            if (width >= UINT16_MAX) return UINT16_MAX;
        }
    }
    return width;
}

uint8_t mui_canvas_current_font_ascent(mui_canvas_t *p_canvas) {
    /* Use the complete font box, including accented glyphs. */
    return p_canvas->fb->font_info.max_char_height + p_canvas->fb->font_info.y_offset;
}

void mui_canvas_set_frame(mui_canvas_t *p_canvas, uint8_t offset_x, uint8_t offset_y, uint8_t width, uint8_t height) {
    p_canvas->offset_x = offset_x;
    p_canvas->offset_y = offset_y;
    p_canvas->width = width;
    p_canvas->height = height;
    u8g2_SetClipWindow(p_canvas->fb, offset_x, offset_y, offset_x + width, offset_y + height);
}

void mui_canvas_get_clip_window(mui_canvas_t *p_canvas, mui_rect_t *p_rect) {
    p_rect->x = p_canvas->fb->clip_x0 - p_canvas->offset_x;
    p_rect->y = p_canvas->fb->clip_y0 - p_canvas->offset_y;
    p_rect->w = p_canvas->fb->clip_x1 - p_canvas->fb->clip_x0;
    p_rect->h = p_canvas->fb->clip_y1 - p_canvas->fb->clip_y0;
}
void mui_canvas_set_clip_window(mui_canvas_t *p_canvas, mui_rect_t *p_rect) {
    u8g2_SetClipWindow(p_canvas->fb, p_rect->x + p_canvas->offset_x, p_rect->y + p_canvas->offset_y,
                       p_rect->x + p_canvas->offset_x + p_rect->w,
                       p_rect->y + p_canvas->offset_y + p_rect->h);
}

uint8_t mui_canvas_get_draw_color(mui_canvas_t *p_canvas) { return u8g2_GetDrawColor(p_canvas->fb); }
void mui_canvas_set_draw_color(mui_canvas_t *p_canvas, uint8_t color) { u8g2_SetDrawColor(p_canvas->fb, color); }

void mui_canvas_draw_box(mui_canvas_t *p_canvas, uint8_t x, uint8_t y, uint8_t w, uint8_t h) {
    x += p_canvas->offset_x;
    y += p_canvas->offset_y;
    u8g2_DrawBox(p_canvas->fb, x, y, w, h);
}

void mui_canvas_draw_rbox(mui_canvas_t *p_canvas, uint8_t x, uint8_t y, uint8_t w, uint8_t h, uint8_t radius) {
    x += p_canvas->offset_x;
    y += p_canvas->offset_y;
    u8g2_DrawRBox(p_canvas->fb, x, y, w, h, radius);
}

void mui_canvas_draw_dot(mui_canvas_t *p_canvas, uint8_t x, uint8_t y) {
    x += p_canvas->offset_x;
    y += p_canvas->offset_y;
    u8g2_DrawPixel(p_canvas->fb, x, y);
}

void mui_canvas_draw_rframe(mui_canvas_t *p_canvas, uint8_t x, uint8_t y, uint8_t width, uint8_t height,
                            uint8_t radius) {
    x += p_canvas->offset_x;
    y += p_canvas->offset_y;
    u8g2_DrawRFrame(p_canvas->fb, x, y, width, height, radius);
}

void mui_canvas_draw_xbm(mui_canvas_t *p_canvas, uint8_t x, uint8_t y, uint8_t width, uint8_t height, const uint8_t *bitmap) {
    x += p_canvas->offset_x;
    y += p_canvas->offset_y;
    u8g2_DrawXBM(p_canvas->fb, x, y, width, height, bitmap);
}

void mui_canvas_draw_bitmap(mui_canvas_t *p_canvas, uint8_t x, uint8_t y, uint8_t width, uint8_t height,
                            const uint8_t *bitmap) {
    x += p_canvas->offset_x;
    y += p_canvas->offset_y;
    u8g2_DrawBitmap(p_canvas->fb, x, y, width, height, bitmap);
}

uint16_t mui_canvas_string_width(mui_canvas_t *p_canvas, const char *str) {
    if (!str) return 0;
    return u8g2_GetStrWidth(p_canvas->fb, str);
}

uint8_t mui_canvas_get_width(mui_canvas_t *p_canvas) { return p_canvas->width; }

uint8_t mui_canvas_get_height(mui_canvas_t *p_canvas) { return p_canvas->height; }

uint8_t mui_canvas_current_font_height(mui_canvas_t *p_canvas) { return u8g2_GetMaxCharHeight(p_canvas->fb); }

void mui_canvas_invert_color(mui_canvas_t *p_canvas) { p_canvas->fb->draw_color = !p_canvas->fb->draw_color; }

void mui_canvas_draw_line(mui_canvas_t *p_canvas, uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2) {
    x1 += p_canvas->offset_x;
    y1 += p_canvas->offset_y;
    x2 += p_canvas->offset_x;
    y2 += p_canvas->offset_y;
    u8g2_DrawLine(p_canvas->fb, x1, y1, x2, y2);
}
