/**
 * Copyright (c) 2014 - 2020, Nordic Semiconductor ASA
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form, except as embedded into a Nordic
 *    Semiconductor ASA integrated circuit in a product or a software update for
 *    such product, must reproduce the above copyright notice, this list of
 *    conditions and the following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. Neither the name of Nordic Semiconductor ASA nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * 4. This software, with or without modification, must only be used with a
 *    Nordic Semiconductor ASA integrated circuit.
 *
 * 5. Any software provided in binary form under this license must not be reverse
 *    engineered, decompiled, modified and/or disassembled.
 *
 * THIS SOFTWARE IS PROVIDED BY NORDIC SEMICONDUCTOR ASA "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NORDIC SEMICONDUCTOR ASA OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
/** @file
 *
 * @defgroup ble_sdk_uart_over_ble_main main.c
 * @{
 * @ingroup  ble_sdk_app_nus_eval
 * @brief    UART over BLE application main file.
 *
 * This file contains the source code for a sample application that uses the Nordic UART service.
 * This application uses the @ref srvlib_conn_params module.
 */

#include "app_timer.h"
#include "app_uart.h"
#include "app_util_platform.h"
#include "ble_advdata.h"
#include "ble_advertising.h"
#include "ble_conn_params.h"
#include "ble_conn_state.h"
#include "ble_hci.h"
#include "ble_nus.h"
#include "bsp_btn_ble.h"
#include "nordic_common.h"
#include "nrf.h"
#include "nrf_ble_gatt.h"
#include "nrf_ble_qwr.h"
#include "nrf_pwr_mgmt.h"
#include "nrf_sdh.h"
#include "nrf_sdh_ble.h"
#include "nrf_sdh_soc.h"
#include <stdint.h>
#include <string.h>

#if defined(UART_PRESENT)
#include "nrf_uart.h"
#endif
#if defined(UARTE_PRESENT)
#include "nrf_uarte.h"
#endif

#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"

#include "ble_amiibolink.h"
#include "ble_df_driver.h"
#include "ble_main.h"
#include "ble_work.h"
#include "ble_remote.h"
#include "../runtime_diag.h"

#if MAX_MTU_DAT_SIZE != BLE_WORK_DATA_SIZE
#error "BLE work buffer must match the negotiated maximum NUS payload"
#endif
#include "df_core.h"
#include "nrf_pwr_mgmt.h"

#include "app_scheduler.h"

#define APP_BLE_CONN_CFG_TAG 1 /**< A tag identifying the SoftDevice BLE configuration. */

#define NUS_SERVICE_UUID_TYPE                                                                                          \
    BLE_UUID_TYPE_VENDOR_BEGIN /**< UUID type for the Nordic UART Service (vendor specific). */

#define APP_BLE_OBSERVER_PRIO 3 /**< Application's BLE observer priority. You shouldn't need to modify this value. */

#define APP_ADV_INTERVAL 64 /**< The advertising interval (in units of 0.625 ms. This value corresponds to 40 ms). */

#define APP_ADV_DURATION 18000 /**< The advertising duration (180 seconds) in units of 10 milliseconds. */

#define MIN_CONN_INTERVAL                                                                                              \
    MSEC_TO_UNITS(                                                                                                     \
        20,                                                                                                            \
        UNIT_1_25_MS) /**< Minimum acceptable connection interval (20 ms), Connection interval uses 1.25 ms units. */
#define MAX_CONN_INTERVAL                                                                                              \
    MSEC_TO_UNITS(                                                                                                     \
        75,                                                                                                            \
        UNIT_1_25_MS)   /**< Maximum acceptable connection interval (75 ms), Connection interval uses 1.25 ms units. */
#define SLAVE_LATENCY 0 /**< Slave latency. */
#define CONN_SUP_TIMEOUT                                                                                               \
    MSEC_TO_UNITS(                                                                                                     \
        4000, UNIT_10_MS) /**< Connection supervisory timeout (4 seconds), Supervision Timeout uses 10 ms units. */
#define FIRST_CONN_PARAMS_UPDATE_DELAY                                                                                 \
    APP_TIMER_TICKS(5000) /**< Time from initiating event (connect or start of notification) to first time             \
                             sd_ble_gap_conn_param_update is called (5 seconds). */
#define NEXT_CONN_PARAMS_UPDATE_DELAY                                                                                  \
    APP_TIMER_TICKS(                                                                                                   \
        30000) /**< Time between each call to sd_ble_gap_conn_param_update after the first call (30 seconds). */
#define MAX_CONN_PARAMS_UPDATE_COUNT                                                                                   \
    3 /**< Number of attempts before giving up the connection parameter negotiation.                                   \
       */

#define DEAD_BEEF                                                                                                      \
    0xDEADBEEF /**< Value used as error code on stack dump, can be used to identify stack location on stack unwind. */



BLE_NUS_DEF(m_nus, NRF_SDH_BLE_TOTAL_LINK_COUNT); /**< BLE NUS service instance. */
NRF_BLE_GATT_DEF(m_gatt);                         /**< GATT module instance. */
NRF_BLE_QWR_DEF(m_qwr);                           /**< Context for the Queued Write module.*/
BLE_ADVERTISING_DEF(m_advertising);               /**< Advertising module instance. */

static volatile uint16_t m_conn_handle = BLE_CONN_HANDLE_INVALID; /**< Shared with the BLE observer IRQ. */
/* A host may retain its GAP link after the browser has closed its GATT
 * session. Notification subscription, not the physical handle, owns a file
 * protocol session. Never invent a GAP disconnect or restart services here. */
static volatile uint16_t m_nus_session_handle = BLE_CONN_HANDLE_INVALID;
static volatile uint16_t m_release_handle = BLE_CONN_HANDLE_INVALID;
static volatile uint32_t m_link_generation, m_release_generation;
static volatile bool m_release_attempted, m_release_requested;
static volatile bool m_file_mode = true;
static volatile bool m_remote_mode;
static volatile uint32_t m_session_generation;
static volatile bool m_timeout_overridden;
static bool m_mode_pending, m_mode_adv_requested, m_mode_handlers_ready, m_mode_stop_requested;
static bool m_mode_wait_reply;
static uint32_t m_mode_wait_tick;
static ble_device_mode_t m_pending_mode;
static nus_rx_data_handler_t m_pending_rx;
static nus_tx_ready_handler_t m_pending_tx;
/* 1: committed remote ACK, UI pending; 2: file UI adopted this exact link. */
static uint8_t m_file_link_handoff;
static uint32_t m_file_link_generation;
static void ble_pending_mode_poll(void);
static void ble_stop_transport(void);
static void ble_file_link_poll(void);
static volatile bool m_sessions_enabled;
/* Bound only initial file-client discovery. An established NUS session has
 * no idle deadline. RTC subtraction handles its 24-bit counter wrapping. */
static volatile bool m_file_join_pending;
static volatile uint32_t m_file_join_tick, m_file_join_generation;
#define BLE_FILE_JOIN_TIMEOUT_TICKS APP_TIMER_TICKS(30000)
static uint16_t m_ble_nus_max_data_len =
    BLE_GATT_ATT_MTU_DEFAULT -
    3; /**< Maximum length of data (in bytes) that can be transmitted to the peer by the Nordic UART service module. */
static ble_uuid_t m_adv_uuids[] = /**< Universally unique service identifier. */
    {{BLE_UUID_NUS_SERVICE, NUS_SERVICE_UUID_TYPE}};

#define DEVICE_NAME_PIXLJS "Pixl.js"
#define DEVICE_NAME_REMOTE "Pixl.Remote"
#define DEVICE_NAME_AMIIBOLINK "amiibolink"
#define DEVICE_NAME_AMILOOP "AmiLoop"

#define DEVICE_NAME DEVICE_NAME_PIXLJS

static ble_gap_addr_t m_default_gap_addr = {0};
static uint8_t m_remote_init_phase;
static uint32_t m_remote_init_result;

uint8_t ble_remote_init_phase(void) { return m_remote_init_phase; }
uint32_t ble_remote_init_result(void) { return m_remote_init_result; }
static ret_code_t remote_init_step(uint8_t phase, ret_code_t result) {
    m_remote_init_phase = phase;
    m_remote_init_result = result;
    return result;
}

static uint8_t m_ble_initialized = false;
/* Advertising mode can remain FAST after a link opens. Track actual SDK
 * start/idle events instead; never infer visibility from the UI screen. */
static volatile bool m_advertising_active;
static uint8_t m_reported_link_state;
static ble_link_state_handler_t m_link_state_handler;
static uint8_t m_reported_status_state;
static ble_link_state_handler_t m_status_state_handler;

#define BLE_CONNECT_SLEEP_TIMEOUT_SECONDS 180 /**< Sleep timeout when ble connection established. */
uint16_t m_previous_pwr_mgmt_sleep_timeout = BLE_CONNECT_SLEEP_TIMEOUT_SECONDS;

/**@brief Function for assert macro callback.
 *
 * @details This function will be called in case of an assert in the SoftDevice.
 *
 * @warning This handler is an example only and does not fit a final product. You need to analyse
 *          how your product is supposed to react in case of Assert.
 * @warning On assert from the SoftDevice, the system can only recover on reset.
 *
 * @param[in] line_num    Line number of the failing ASSERT call.
 * @param[in] p_file_name File name of the failing ASSERT call.
 */
void assert_nrf_callback(uint16_t line_num, const uint8_t *p_file_name) {
    app_error_handler(DEAD_BEEF, line_num, p_file_name);
}

/**@brief Function for initializing the timer module.
 */
static void timers_init(void) {
    ret_code_t err_code = app_timer_init();
    APP_ERROR_CHECK(err_code);
}

/**@brief Function for the GAP initialization.
 *
 * @details This function will set up all the necessary GAP (Generic Access Profile) parameters of
 *          the device. It also sets the permissions and appearance.
 */
static void gap_params_init(void) {
    uint32_t err_code;
    ble_gap_conn_params_t gap_conn_params;
    ble_gap_conn_sec_mode_t sec_mode;

    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&sec_mode);

    err_code = sd_ble_gap_device_name_set(&sec_mode, (const uint8_t *)DEVICE_NAME, strlen(DEVICE_NAME));
    APP_ERROR_CHECK(err_code);

    memset(&gap_conn_params, 0, sizeof(gap_conn_params));

    gap_conn_params.min_conn_interval = MIN_CONN_INTERVAL;
    gap_conn_params.max_conn_interval = MAX_CONN_INTERVAL;
    gap_conn_params.slave_latency = SLAVE_LATENCY;
    gap_conn_params.conn_sup_timeout = CONN_SUP_TIMEOUT;

    err_code = sd_ble_gap_ppcp_set(&gap_conn_params);
    APP_ERROR_CHECK(err_code);

    sd_ble_gap_addr_get(&m_default_gap_addr);
}

/**@brief Function for handling Queued Write Module errors.
 *
 * @details A pointer to this function will be passed to each service which may need to inform the
 *          application about an error.
 *
 * @param[in]   nrf_error   Error code containing information about what went wrong.
 */
static void nrf_qwr_error_handler(uint32_t nrf_error) { APP_ERROR_HANDLER(nrf_error); }

/* NUS runs in the SoftDevice observer IRQ. Copy only; handlers and all VFS
 * operations run from ble_process_pending() in the foreground. */
static void nus_data_handler(ble_nus_evt_t *p_evt) {
    bool accepted = true;
    if (!m_remote_mode) nrf_pwr_mgmt_feed();
    if (!m_sessions_enabled || p_evt->conn_handle == BLE_CONN_HANDLE_INVALID ||
        (m_conn_handle != BLE_CONN_HANDLE_INVALID && p_evt->conn_handle != m_conn_handle)) return;
    if (p_evt->type == BLE_NUS_EVT_COMM_STARTED) {
        /* NUS's CONNECT observer runs before ours. Remember an already
         * restored CCCD, but do not dispatch work before GAP is recorded. */
        if (ble_conn_state_status(p_evt->conn_handle) != BLE_CONN_STATUS_CONNECTED ||
            m_release_handle != BLE_CONN_HANDLE_INVALID || m_nus_session_handle == p_evt->conn_handle) return;
        m_nus_session_handle = p_evt->conn_handle;
        m_session_generation++;
        m_file_join_pending = false;
        if ((m_file_mode || m_remote_mode) && m_conn_handle == p_evt->conn_handle) ble_work_connected();
        return;
    }
    if (p_evt->type == BLE_NUS_EVT_COMM_STOPPED) {
        if (m_nus_session_handle != p_evt->conn_handle) return; /* Initial CCCD=0 is not a session close. */
        m_nus_session_handle = BLE_CONN_HANDLE_INVALID;
        m_session_generation++;
        if ((m_file_mode || m_remote_mode) && m_conn_handle == p_evt->conn_handle) {
            ble_work_disconnected(); /* Invalidate now; flush/close only in main. */
            m_release_handle = m_conn_handle;
            m_release_generation = m_link_generation;
            m_release_attempted = m_release_requested = false;
        }
        return;
    }
    if (m_conn_handle != p_evt->conn_handle ||
        ((m_file_mode || m_remote_mode) && (m_nus_session_handle != m_conn_handle ||
                         m_release_handle != BLE_CONN_HANDLE_INVALID))) return;
    if (p_evt->type == BLE_NUS_EVT_RX_DATA) {
        accepted = m_remote_mode ? ble_remote_receive_irq(p_evt->params.rx_data.p_data, p_evt->params.rx_data.length)
                                 : ble_work_receive(p_evt->params.rx_data.p_data, p_evt->params.rx_data.length);
    } else if (p_evt->type == BLE_NUS_EVT_TX_RDY) {
        accepted = ble_work_tx_ready();
    }
    if (!accepted && m_conn_handle != BLE_CONN_HANDLE_INVALID) {
        /* A request burst exceeding the bounded queue must retry in a new
         * session; do not continue a stream with missing commands. */
        uint32_t result = sd_ble_gap_disconnect(m_conn_handle, BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
        NRF_LOG_WARNING("BLE work queue overflow; disconnect result %lu", (unsigned long)result);
    }
}

static void ble_file_join_poll(void) {
    /* No extra timer callback: serialize the deadline decision with NUS/GAP
     * events, then use the existing deferred cleanup and release path. */
    CRITICAL_REGION_ENTER();
    if (m_file_join_pending && m_sessions_enabled && (m_file_mode || m_remote_mode) &&
        m_conn_handle != BLE_CONN_HANDLE_INVALID && m_file_join_generation == m_link_generation &&
        m_nus_session_handle != m_conn_handle && m_release_handle == BLE_CONN_HANDLE_INVALID &&
        app_timer_cnt_diff_compute(app_timer_cnt_get(), m_file_join_tick) >= BLE_FILE_JOIN_TIMEOUT_TICKS) {
        m_file_join_pending = false;
        ble_work_disconnected();
        m_release_handle = m_conn_handle;
        m_release_generation = m_link_generation;
        m_release_attempted = m_release_requested = false;
        /* Give the restored user standby interval a fresh starting point,
         * rather than sleeping immediately when a short timeout returns. */
        nrf_pwr_mgmt_feed();
    }
    CRITICAL_REGION_EXIT();
}

static void ble_release_stopped_session(void) {
    /* Run after old VFS work has unwound and cleanup has completed. The
     * generation check also covers a newer peer reusing the same handle. */
    ret_code_t result = NRF_SUCCESS;
    CRITICAL_REGION_ENTER();
    if (ble_work_cleanup_complete() && !m_release_attempted && m_release_handle != BLE_CONN_HANDLE_INVALID &&
        m_release_handle == m_conn_handle && m_release_generation == m_link_generation) {
        m_release_attempted = true;
        result = sd_ble_gap_disconnect(m_release_handle, BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
        m_release_requested = result == NRF_SUCCESS;
    }
    CRITICAL_REGION_EXIT();
    /* On failure keep the actual link visible and allow the normal local
     * exit action to retry. Do not spin or claim that advertising resumed. */
    if (result != NRF_SUCCESS) NRF_LOG_WARNING("BLE session release failed: %lu", (unsigned long)result);
}

void ble_process_pending(void) {
    ble_file_join_poll();
    ble_work_process(ble_on_disconnected);
    ble_release_stopped_session();
    ble_file_link_poll();
    ble_pending_mode_poll();
    ble_df_driver_poll();
    if (m_link_state_handler) {
        ble_link_state_t state = ble_link_state_get();
        if (state != m_reported_link_state) {
            m_reported_link_state = state;
            m_link_state_handler(state);
        }
    }
    if (m_status_state_handler) {
        ble_link_state_t state = ble_status_state_get();
        if (state != m_reported_status_state) {
            m_reported_status_state = state;
            m_status_state_handler(state);
        }
    }
}

/**@snippet [Handling the data received over BLE] */

/**@brief Function for initializing services that will be used by the application.
 */
static void services_init(void) {
    uint32_t err_code;
    ble_nus_init_t nus_init;
    nrf_ble_qwr_init_t qwr_init = {0};

    // Initialize Queued Write Module.
    qwr_init.error_handler = nrf_qwr_error_handler;

    err_code = nrf_ble_qwr_init(&m_qwr, &qwr_init);
    APP_ERROR_CHECK(err_code);

    // Initialize NUS.
    memset(&nus_init, 0, sizeof(nus_init));

    nus_init.data_handler = nus_data_handler;

    err_code = ble_nus_init(&m_nus, &nus_init);
    APP_ERROR_CHECK(err_code);
}

/**@brief Function for handling an event from the Connection Parameters Module.
 *
 * @details This function will be called for all events in the Connection Parameters Module
 *          which are passed to the application.
 *
 * @note All this function does is to disconnect. This could have been done by simply setting
 *       the disconnect_on_fail config parameter, but instead we use the event handler
 *       mechanism to demonstrate its use.
 *
 * @param[in] p_evt  Event received from the Connection Parameters Module.
 */
static void on_conn_params_evt(ble_conn_params_evt_t *p_evt) {
    uint32_t err_code;

    if (p_evt->evt_type == BLE_CONN_PARAMS_EVT_FAILED) {
        err_code = sd_ble_gap_disconnect(m_conn_handle, BLE_HCI_CONN_INTERVAL_UNACCEPTABLE);
        APP_ERROR_CHECK(err_code);
    }
}

/**@brief Function for handling errors from the Connection Parameters module.
 *
 * @param[in] nrf_error  Error code containing information about what went wrong.
 */
static void conn_params_error_handler(uint32_t nrf_error) { APP_ERROR_HANDLER(nrf_error); }

/**@brief Function for initializing the Connection Parameters module.
 */
static void conn_params_init(void) {
    uint32_t err_code;
    ble_conn_params_init_t cp_init;

    memset(&cp_init, 0, sizeof(cp_init));

    cp_init.p_conn_params = NULL;
    cp_init.first_conn_params_update_delay = FIRST_CONN_PARAMS_UPDATE_DELAY;
    cp_init.next_conn_params_update_delay = NEXT_CONN_PARAMS_UPDATE_DELAY;
    cp_init.max_conn_params_update_count = MAX_CONN_PARAMS_UPDATE_COUNT;
    cp_init.start_on_notify_cccd_handle = BLE_GATT_HANDLE_INVALID;
    cp_init.disconnect_on_fail = false;
    cp_init.evt_handler = on_conn_params_evt;
    cp_init.error_handler = conn_params_error_handler;

    err_code = ble_conn_params_init(&cp_init);
    APP_ERROR_CHECK(err_code);
}

/**@brief Function for handling advertising events.
 *
 * @details This function will be called for advertising events which are passed to the application.
 *
 * @param[in] ble_adv_evt  Advertising event.
 */
static void on_adv_evt(ble_adv_evt_t ble_adv_evt) {
    uint32_t err_code;

    switch (ble_adv_evt) {
    case BLE_ADV_EVT_FAST:
        m_advertising_active = true;
        err_code = bsp_indication_set(BSP_INDICATE_ADVERTISING);
        APP_ERROR_CHECK(err_code);
        break;
    case BLE_ADV_EVT_IDLE:
        m_advertising_active = false;
        bsp_indication_set(BSP_INDICATE_IDLE);
        break;
    default:
        break;
    }
}

/**@brief Function for handling BLE events.
 *
 * @param[in]   p_ble_evt   Bluetooth stack event.
 * @param[in]   p_context   Unused.
 */
/* The SoftDevice returns counted UTF-8 bytes, without a terminating NUL. */
static bool ble_device_name_is(const char *expected) {
    uint8_t device_name[35];
    uint16_t length = sizeof(device_name);
    if (expected == NULL) return false;
    uint32_t result = sd_ble_gap_device_name_get(device_name, &length);
    size_t expected_length = strlen(expected);
    return result == NRF_SUCCESS && length <= sizeof(device_name) &&
           length == expected_length && memcmp(device_name, expected, length) == 0;
}

static void ble_evt_handler(ble_evt_t const *p_ble_evt, void *p_context) {
    uint32_t err_code;

    switch (p_ble_evt->header.evt_id) {
    case BLE_GAP_EVT_CONNECTED:
        NRF_LOG_INFO("Connected");
        err_code = bsp_indication_set(BSP_INDICATE_CONNECTED);
        APP_ERROR_CHECK(err_code);
        m_conn_handle = p_ble_evt->evt.gap_evt.conn_handle;
        m_link_generation++;
        m_session_generation++;
        m_timeout_overridden = false;
        m_release_handle = BLE_CONN_HANDLE_INVALID;
        m_release_attempted = m_release_requested = false;
        m_file_join_pending = m_sessions_enabled && (m_file_mode || m_remote_mode) && m_nus_session_handle != m_conn_handle;
        if (m_file_join_pending) {
            m_file_join_tick = app_timer_cnt_get();
            m_file_join_generation = m_link_generation;
            /* GAP discovery is activity once, not a reason to feed forever. */
            nrf_pwr_mgmt_feed();
        }
        m_advertising_active = false;
        m_ble_nus_max_data_len = BLE_GATT_ATT_MTU_DEFAULT - OPCODE_LENGTH - HANDLE_LENGTH;
        if (m_sessions_enabled && (!(m_file_mode || m_remote_mode) || m_nus_session_handle == m_conn_handle)) {
            ble_work_connected();
        } else {
            ble_work_disconnected();
        }
        err_code = nrf_ble_qwr_conn_handle_assign(&m_qwr, m_conn_handle);
        APP_ERROR_CHECK(err_code);

        if (!m_sessions_enabled) {
            /* A CONNECT already accepted by the stack may arrive after stop. */
            sd_ble_gap_disconnect(m_conn_handle, BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
            break;
        }
        if (ble_device_name_is(DEVICE_NAME_AMILOOP)) {
            NRF_LOG_INFO("Set mtu to %d", NRF_SDH_BLE_GATT_MAX_MTU_SIZE);
            sd_ble_gattc_exchange_mtu_request(p_ble_evt->evt.gap_evt.conn_handle, NRF_SDH_BLE_GATT_MAX_MTU_SIZE);
        }

        if (!m_remote_mode) {
            m_previous_pwr_mgmt_sleep_timeout = nrf_pwr_mgmt_get_timeout();
            nrf_pwr_mgmt_set_timeout(BLE_CONNECT_SLEEP_TIMEOUT_SECONDS);
            m_timeout_overridden = true;
        }

        break;

    case BLE_GAP_EVT_DISCONNECTED:
        if (p_ble_evt->evt.gap_evt.conn_handle != m_conn_handle) break;
        runtime_diag_ble_disconnected(p_ble_evt->evt.gap_evt.params.disconnected.reason);
        NRF_LOG_INFO("Disconnected");
        // LED indication will be changed when advertising starts.
        m_conn_handle = BLE_CONN_HANDLE_INVALID;
        /* Do not clear advertising here: the SDK may already have restarted
         * it earlier in this same disconnect observer dispatch. */
        m_nus_session_handle = m_release_handle = BLE_CONN_HANDLE_INVALID;
        m_file_join_pending = false;
        m_release_attempted = m_release_requested = false;
        m_link_generation++;
        m_session_generation++;
        m_ble_nus_max_data_len = BLE_GATT_ATT_MTU_DEFAULT - OPCODE_LENGTH - HANDLE_LENGTH;
        ble_work_disconnected();
        if (m_timeout_overridden) nrf_pwr_mgmt_set_timeout(m_previous_pwr_mgmt_sleep_timeout);
        m_timeout_overridden = false;

        break;

    case BLE_GAP_EVT_PHY_UPDATE_REQUEST: {
        NRF_LOG_DEBUG("PHY update request.");
        ble_gap_phys_t const phys = {
            .rx_phys = BLE_GAP_PHY_AUTO,
            .tx_phys = BLE_GAP_PHY_AUTO,
        };
        err_code = sd_ble_gap_phy_update(p_ble_evt->evt.gap_evt.conn_handle, &phys);
        APP_ERROR_CHECK(err_code);
    } break;

    case BLE_GAP_EVT_SEC_PARAMS_REQUEST:
        // Pairing not supported
        err_code = sd_ble_gap_sec_params_reply(m_conn_handle, BLE_GAP_SEC_STATUS_PAIRING_NOT_SUPP, NULL, NULL);
        APP_ERROR_CHECK(err_code);
        break;

    case BLE_GATTS_EVT_SYS_ATTR_MISSING:
        // No system attributes have been stored.
        err_code = sd_ble_gatts_sys_attr_set(m_conn_handle, NULL, 0, 0);
        APP_ERROR_CHECK(err_code);
        break;

    case BLE_GATTC_EVT_TIMEOUT:
        runtime_diag_ble_abort(RUNTIME_DIAG_GATT_CLIENT_TIMEOUT);
        // Disconnect on GATT Client timeout event.
        err_code =
            sd_ble_gap_disconnect(p_ble_evt->evt.gattc_evt.conn_handle, BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
        APP_ERROR_CHECK(err_code);
        break;

    case BLE_GATTS_EVT_TIMEOUT:
        runtime_diag_ble_abort(RUNTIME_DIAG_GATT_SERVER_TIMEOUT);
        // Disconnect on GATT Server timeout event.
        err_code =
            sd_ble_gap_disconnect(p_ble_evt->evt.gatts_evt.conn_handle, BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
        APP_ERROR_CHECK(err_code);
        break;

    default:
        // No implementation needed.
        break;
    }
}

/**@brief Function for the SoftDevice initialization.
 *
 * @details This function initializes the SoftDevice and the BLE event interrupt.
 */
static void ble_stack_init(void) {
    ret_code_t err_code;

    if (!nrf_sdh_is_enabled()) {
        err_code = nrf_sdh_enable_request();
        APP_ERROR_CHECK(err_code);
    }

    // Configure the BLE stack using the default settings.
    // Fetch the start address of the application RAM.
    uint32_t ram_start = 0;
    err_code = nrf_sdh_ble_default_cfg_set(APP_BLE_CONN_CFG_TAG, &ram_start);
    APP_ERROR_CHECK(err_code);

    // Enable BLE stack.
    err_code = nrf_sdh_ble_enable(&ram_start);
    APP_ERROR_CHECK(err_code);

    // Register a handler for BLE events.
    NRF_SDH_BLE_OBSERVER(m_ble_observer, APP_BLE_OBSERVER_PRIO, ble_evt_handler, NULL);
}

/**@brief Function for handling events from the GATT library. */
void gatt_evt_handler(nrf_ble_gatt_t *p_gatt, nrf_ble_gatt_evt_t const *p_evt) {
    if ((m_conn_handle == p_evt->conn_handle) && (p_evt->evt_id == NRF_BLE_GATT_EVT_ATT_MTU_UPDATED)) {
        m_ble_nus_max_data_len = p_evt->params.att_mtu_effective - OPCODE_LENGTH - HANDLE_LENGTH;
        NRF_LOG_INFO("Data len is set to 0x%X(%d)", m_ble_nus_max_data_len, m_ble_nus_max_data_len);
    }
    NRF_LOG_DEBUG("ATT MTU exchange completed. central 0x%x peripheral 0x%x", p_gatt->att_mtu_desired_central,
                  p_gatt->att_mtu_desired_periph);
}

/**@brief Function for initializing the GATT library. */
void gatt_init(void) {
    ret_code_t err_code;

    err_code = nrf_ble_gatt_init(&m_gatt, gatt_evt_handler);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_ble_gatt_att_mtu_periph_set(&m_gatt, NRF_SDH_BLE_GATT_MAX_MTU_SIZE);
    APP_ERROR_CHECK(err_code);
}

/**@snippet [Handling the data received over UART] */

/**@brief Function for initializing the Advertising functionality.
 */
static ret_code_t advertising_init(bool remote) {
    uint32_t err_code;
    ble_advertising_init_t init;

    memset(&init, 0, sizeof(init));

    init.advdata.name_type = remote ? BLE_ADVDATA_NO_NAME : BLE_ADVDATA_FULL_NAME;
    init.advdata.include_appearance = false;
    init.advdata.flags = remote ? BLE_GAP_ADV_FLAGS_LE_ONLY_GENERAL_DISC_MODE :
                                BLE_GAP_ADV_FLAGS_LE_ONLY_LIMITED_DISC_MODE;

    /* Primary: flags (3) + complete 128-bit NUS UUID (18) = 21 bytes.
     * Scan response: complete Pixl.Remote name (13 bytes). Both fit legacy
     * 31-byte packets; service-filtered discovery sees NUS before scanning.
     * Existing file/AmiiboLink advertising retains its established layout. */
    ble_advdata_t *services = remote ? &init.advdata : &init.srdata;
    services->uuids_complete.uuid_cnt = sizeof(m_adv_uuids) / sizeof(m_adv_uuids[0]);
    services->uuids_complete.p_uuids = m_adv_uuids;
    if (remote) init.srdata.name_type = BLE_ADVDATA_FULL_NAME;

    init.config.ble_adv_fast_enabled = true;
    init.config.ble_adv_fast_interval = APP_ADV_INTERVAL;
    /* Permission ends at sleep/disable; mere advertising never feeds sleep. */
    init.config.ble_adv_fast_timeout = remote ? 0 : APP_ADV_DURATION;
    init.evt_handler = on_adv_evt;
    init.config.ble_adv_on_disconnect_disabled = true;

    err_code = ble_advertising_init(&m_advertising, &init);
    if (err_code != NRF_SUCCESS) return err_code;
    ble_advertising_conn_cfg_tag_set(&m_advertising, APP_BLE_CONN_CFG_TAG);
    return NRF_SUCCESS;
}

/**@brief Function for starting advertising.
 */
static void advertising_start(void) {
    m_advertising.adv_modes_config.ble_adv_on_disconnect_disabled = false;
    uint32_t err_code = ble_advertising_start(&m_advertising, BLE_ADV_MODE_FAST);
    if (m_remote_mode)
        remote_init_step(err_code == NRF_SUCCESS ? BLE_REMOTE_INIT_READY : BLE_REMOTE_INIT_START, err_code);
    APP_ERROR_CHECK(err_code);
}

/**@brief Application main function.
 */
void ble_init(void) {

    if (!m_ble_initialized) {
        ble_stack_init();
        gap_params_init();
        gatt_init();
        services_init();
        conn_params_init();
        df_core_init();
        m_ble_initialized = true;
    }

    NRF_LOG_INFO("BLE started.");
}

static ret_code_t ble_set_device_name(const char *device_name) {
    ble_gap_conn_sec_mode_t sec_mode;
    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&sec_mode);
    return sd_ble_gap_device_name_set(&sec_mode, (const uint8_t *)device_name, strlen(device_name));
}
static ret_code_t ble_addr_set(uint8_t offset) {
    ble_gap_addr_t addr = m_default_gap_addr;
    if (offset == 0x30) {
        /* Remote gets a separate stable random-static identity. Carry across
         * its 46 random bits, preserving the upper address-type bits. Keep
         * the established file/+0x10/+0x20 identities unchanged. DFU uses +1. */
        uint8_t type_bits = addr.addr[5] & 0xC0u;
        uint16_t carry = offset;
        for (unsigned i = 0; i < sizeof(addr.addr); ++i) {
            carry += addr.addr[i];
            addr.addr[i] = (uint8_t)carry;
            carry >>= 8;
        }
        addr.addr[5] = (addr.addr[5] & 0x3Fu) | type_bits;
        /* Static random addresses may not have all-zero/all-one random bits. */
        bool zeros = (addr.addr[5] & 0x3Fu) == 0;
        bool ones = (addr.addr[5] & 0x3Fu) == 0x3Fu;
        for (unsigned i = 0; i < 5; ++i) {
            zeros = zeros && addr.addr[i] == 0;
            ones = ones && addr.addr[i] == 0xFFu;
        }
        if (zeros || ones) addr.addr[0] ^= 2u;
    } else {
        addr.addr[0] += offset;
    }
    return sd_ble_gap_addr_set(&addr);
}

void ble_service_id_set(uint32_t suffix) {
    if (m_advertising.p_adv_data == NULL ||
        m_advertising.p_adv_data->scan_rsp_data.p_data == NULL ||
        m_advertising.p_adv_data->scan_rsp_data.len < sizeof(suffix)) return;
    uint8_t *ptr = m_advertising.p_adv_data->scan_rsp_data.p_data
                    + m_advertising.p_adv_data->scan_rsp_data.len - sizeof(suffix);
    memcpy(ptr, &suffix, sizeof(suffix));
}

static ret_code_t ble_apply_device_mode(ble_device_mode_t mode) {
    uint8_t offset = mode == BLE_DEVICE_MODE_REMOTE ? 0x30 : 0;
    const char *name = mode == BLE_DEVICE_MODE_REMOTE ? DEVICE_NAME_REMOTE : DEVICE_NAME_PIXLJS;
    if (mode == BLE_DEVICE_MODE_AMIIBOLINK || mode == BLE_DEVICE_MODE_AMIIBOLINK_V2) {
        name = DEVICE_NAME_AMIIBOLINK; offset = 0x10;
    } else if (mode == BLE_DEVICE_MODE_AMILOOP) {
        name = DEVICE_NAME_AMILOOP; offset = 0x20;
    }
    /* BUSY means the stack still has events to deliver. Publish no new owner
     * until every configuration step succeeded; retry from foreground. */
    ret_code_t result = ble_addr_set(offset);
    if (mode == BLE_DEVICE_MODE_REMOTE) remote_init_step(BLE_REMOTE_INIT_ADDRESS, result);
    if (result != NRF_SUCCESS) return result;
    result = ble_set_device_name(name);
    if (mode == BLE_DEVICE_MODE_REMOTE) remote_init_step(BLE_REMOTE_INIT_NAME, result);
    if (result != NRF_SUCCESS) return result;
    result = nrf_ble_gatt_att_mtu_periph_set(&m_gatt, NRF_SDH_BLE_GATT_MAX_MTU_SIZE);
    if (mode == BLE_DEVICE_MODE_REMOTE) remote_init_step(BLE_REMOTE_INIT_MTU, result);
    if (result != NRF_SUCCESS) return result;
    result = advertising_init(mode == BLE_DEVICE_MODE_REMOTE);
    if (mode == BLE_DEVICE_MODE_REMOTE) remote_init_step(BLE_REMOTE_INIT_ADVDATA, result);
    if (result != NRF_SUCCESS) return result;
    /* Remote's service was encoded in the primary payload; its scan response
     * now ends in the name and must not be patched as a UUID byte array. */
    if (mode != BLE_DEVICE_MODE_REMOTE)
        ble_service_id_set(mode == BLE_DEVICE_MODE_AMIIBOLINK_V2 ? 0x0000180F : 0x6e400001);
    m_file_join_pending = false;
    m_file_mode = mode == BLE_DEVICE_MODE_PIXLJS;
    m_remote_mode = mode == BLE_DEVICE_MODE_REMOTE;
    m_session_generation++;
    m_sessions_enabled = true;
    return NRF_SUCCESS;
}

void ble_adv_start(void) {
    if (m_mode_pending) { m_mode_adv_requested = true; return; }
    if (m_ble_initialized && m_advertising.adv_mode_current == BLE_ADV_MODE_IDLE) {
        advertising_start();
    }
}

ble_link_state_t ble_link_state_get(void) {
    ble_link_state_t state;
    CRITICAL_REGION_ENTER();
    if (m_conn_handle != BLE_CONN_HANDLE_INVALID) {
        state = m_release_handle != BLE_CONN_HANDLE_INVALID && (!m_release_attempted || m_release_requested) ?
                    BLE_LINK_DISCONNECTING :
                m_file_mode && m_nus_session_handle != m_conn_handle ? BLE_LINK_HOST_CONNECTED : BLE_LINK_CONNECTED;
    } else {
        state = m_advertising_active ? BLE_LINK_ADVERTISING : BLE_LINK_INACTIVE;
    }
    CRITICAL_REGION_EXIT();
    return state;
}

ble_link_state_t ble_status_state_get(void) {
    ble_link_state_t state = BLE_LINK_INACTIVE;
    CRITICAL_REGION_ENTER();
    if (m_ble_initialized) {
        if (m_conn_handle != BLE_CONN_HANDLE_INVALID) {
            if (!m_sessions_enabled || m_mode_pending)
                state = BLE_LINK_DISCONNECTING;
            else if (m_release_handle != BLE_CONN_HANDLE_INVALID)
                /* A rejected disconnect keeps the physical link but no ready
                 * session. Do not imply that a release is still in flight. */
                state = !m_release_attempted || m_release_requested ?
                    BLE_LINK_DISCONNECTING : BLE_LINK_HOST_CONNECTED;
            else
                state = m_nus_session_handle == m_conn_handle && ble_work_can_send() ?
                    BLE_LINK_CONNECTED : BLE_LINK_HOST_CONNECTED;
        } else if (m_sessions_enabled && !m_mode_pending && m_advertising_active) {
            state = BLE_LINK_ADVERTISING;
        }
    }
    CRITICAL_REGION_EXIT();
    return state;
}

void ble_status_state_observe(ble_link_state_handler_t handler) {
    m_status_state_handler = handler;
    m_reported_status_state = UINT8_MAX;
}

void ble_link_state_observe(ble_link_state_handler_t handler) {
    /* Registration and delivery are foreground-only. Force one initial
     * snapshot even when another BLE app previously saw the same state. */
    m_link_state_handler = handler;
    m_reported_link_state = UINT8_MAX;
}

bool ble_restart_advertising(void) {
    ret_code_t result = NRF_ERROR_INVALID_STATE;
    CRITICAL_REGION_ENTER();
    if (m_ble_initialized && m_conn_handle == BLE_CONN_HANDLE_INVALID && !m_advertising_active) {
        m_advertising.adv_modes_config.ble_adv_on_disconnect_disabled = false;
        result = ble_advertising_start(&m_advertising, BLE_ADV_MODE_FAST);
        if (m_remote_mode)
            remote_init_step(result == NRF_SUCCESS ? BLE_REMOTE_INIT_READY : BLE_REMOTE_INIT_START, result);
    }
    CRITICAL_REGION_EXIT();
    /* SoftDevice may establish a link before its application IRQ is handled.
     * INVALID_STATE must not reset/disconnect that new peer. Allow a retry if
     * advertising failed for another reason; never report success early. */
    if (result != NRF_SUCCESS) NRF_LOG_INFO("BLE visibility retry: %lu", (unsigned long)result);
    return result == NRF_SUCCESS;
}

static void ble_stop_transport(void) {
    m_file_link_handoff = 0;
    m_session_generation++;
    m_file_join_pending = false;
    m_sessions_enabled = false;
    m_nus_session_handle = m_release_handle = BLE_CONN_HANDLE_INVALID;
    m_release_attempted = m_release_requested = false;
    m_advertising_active = false;
    ble_work_disconnected();
    if (!m_ble_initialized) return;

    /* Disable automatic restart before stopping advertising: a disconnect
     * observer may run between these SoftDevice calls. */
    m_advertising.adv_modes_config.ble_adv_on_disconnect_disabled = true;
    if (m_advertising.p_adv_data) {
        ble_advertising_start(&m_advertising, BLE_ADV_MODE_IDLE);
        sd_ble_gap_adv_stop(m_advertising.adv_handle);
    }
    if (m_conn_handle != BLE_CONN_HANDLE_INVALID) {
        sd_ble_gap_disconnect(m_conn_handle, BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
    }
}

void ble_disable(void) {
    m_mode_pending = m_mode_adv_requested = m_mode_handlers_ready = m_mode_wait_reply = false;
    remote_init_step(BLE_REMOTE_INIT_IDLE, NRF_SUCCESS);
    ble_stop_transport();
}
void ble_device_mode_prepare(ble_device_mode_t mode) {
    /* New owners register their handlers before the next foreground poll.
     * Never reconfigure the GAP address beneath an existing connection. */
    m_pending_mode = mode;
    remote_init_step(mode == BLE_DEVICE_MODE_REMOTE ? BLE_REMOTE_INIT_WAIT : BLE_REMOTE_INIT_IDLE, NRF_SUCCESS);
    m_mode_pending = true;
    m_mode_adv_requested = m_mode_handlers_ready = m_mode_stop_requested = false;
    m_pending_rx = NULL; m_pending_tx = NULL;
    m_mode_wait_reply = m_remote_mode && ble_remote_dispatching();
    m_mode_wait_tick = app_timer_cnt_get();
    if (!m_mode_wait_reply) { ble_stop_transport(); m_mode_stop_requested = true; }
}
static void ble_pending_mode_poll(void) {
    if (!m_mode_pending) return;
    if (!m_mode_stop_requested) {
        if (m_mode_wait_reply && ble_is_connected() && ble_remote_response_pending() &&
            app_timer_cnt_diff_compute(app_timer_cnt_get(), m_mode_wait_tick) < APP_TIMER_TICKS(2000)) return;
        ble_stop_transport(); m_mode_stop_requested = true;
    }
    if (m_conn_handle != BLE_CONN_HANDLE_INVALID || !ble_work_cleanup_complete() || !m_mode_handlers_ready) return;
    ble_device_mode_t mode = m_pending_mode;
    bool advertise = m_mode_adv_requested;
    ble_work_set_handlers(m_pending_rx, m_pending_tx);
    ble_work_process(ble_on_disconnected);
    if (!ble_work_cleanup_complete()) return;
    ret_code_t result = NRF_ERROR_BUSY;
    CRITICAL_REGION_ENTER();
    if (m_conn_handle == BLE_CONN_HANDLE_INVALID && ble_work_cleanup_complete())
        result = ble_apply_device_mode(mode);
    CRITICAL_REGION_EXIT();
    if (result == NRF_ERROR_BUSY || result == NRF_ERROR_INVALID_STATE) return;
    APP_ERROR_CHECK(result);
    m_mode_pending = m_mode_wait_reply = false;
    if (advertise) ble_adv_start();
}
uint32_t ble_session_generation(void) { return m_session_generation; }
uint32_t ble_link_generation(void) { return m_link_generation; }
bool ble_remote_mode_active(void) { return m_ble_initialized && m_remote_mode && m_sessions_enabled; }
bool ble_remote_mode_owned(void) {
    return m_mode_pending ? m_pending_mode == BLE_DEVICE_MODE_REMOTE : ble_remote_mode_active();
}
bool ble_mode_transition_pending(void) { return m_mode_pending; }
bool ble_transport_idle(void) { return m_conn_handle == BLE_CONN_HANDLE_INVALID && ble_work_cleanup_complete(); }
bool ble_remote_transport_ready(void) {
    return ble_remote_mode_active() && m_conn_handle != BLE_CONN_HANDLE_INVALID &&
           m_nus_session_handle == m_conn_handle && m_release_handle == BLE_CONN_HANDLE_INVALID && ble_work_can_send();
}
uint32_t ble_remote_open_file_link(const uint8_t *reply, size_t length, uint32_t generation) {
    ret_code_t result = NRF_ERROR_INVALID_STATE;
    CRITICAL_REGION_ENTER();
    if (!m_mode_pending && !m_file_link_handoff && m_session_generation == generation &&
        ble_remote_transport_ready()) {
        result = ble_nus_tx_data((void *)reply, length);
        if (result == NRF_SUCCESS) {
            /* The ACK and new RX owner are indivisible to application IRQs.
             * Discard all old remote work; newly arriving file frames remain
             * queued until foreground cleanup has reset the DF protocol. */
            m_remote_mode = false;
            m_file_mode = true;
            m_file_join_pending = false;
            m_session_generation++;
            m_file_link_generation = m_link_generation;
            m_file_link_handoff = 1;
            m_advertising.adv_modes_config.ble_adv_on_disconnect_disabled = true;
            ble_work_set_handlers(ble_on_received_data, ble_on_transmit_ready);
            ble_work_connected();
            m_previous_pwr_mgmt_sleep_timeout = nrf_pwr_mgmt_get_timeout();
            nrf_pwr_mgmt_set_timeout(BLE_CONNECT_SLEEP_TIMEOUT_SECONDS);
            m_timeout_overridden = true;
        }
    }
    CRITICAL_REGION_EXIT();
    return result;
}
bool ble_file_link_adopt(void) {
    bool accepted = false;
    CRITICAL_REGION_ENTER();
    if (m_file_link_handoff == 1 && m_file_link_generation == m_link_generation &&
        m_sessions_enabled && m_file_mode && !m_mode_pending &&
        m_conn_handle != BLE_CONN_HANDLE_INVALID && m_nus_session_handle == m_conn_handle &&
        m_release_handle == BLE_CONN_HANDLE_INVALID && ble_work_can_send()) {
        m_file_link_handoff = 2;
        accepted = true;
    }
    CRITICAL_REGION_EXIT();
    return accepted;
}
static void ble_file_link_poll(void) {
    if (!m_file_link_handoff || m_conn_handle != BLE_CONN_HANDLE_INVALID) return;
    /* A retained link used the remote GAP name/advertisement. Only after its
     * disconnect may the normal file identity and visibility be configured. */
    m_file_link_handoff = 0;
    ble_device_mode_prepare(BLE_DEVICE_MODE_PIXLJS);
    ble_adv_start();
    ble_nus_set_handler(ble_on_received_data, ble_on_transmit_ready);
}
void ble_hold_advertising_after_disconnect(void) {
    m_advertising.adv_modes_config.ble_adv_on_disconnect_disabled = true;
}
void ble_release_advertising_hold(void) {
    if (m_mode_pending || !ble_remote_mode_active()) return;
    m_advertising.adv_modes_config.ble_adv_on_disconnect_disabled = false;
    if (ble_transport_idle()) (void)ble_restart_advertising();
}

bool ble_is_connected(void) {
    return m_conn_handle != BLE_CONN_HANDLE_INVALID;
}

void ble_nus_set_handler(nus_rx_data_handler_t rx_data_handler, nus_tx_ready_handler_t tx_ready_handler) {
    if (m_mode_pending) {
        m_pending_rx = rx_data_handler; m_pending_tx = tx_ready_handler;
        m_mode_handlers_ready = true;
    } else ble_work_set_handlers(rx_data_handler, tx_ready_handler);
}

size_t ble_nus_max_data_length(void) { return m_ble_nus_max_data_len; }

bool ble_mtu_diagnostic(uint16_t requested_mtu, uint8_t *snapshot, size_t capacity) {
    if (snapshot == NULL || capacity < BLE_MTU_DIAGNOSTIC_SIZE ||
        (requested_mtu != 0 && requested_mtu != BLE_GATT_ATT_MTU_DEFAULT &&
         requested_mtu != NRF_SDH_BLE_GATT_MAX_MTU_SIZE)) return false;

    bool success = false;
    CRITICAL_REGION_ENTER();
    if (m_ble_initialized) {
        bool connected = m_conn_handle != BLE_CONN_HANDLE_INVALID && ble_work_can_send();
        /* A same-link handoff retains the remote GAP name until disconnect. */
        bool file_mode = m_file_mode;
        uint16_t effective = connected ? nrf_ble_gatt_eff_mtu_get(&m_gatt, m_conn_handle) : 0;
        if ((!connected || (effective >= BLE_GATT_ATT_MTU_DEFAULT && effective <= NRF_SDH_BLE_GATT_MAX_MTU_SIZE)) &&
            (requested_mtu == 0 || (connected && file_mode &&
             nrf_ble_gatt_att_mtu_periph_set(&m_gatt, requested_mtu) == NRF_SUCCESS))) {
            const uint16_t values[] = {effective, m_gatt.att_mtu_desired_periph,
                                      NRF_SDH_BLE_GATT_MAX_MTU_SIZE, connected ? m_ble_nus_max_data_len : 0};
            memset(snapshot, 0, BLE_MTU_DIAGNOSTIC_SIZE);
            memcpy(snapshot, "MTUD", 4);
            snapshot[4] = 1;
            snapshot[5] = (connected ? 1u : 0u) | (file_mode ? 2u : 0u);
            for (size_t i = 0; i < sizeof(values) / sizeof(values[0]); ++i) {
                snapshot[6 + i * 2] = (uint8_t)values[i];
                snapshot[7 + i * 2] = (uint8_t)(values[i] >> 8);
            }
            success = true;
        }
    }
    CRITICAL_REGION_EXIT();
    return success;
}

void ble_nus_abort_transfer(void) {
    /* Discard queued work now; file-close/flush remains deferred to main after
     * the current handler returns, as with a radio disconnect. */
    CRITICAL_REGION_ENTER();
    /* An old callback must never disconnect a newer peer after a link change. */
    if (ble_work_can_send()) {
        ble_work_disconnected();
        if (m_conn_handle != BLE_CONN_HANDLE_INVALID) {
            ret_code_t result = sd_ble_gap_disconnect(m_conn_handle, BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
            if (result != NRF_SUCCESS) NRF_LOG_INFO("DF disconnect failed: %d", result);
        }
    }
    CRITICAL_REGION_EXIT();
}

ret_code_t ble_nus_tx_data(void *data, size_t length) {
    if (data == NULL || length > m_ble_nus_max_data_len) return NRF_ERROR_DATA_SIZE;
    uint16_t tx_length = (uint16_t)length;
    ret_code_t err_code = NRF_ERROR_INVALID_STATE;
    /* Keep the session check and submission together with respect to BLE
     * observer callbacks. SoftDevice radio IRQs remain enabled. */
    CRITICAL_REGION_ENTER();
    if (ble_work_can_send() && m_conn_handle != BLE_CONN_HANDLE_INVALID) {
        err_code = ble_nus_data_send(&m_nus, data, &tx_length, m_conn_handle);
    }
    CRITICAL_REGION_EXIT();
    if (err_code) NRF_LOG_INFO("send back error:%d", err_code);
    return err_code;
}

void ble_get_addr_str(char addr_fmt[]) {
    ble_gap_addr_t addr = {0};
    sd_ble_gap_addr_get(&addr);
    sprintf(addr_fmt, "%02X:%02X:%02X:%02X:%02X:%02X", addr.addr[5], addr.addr[4], addr.addr[3], addr.addr[2],
            addr.addr[1], addr.addr[0]);
}
