#include "df_proto_info.h"
#include "df_proto_vfs.h"
#include "df_buffer.h"
#include "utils2.h"
#include "ble_df_driver.h"
#include "mui_nav_diag.h"
#include "../runtime_diag.h"
#include "../boot_diag.h"
#include "boards.h"
#ifdef LCD_SCREEN
#include "../fault_note.h"
#include "hal_spi_flash.h"
#include "mui_core.h"
#include "mbedtls/sha256.h"
#endif

#include "nrf_log.h"
#include "ble_main.h"
#include "version2.h"
#include "ble_main.h"

void df_proto_handler_info_get_version(df_event_t *evt) {
    if (evt->type == DF_EVENT_DATA_RECEVIED) {
        df_frame_t out;

        NEW_BUFFER_ZERO(buff, out.data, sizeof(out.data));
        buff_put_string(&buff, version_get_version(version_get()));
        char ble_addr[24];
        ble_get_addr_str(ble_addr);
        buff_put_string(&buff, ble_addr);

        OUT_FRAME_WITH_DATA_0(out, DF_PROTO_CMD_INFO_VERSION_INFO, DF_STATUS_OK, buff_get_size(&buff));

        df_core_send_frame(&out);
    }
}

static bool dfu_pending;

void df_proto_info_cancel_pending(void) {
    if (dfu_pending) {
        dfu_pending = false;
        system_cancel_reset();
    }
}

void df_proto_handler_info_enter_dfu(df_event_t *evt) {
    if (evt->type == DF_EVENT_LINK_DISCONNECTED) {
        df_proto_info_cancel_pending();
    } else if (evt->type == DF_EVENT_DATA_RECEVIED) {
        df_proto_info_cancel_pending();
        /* Flush and reserve the exact current owner before acknowledging.
         * Errors and superseded requests must never reset on TX_READY. */
        dfu_pending = evt->df->length == 0 && evt->df->status == 0 && evt->df->chunk == 0 &&
                      df_proto_vfs_file_transfer_closed() && system_prepare_reset();
        df_frame_t out;
        OUT_FRAME_NO_DATA(out, DF_PROTO_CMD_INFO_ENTER_DFU, dfu_pending ? DF_STATUS_OK : DF_STATUS_ERR);
        df_core_send_frame(&out);
    } else if (evt->type == DF_EVENT_DATA_TRANSMIT_READY && dfu_pending) {
        dfu_pending = false;
        if (system_reset_prepared()) {
            NRF_LOG_INFO("enter dfu ...");
            (void)enter_dfu();
        } else {
            system_cancel_reset();
        }
    }
}

static void df_proto_handler_info_capabilities(df_event_t *evt) {
    if (evt->type != DF_EVENT_DATA_RECEVIED) return;
    df_frame_t out = {0};
    OUT_FRAME_NO_DATA(out, DF_PROTO_CMD_INFO_CAPABILITIES, DF_STATUS_ERR);
    if (evt->df->length == 0 && evt->df->status == 0 && evt->df->chunk == 0) {
        ble_df_driver_enable_framed_rx();
        /* Fits the minimum ATT MTU23: magic, format, RX/TX chunk flags,
         * maximum reassembled request payload and current GATT value capacity
         * (both little endian). ATT MTU is shared by RX and TX on this link. */
        size_t capacity = ble_nus_max_data_length();
        if (capacity < 20 || capacity > DF_MAX_LEN) capacity = 20;
        const uint8_t capabilities[] = {'P', 'X', 'D', 'F', 1, 3, DF_PAYLOAD_LEN, 0,
                                        (uint8_t)capacity, (uint8_t)(capacity >> 8)};
        memcpy(out.data, capabilities, sizeof(capabilities));
        out.status = DF_STATUS_OK;
        out.length = sizeof(capabilities);
    }
    df_core_send_frame(&out);
}

/* Diagnostic build only: a bounded RAM snapshot, no settings/file mutation.
 * Reading never clears the observations from the previous Settings session. */
static void df_proto_handler_info_ui_diagnostic(df_event_t *evt) {
    if (evt->type != DF_EVENT_DATA_RECEVIED) return;
    df_frame_t out = {0};
    OUT_FRAME_NO_DATA(out, DF_PROTO_CMD_INFO_UI_DIAGNOSTIC, DF_STATUS_ERR);
    if (!evt->df->status && !evt->df->chunk) {
        if (!evt->df->length && mui_nav_diag_snapshot(out.data, sizeof(out.data)))
            out.length = MUI_NAV_DIAG_SNAPSHOT_SIZE;
#ifdef MUI_FIRST_MENU_DIAG
        else if (evt->df->length == 1 && evt->df->data[0] == 1 &&
                 mui_menu_diag_snapshot(out.data, sizeof(out.data)))
            out.length = MUI_MENU_DIAG_SIZE;
        else if (evt->df->length == 1 && evt->df->data[0] == 2 &&
                 mui_menu_diag_snapshot_v2(out.data, sizeof(out.data)))
            out.length = MUI_MENU_DIAG_V2_SIZE;
#endif
        if (out.length) out.status = DF_STATUS_OK;
    }
    df_core_send_frame(&out);
}

/* Empty query, or exactly "MTU!" + uint16 LE (23 or 250). The ACK uses the
 * current link; the test client must disconnect/reconnect to apply the value.
 * This is volatile diagnostics, not a persisted setting or a DFU request. */
static void df_proto_handler_info_mtu_diagnostic(df_event_t *evt) {
    if (evt->type != DF_EVENT_DATA_RECEVIED) return;
    df_frame_t out = {0};
    OUT_FRAME_NO_DATA(out, DF_PROTO_CMD_INFO_MTU_DIAGNOSTIC, DF_STATUS_ERR);
    if (evt->df->status == 0 && evt->df->chunk == 0) {
        bool idle = df_proto_vfs_is_idle();
        uint16_t requested = 0;
        bool valid = evt->df->length == 0;
        if (evt->df->length == 6 && memcmp(evt->df->data, "MTU!", 4) == 0) {
            requested = (uint16_t)evt->df->data[4] | ((uint16_t)evt->df->data[5] << 8);
            valid = idle && (requested == 23 || requested == 250);
        }
        if (valid && ble_mtu_diagnostic(requested, out.data, sizeof(out.data))) {
            if (idle) out.data[5] |= 4; /* no open/abandoned file or directory transfer */
            out.status = DF_STATUS_OK;
            out.length = BLE_MTU_DIAGNOSTIC_SIZE;
        }
    }
    df_core_send_frame(&out);
}

static void df_proto_handler_info_runtime_diagnostic(df_event_t *evt) {
    if (evt->type != DF_EVENT_DATA_RECEVIED) return;
    df_frame_t out = {0};
    OUT_FRAME_NO_DATA(out, DF_PROTO_CMD_INFO_RUNTIME_DIAGNOSTIC, DF_STATUS_ERR);
    if (evt->df->length == 0 && evt->df->status == 0 && evt->df->chunk == 0 &&
        runtime_diag_snapshot(out.data, sizeof(out.data))) {
        out.status = DF_STATUS_OK;
        out.length = RUNTIME_DIAG_SIZE;
    }
    df_core_send_frame(&out);
}

/* Fixed read-only report; malformed requests cannot select memory addresses.
 * Avoid interleaving the bounded hash with an unfinished storage transfer. */
static void df_proto_handler_info_boot_diagnostic(df_event_t *evt) {
    if (evt->type != DF_EVENT_DATA_RECEVIED) return;
    df_frame_t out = {0};
    OUT_FRAME_NO_DATA(out, DF_PROTO_CMD_INFO_BOOT_DIAGNOSTIC, DF_STATUS_ERR);
    if (evt->df->length == 0 && evt->df->status == 0 && evt->df->chunk == 0 &&
        df_proto_vfs_is_idle() && boot_diag_snapshot(out.data, sizeof(out.data))) {
        out.status = DF_STATUS_OK;
        out.length = BOOT_DIAG_SIZE;
    }
    df_core_send_frame(&out);
}

/* Optional cached observations only: no ADC conversion, GPIO write or reset. */
static void df_proto_handler_info_power_diagnostic(df_event_t *evt) {
    if (evt->type != DF_EVENT_DATA_RECEVIED) return;
    df_frame_t out = {0};
    OUT_FRAME_NO_DATA(out, DF_PROTO_CMD_INFO_POWER_DIAGNOSTIC, DF_STATUS_ERR);
    if (evt->df->length == 0 && evt->df->status == 0 && evt->df->chunk == 0 &&
        runtime_diag_power_snapshot(out.data, sizeof(out.data))) {
        out.status = DF_STATUS_OK;
        out.length = POWER_DIAG_SIZE;
    }
    df_core_send_frame(&out);
}

/* A cached startup trace. Reading cannot restart, mount, mutate or clear it. */
static void df_proto_handler_info_startup_diagnostic(df_event_t *evt) {
    if (evt->type != DF_EVENT_DATA_RECEVIED) return;
    df_frame_t out = {0};
    OUT_FRAME_NO_DATA(out, DF_PROTO_CMD_INFO_STARTUP_DIAGNOSTIC, DF_STATUS_ERR);
    if (!evt->df->status && !evt->df->chunk) {
        bool ready = false;
        if (!evt->df->length)
            ready = runtime_diag_startup_snapshot(out.data, sizeof(out.data), false);
        else if (evt->df->length == 1) {
            switch (evt->df->data[0]) {
                case 1: ready = runtime_diag_startup_snapshot(out.data, sizeof(out.data), true); break;
                case 2: ready = runtime_diag_startup_mount_snapshot(out.data, sizeof(out.data)); break;
                case 3: ready = runtime_diag_startup_cache_snapshot(out.data, sizeof(out.data)); break;
            }
        }
        if (ready) {
            out.status = DF_STATUS_OK;
            out.length = out.data[5];
        }
    }
    df_core_send_frame(&out);
}

#ifdef LCD_SCREEN
#if defined(BOARD_LCD) && defined(PIXL_RUNTIME_DIAGNOSTICS)
/* Current compiled provenance plus the previous fault captured at this boot.
 * This reads neither application flash contents for hashing nor a device ID. */
static void df_proto_handler_info_build_fault(df_event_t *evt) {
    if (evt->type != DF_EVENT_DATA_RECEVIED) return;
    df_frame_t out = {0};
    OUT_FRAME_NO_DATA(out, DF_PROTO_CMD_INFO_BUILD_FAULT, DF_STATUS_ERR);
    if (!evt->df->length && !evt->df->status && !evt->df->chunk) {
        const fault_note_t *note = fault_note_previous();
        memcpy(out.data, "PXBI", 4);
        out.data[4] = 1;
        out.data[5] = 80;
        out.data[6] = 1; /* compiled LCD profile */
        out.data[7] = (uint8_t)note->kind;
        memcpy(out.data + 8, version_get_source_id(), 64);
        for (unsigned i = 0; i < 4; ++i) {
            out.data[72+i] = (uint8_t)(note->sdk_id >> (8*i));
            out.data[76+i] = (uint8_t)(note->pc >> (8*i));
        }
        out.length = 80;
        out.status = DF_STATUS_OK;
    }
    df_core_send_frame(&out);
}
#endif
/* One cached result from the external flash geometry probe. Fits ATT MTU 23. */
static void df_proto_handler_info_flash_jedec(df_event_t *evt) {
    if (evt->type != DF_EVENT_DATA_RECEVIED) return;
    df_frame_t out = {0};
    OUT_FRAME_NO_DATA(out, DF_PROTO_CMD_INFO_FLASH_JEDEC, DF_STATUS_ERR);
    if (!evt->df->length && !evt->df->status && !evt->df->chunk) {
        memcpy(out.data, "PXJF", 4);
        out.data[4] = 1;
        out.data[5] = 12;
        out.data[6] = hal_spi_flash_cached_jedec(out.data + 8);
        out.length = 12;
        out.status = DF_STATUS_OK;
    }
    df_core_send_frame(&out);
}

/* Rendering and DF commands both run in the foreground. Each reply binds its
 * page to the entire framebuffer as seen during this command. The client
 * can discard a changed frame without pinning or duplicating the LCD buffer. */
static void df_proto_handler_info_display_page(df_event_t *evt) {
    if (evt->type != DF_EVENT_DATA_RECEVIED) return;
    df_frame_t out = {0};
    OUT_FRAME_NO_DATA(out, DF_PROTO_CMD_INFO_DISPLAY_PAGE, DF_STATUS_ERR);
    const df_frame_t *request = evt->df;
    if (!request->status && !request->chunk && request->length == 5 &&
        memcmp(request->data, "LCD1", 4) == 0 && request->data[4] < 8 && df_proto_vfs_is_idle()) {
        mui_t *ui = mui();
        if (ui && ui->initialized && ui->auto_update && u8g2_GetBufferTileHeight(&ui->u8g2) == 8 &&
            u8g2_GetBufferTileWidth(&ui->u8g2) == 16) {
            const uint8_t *pixels = u8g2_GetBufferPtr(&ui->u8g2);
            if (pixels && mbedtls_sha256_ret(pixels, 1024, out.data + 8, 0) == 0) {
                memcpy(out.data, "PXLC", 4);
                out.data[4] = 1;
                out.data[5] = request->data[4];
                out.data[6] = 128;
                out.data[7] = 64;
                memcpy(out.data + 40, pixels + 128 * request->data[4], 128);
                out.length = 168;
                out.status = DF_STATUS_OK;
            }
        }
    }
    df_core_send_frame(&out);
}
#endif

const df_cmd_entry_t df_proto_handler_info_entries[] = {
    {DF_PROTO_CMD_INFO_VERSION_INFO, df_proto_handler_info_get_version},
    {DF_PROTO_CMD_INFO_ENTER_DFU, df_proto_handler_info_enter_dfu},
    {DF_PROTO_CMD_INFO_CAPABILITIES, df_proto_handler_info_capabilities},
    {DF_PROTO_CMD_INFO_UI_DIAGNOSTIC, df_proto_handler_info_ui_diagnostic},
    {DF_PROTO_CMD_INFO_MTU_DIAGNOSTIC, df_proto_handler_info_mtu_diagnostic},
    {DF_PROTO_CMD_INFO_RUNTIME_DIAGNOSTIC, df_proto_handler_info_runtime_diagnostic},
    {DF_PROTO_CMD_INFO_BOOT_DIAGNOSTIC, df_proto_handler_info_boot_diagnostic},
    {DF_PROTO_CMD_INFO_POWER_DIAGNOSTIC, df_proto_handler_info_power_diagnostic},
    {DF_PROTO_CMD_INFO_STARTUP_DIAGNOSTIC, df_proto_handler_info_startup_diagnostic},
#ifdef LCD_SCREEN
    {DF_PROTO_CMD_INFO_DISPLAY_PAGE, df_proto_handler_info_display_page},
    {DF_PROTO_CMD_INFO_FLASH_JEDEC, df_proto_handler_info_flash_jedec},
#if defined(BOARD_LCD) && defined(PIXL_RUNTIME_DIAGNOSTICS)
    {DF_PROTO_CMD_INFO_BUILD_FAULT, df_proto_handler_info_build_fault},
#endif
#endif
    {0, NULL}};
