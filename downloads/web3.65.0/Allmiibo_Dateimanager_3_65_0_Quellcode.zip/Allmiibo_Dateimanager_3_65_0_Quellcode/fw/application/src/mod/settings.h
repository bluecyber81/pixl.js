#ifndef SETTINGS_H
#define SETTINGS_H

#include <stdbool.h>
#include <stdint.h>

#include "app_amiibolink.h"
#include "i18n/language.h"

#define INVALID_SLOT_INDEX 0xFF
#define AMIIDB_SORT_COLUMN_DEFAULT 0
#define AMIIDB_SORT_COLUMN_NAME 1

typedef struct {
    uint8_t backlight; // legacy 0/1 = no idle dimming; explicit LCD opt-in uses a distinct tag
    uint8_t sleep_timeout_sec;
    bool dirty;
    bool auto_gen_amiibo;
    bool auto_gen_amiibolink; // deprecated, keep for capability issue
    bool skip_driver_select;
    bool bat_mode;
    ble_amiibolink_ver_t amiibo_link_ver;
    bool hibernate_enabled;
    bool show_mem_usage;
    uint8_t lcd_backlight;
    uint8_t oled_contrast;
    bool anim_enabled;
    bool qrcode_enabled;
    Language language;
    uint8_t amiidb_data_slot_num;
    uint8_t chameleon_default_slot_index;
    uint16_t app_enable_bits; // bitmask for app enable status (1: enabled, 0: disabled)
    uint8_t amiidb_sort_column;
    uint8_t chameleon_slot_num; // chameleon available slot count (8-50)
    ble_amiibolink_mode_t amiibolink_mode; // user's preferred AmiiboLink mode (0 = not set, use default)
    bool no_sleep_mode; // don't enter sleep mode while emulating a card (all modes) or in BLE transfer mode
    bool flip_display;  // rotate the UI 180 degrees (for right-handed use)
    bool swap_buttons;  // swap left/right buttons (to match a flipped/rotated device)
} settings_data_t;

int32_t settings_init();
int32_t settings_save();
int32_t settings_reset();
bool settings_get_lcd_dim(void);
uint8_t settings_lcd_dim_idle_seconds(void);
void settings_cycle_lcd_dim(void);
settings_data_t *settings_get_data();

#endif