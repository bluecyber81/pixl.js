#include "amiidb_scene_errors.h"
#include "amiibo_helper.h"
#include "amiidb_api_fav.h"
#include "amiidb_scene.h"
#include "app_amiidb.h"
#include "mui_list_view.h"
#include "mui_alloc.h"
#include "amiidb_fav_page.h"
#include "nrf_log.h"

#include "db_header.h"
#include "mui_icons.h"
#include "settings.h"
#include "vfs.h"
#include <stdlib.h>

static void amiidb_scene_fav_list_reload(app_amiidb_t *app);
void amiidb_scene_fav_list_item_clear_cb(mui_list_item_t *p_item);

static void amiidb_scene_fav_list_text_input_event_cb(mui_text_input_event_t event, mui_text_input_t *p_text_input) {
    app_amiidb_t *app = p_text_input->user_data;
    if (event == MUI_TEXT_INPUT_EVENT_CANCELLED ||
        (event == MUI_TEXT_INPUT_EVENT_CONFIRMED && !*mui_text_input_get_input_text(p_text_input))) {
        amiidb_scene_fav_list_reload(app);
        return;
    }
    if (event == MUI_TEXT_INPUT_EVENT_CONFIRMED) {
        const char *text = mui_text_input_get_input_text(p_text_input);
        if (strlen(text) > 0) {
            int32_t res = amiidb_api_fav_create_dir(text);
            if (res == VFS_OK) {
                string_reset(app->cur_fav_dir);
                amiidb_scene_fav_list_reload(app);
            } else {
                amiidb_fav_show_error(app, res);
            }
        }
    }
}

static void amiidb_scene_fav_list_list_view_on_selected(mui_list_view_event_t event, mui_list_view_t *p_list_view,
                                                        mui_list_item_t *p_item) {
    uint16_t icon = p_item->icon;
    app_amiidb_t *app = mui_list_view_get_user_data(p_list_view);
    if (icon == ICON_PREV || icon == ICON_NEXT) {
        if (event == MUI_LIST_VIEW_EVENT_SELECTED && amiidb_fav_page_step(app, icon))
            amiidb_scene_fav_list_reload(app);
        return;
    }
    if (event == MUI_LIST_VIEW_EVENT_SELECTED) {
        switch (icon) {
        case ICON_EXIT:
            if (string_size(app->cur_fav_dir) == 0) {
                app->in_fav_folders = true;
                mui_scene_dispatcher_next_scene(app->p_scene_dispatcher, AMIIDB_SCENE_MAIN);
            } else {
                string_reset(app->cur_fav_dir);
                app->in_fav_folders = false;
                amiidb_scene_fav_list_reload(app);
            }
            break;

        case ICON_FILE: {
            amiidb_fav_t *p_fav_item = p_item->user_data;
            memcpy(&app->cur_fav, p_fav_item, sizeof(amiidb_fav_t));
            app->prev_scene_id = AMIIDB_SCENE_FAV_LIST;
            mui_scene_dispatcher_next_scene(app->p_scene_dispatcher, AMIIDB_SCENE_AMIIBO_DETAIL);
        } break;

        case ICON_FOLDER: {
            if (!mui_string_try_set_str(app->cur_fav_dir, string_get_cstr(p_item->text))) {
                mui_show_memory_error(mui()); return;
            }
            amiidb_fav_page_reset(app);
            app->in_fav_folders = false;
            amiidb_scene_fav_list_reload(app);
        } break;

        case ICON_NEW: {
            mui_text_input_set_max_length(app->p_text_input, AMIIDB_FAV_NEW_FOLDER_MAX_BYTES);
            mui_text_input_clear_input_text(app->p_text_input);
            mui_text_input_set_header(app->p_text_input, getLangString(_L_APP_AMIIDB_FAV_NEW_HEAD));
            mui_text_input_set_event_cb(app->p_text_input, amiidb_scene_fav_list_text_input_event_cb);
            mui_view_dispatcher_switch_to_view(app->p_view_dispatcher, AMIIDB_VIEW_ID_INPUT);
        } break;
        }
    } else if (event == MUI_LIST_VIEW_EVENT_LONG_SELECTED) {
        if (icon == ICON_FILE) {
            amiidb_fav_t *p_fav_item = p_item->user_data;
            memcpy(&app->cur_fav, p_fav_item, sizeof(amiidb_fav_t));
            app->in_fav_folders = false;
            mui_scene_dispatcher_next_scene(app->p_scene_dispatcher, AMIIDB_SCENE_FAV_LIST_MENU);
        } else if (icon == ICON_FOLDER) {
            memset(&app->cur_fav, 0, sizeof(amiidb_fav_t));
            if (!mui_string_try_set_str(app->cur_fav_dir, string_get_cstr(p_item->text))) {
                mui_show_memory_error(mui()); return;
            }
            app->in_fav_folders = true;
            mui_scene_dispatcher_next_scene(app->p_scene_dispatcher, AMIIDB_SCENE_FAV_LIST_MENU);
        }
    }
}

static int amiidb_scene_fav_list_list_view_sort_cb(const mui_list_item_t *p_item_a, const mui_list_item_t *p_item_b) {
    /* This sorter runs before controls are appended: only folders and files. */
    if (p_item_a->icon != p_item_b->icon) return (int)p_item_a->icon - (int)p_item_b->icon;
    if (p_item_a->icon == ICON_FOLDER) return string_cmp(p_item_a->text, p_item_b->text);
    return fav_record_compare(p_item_a->user_data, p_item_b->user_data);
}


#define FAV_PAGE_SIZE 24u
typedef struct {
    app_amiidb_t *app;
    uint32_t eligible, excluded, aliases;
    int32_t result;
    bool folders_only;
} fav_page_context_t;

static void fav_item_key(const mui_list_item_t *item, amiidb_fav_info_t *key) {
    key->fav_type = item->icon == ICON_FOLDER ? FAV_TYPE_FOLDER : FAV_TYPE_FAV;
    if (key->fav_type == FAV_TYPE_FOLDER)
        snprintf(key->fav_data.folder_name, sizeof(key->fav_data.folder_name), "%s", string_get_cstr(item->text));
    else key->fav_data.fav = *(amiidb_fav_t *)item->user_data;
}

static int fav_key_compare(const amiidb_fav_info_t *a, const amiidb_fav_info_t *b) {
    if (a->fav_type != b->fav_type) return (int)a->fav_type - (int)b->fav_type;
    if (a->fav_type == FAV_TYPE_FOLDER) return strcmp(a->fav_data.folder_name, b->fav_data.folder_name);
    return fav_record_compare(&a->fav_data.fav, &b->fav_data.fav);
}

void amiidb_fav_page_reset(app_amiidb_t *app) {
    app->fav_page_direction = 0;
    app->fav_page_focus = 0;
    app->fav_page_number = 0;
}

bool amiidb_fav_page_step(app_amiidb_t *app, uint16_t icon) {
    mui_list_item_t *anchor = NULL;
    for (size_t i = 0; i < mui_list_view_item_size(app->p_list_view); i++) {
        mui_list_item_t *item = mui_list_item_array_get(app->p_list_view->items, i);
        if (item->icon != ICON_FILE && item->icon != ICON_FOLDER) continue;
        anchor = item;
        if (icon == ICON_PREV) break;
    }
    if (!anchor) return false;
    if (app->fav_page_number) {
        if (icon == ICON_NEXT) app->fav_page_number++;
        else if (app->fav_page_number > 1) app->fav_page_number--;
    }
    fav_item_key(anchor, &app->fav_page_anchor);
    app->fav_page_direction = icon == ICON_PREV ? -1 : 1;
    app->fav_page_focus = 0;
    return true;
}

static void amiidb_scene_fav_list_read_cb(amiidb_fav_info_t *info, void *ctx) {
    fav_page_context_t *page = ctx;
    app_amiidb_t *app = page->app;
    if (page->result != VFS_OK || (page->folders_only && info->fav_type != FAV_TYPE_FOLDER)) return;
    if (info->fav_type == FAV_TYPE_FAV && info->name_alias) page->aliases++;
    int comparison = fav_key_compare(info, &app->fav_page_anchor);
    if (app->fav_page_direction && (app->fav_page_direction > 0 ? comparison <= 0 : comparison >= 0)) {
        page->excluded++; return;
    }
    mui_list_item_t *replace = NULL;
    size_t count = mui_list_view_item_size(app->p_list_view);
    if (info->fav_type == FAV_TYPE_FAV) {
        for (size_t i = 0; i < count; i++) {
            const mui_list_item_t *row = mui_list_item_array_get(app->p_list_view->items, i);
            if (row->icon == ICON_FILE && !fav_record_compare(row->user_data, &info->fav_data.fav)) return;
        }
    }
    page->eligible++;
    if (count == FAV_PAGE_SIZE) {
        replace = mui_list_item_array_get(app->p_list_view->items, app->fav_page_direction < 0 ? 0 : count - 1);
        amiidb_fav_info_t worst;
        fav_item_key(replace, &worst);
        comparison = fav_key_compare(info, &worst);
        if (app->fav_page_direction < 0 ? comparison <= 0 : comparison >= 0) return;
    }
    amiidb_fav_t *favorite = NULL;
    const char *text = info->fav_data.folder_name;
    char unknown[32];
    uint16_t icon = ICON_FOLDER;
    if (info->fav_type == FAV_TYPE_FAV) {
        favorite = mui_mem_malloc(sizeof(*favorite));
        if (!favorite) { page->result = VFS_ERR_NOMEM; return; }
        *favorite = info->fav_data.fav;
        const db_amiibo_t *figure = get_amiibo_by_id(favorite->amiibo_head, favorite->amiibo_tail);
        snprintf(unknown, sizeof(unknown), "Amiibo[%08x:%08x]", favorite->amiibo_head, favorite->amiibo_tail);
        text = figure ? get_amiibo_display_name(figure) : unknown;
        icon = ICON_FILE;
    }
    bool added = replace ? mui_string_try_set_str(replace->text, text)
                         : mui_list_view_try_add_item_ext(app->p_list_view, icon, text, NULL, favorite);
    if (!added) { mui_mem_free(favorite); page->result = VFS_ERR_NOMEM; return; }
    if (replace) {
        amiidb_scene_fav_list_item_clear_cb(replace);
        replace->icon = icon;
        replace->user_data = favorite;
    }
    mui_list_view_sort(app->p_list_view, amiidb_scene_fav_list_list_view_sort_cb);
}

/* Rank reconstruction is needed only after a non-local detail jump or a v1
 * resume. Canonical directories use the existing page scan. With aliases, count
 * canonical markers/folders once and each additional logical ID once. */
typedef struct {
    const amiidb_fav_t *first;
    amiidb_fav_t *keys;
    amiidb_fav_t after;
    uint32_t ordinary;
    size_t used, batch;
    bool resumed, more;
} fav_rank_t;

static int fav_rank_compare(const void *a, const void *b) { return fav_record_compare(a, b); }

static void fav_rank_compact(fav_rank_t *rank) {
    qsort(rank->keys, rank->used, sizeof(*rank->keys), fav_rank_compare);
    size_t distinct = 0;
    for (size_t i = 0; i < rank->used; i++) {
        if (distinct && !fav_record_compare(&rank->keys[i], &rank->keys[distinct - 1])) continue;
        if (distinct == rank->batch) { rank->more = true; break; }
        rank->keys[distinct++] = rank->keys[i];
    }
    rank->used = distinct;
}

static void fav_rank_read(amiidb_fav_info_t *info, void *context) {
    fav_rank_t *rank = context;
    if (info->fav_type == FAV_TYPE_FOLDER) {
        if (!rank->resumed) rank->ordinary++;
        return;
    }
    const amiidb_fav_t *fav = &info->fav_data.fav;
    if (fav_record_compare(fav, rank->first) >= 0) return;
    if (!info->name_alias) {
        if (!rank->resumed) rank->ordinary++;
    } else if (!rank->resumed || fav_record_compare(fav, &rank->after) > 0) {
        rank->keys[rank->used++] = *fav;
        if (rank->used == 2 * rank->batch) fav_rank_compact(rank);
    }
}

static bool fav_alias_rank(const char *folder, const amiidb_fav_t *first, uint32_t aliases, uint32_t *before) {
    /* A batch at least ceil(sqrt(alias count)) bounds the number of complete
     * scans. Common-sized folders use up to 64 IDs per batch when RAM permits. */
    size_t minimum = 1;
    while (minimum < (aliases - 1) / minimum + 1) minimum++;
    size_t batch = minimum < 64 ? 64 : minimum;
    if (batch > aliases) batch = aliases;
    fav_rank_t rank = {.first = first, .batch = batch};
    rank.keys = mui_mem_malloc(2 * rank.batch * sizeof(*rank.keys));
    if (!rank.keys && batch != minimum) {
        rank.batch = minimum;
        rank.keys = mui_mem_malloc(2 * rank.batch * sizeof(*rank.keys));
    }
    if (!rank.keys) return false;
    bool success = false;
    uint32_t additional = 0;
    for (;;) {
        rank.more = false;
        rank.used = 0;
        if (amiidb_api_fav_list_dir(folder, fav_rank_read, &rank) != VFS_OK) break;
        fav_rank_compact(&rank);
        for (size_t i = 0; i < rank.used; i++) {
            bool canonical = false;
            if (rank.ordinary && amiidb_api_fav_has_canonical(folder, &rank.keys[i], &canonical) != VFS_OK)
                goto done;
            if (!canonical) additional++;
        }
        if (!rank.more) {
            *before = rank.ordinary + additional;
            success = true;
            break;
        }
        rank.after = rank.keys[rank.used - 1];
        rank.resumed = true;
    }
done:
    mui_mem_free(rank.keys);
    return success;
}

static void fav_hide_page_hint(app_amiidb_t *app) {
    if (app->fav_page_hint_visible) {
        app->p_toast_view->is_visible = false;
        app->fav_page_hint_visible = false;
    }
}

void amiidb_fav_page_load(app_amiidb_t *app, bool folders_only) {
    if (!folders_only) fav_hide_page_hint(app);
    uint8_t mode = folders_only ? 1 : string_empty_p(app->cur_fav_dir) ? 2 : 3;
    if (mode != app->fav_page_mode) { amiidb_fav_page_reset(app); app->fav_page_mode = mode; }
    mui_list_view_clear_items_with_cb(app->p_list_view, amiidb_scene_fav_list_item_clear_cb);
    fav_page_context_t page = {.app = app, .folders_only = folders_only};
    int32_t result = amiidb_api_fav_list_dir(folders_only ? "" : string_get_cstr(app->cur_fav_dir), amiidb_scene_fav_list_read_cb, &page);
    if (result == VFS_OK) result = page.result;
    if (result == VFS_OK && !page.eligible && page.excluded) {
        amiidb_fav_page_reset(app);
        amiidb_fav_page_load(app, folders_only);
        return;
    }
    if (result != VFS_OK) {
        /* A failed traversal is never presented as the complete directory. */
        mui_list_view_clear_items_with_cb(app->p_list_view, amiidb_scene_fav_list_item_clear_cb);
        if (result == VFS_ERR_NOMEM) { mui_show_memory_error(mui()); return; }
        amiidb_fav_show_error(app, result);
    } else {
        if (folders_only || (!page.eligible && string_empty_p(app->cur_fav_dir)))
            mui_list_view_add_item(app->p_list_view, ICON_NEW, _T(APP_AMIIDB_NEW), NULL);
        bool previous = app->fav_page_direction < 0 ? page.eligible > FAV_PAGE_SIZE : page.excluded > 0;
        bool next = app->fav_page_direction < 0 ? page.excluded > 0 : page.eligible > FAV_PAGE_SIZE;
        if (mode == 3 && (previous || next)) {
            if (!previous) app->fav_page_number = 1;
            else if (!app->fav_page_number) {
                /* A restored or relocated anchor has no live page counter.
                 * Reuse this traversal to locate its first displayed row. */
                uint32_t before = app->fav_page_direction < 0
                    ? page.eligible - mui_list_view_item_size(app->p_list_view) : page.excluded;
                const mui_list_item_t *first = mui_list_item_array_get(app->p_list_view->items, 0);
                if (!page.aliases || first->icon == ICON_FOLDER ||
                    fav_alias_rank(string_get_cstr(app->cur_fav_dir), first->user_data, page.aliases, &before))
                    app->fav_page_number = 1 + before / FAV_PAGE_SIZE;
            }
            const char *folder = string_get_cstr(app->cur_fav_dir);
            /* Leave room for the page suffix even with the widest LCD glyphs.
             * Copy complete UTF-8 characters and keep the stored name intact. */
            char shortened[26];
            if (strlen(folder) > sizeof(shortened) - 4) {
                size_t cut = sizeof(shortened) - 4;
                while (cut && ((uint8_t)folder[cut] & 0xC0) == 0x80) cut--;
                memcpy(shortened, folder, cut);
                memcpy(shortened + cut, "...", 4);
                folder = shortened;
            }
            char hint[sizeof(shortened) + 24];
            if (app->fav_page_number)
                snprintf(hint, sizeof(hint), _T(DE3_FAVORITE_FOLDER_PAGE), folder, (unsigned)app->fav_page_number);
            else
                snprintf(hint, sizeof(hint), "%s", folder); /* Optional rank scratch/I/O unavailable. */
            mui_toast_view_show(app->p_toast_view, hint);
            app->fav_page_hint_visible = true;
        }
        if (previous) mui_list_view_add_item(app->p_list_view, ICON_PREV, _T(DE3_PREVIOUS_PAGE), NULL);
        if (next) mui_list_view_add_item(app->p_list_view, ICON_NEXT, _T(DE3_NEXT_PAGE), NULL);
    }
    mui_list_view_add_item(app->p_list_view, ICON_EXIT, _T(APP_AMIIDB_BACK), NULL);
    mui_list_view_set_focus(app->p_list_view, app->fav_page_focus);
}

/* Keep destination paging transient, including while a sleep snapshot is taken. */
bool amiidb_fav_select_page_step(app_amiidb_t *app, uint16_t icon) {
    amiidb_fav_info_t saved_anchor = app->fav_page_anchor;
    int8_t saved_direction = app->fav_page_direction;
    uint8_t saved_focus = app->fav_page_focus;
    uint16_t saved_number = app->fav_page_number;
    bool stepped = amiidb_fav_page_step(app, icon);
    if (stepped) {
        app->fav_select_anchor = app->fav_page_anchor;
        app->fav_select_direction = app->fav_page_direction;
    }
    app->fav_page_anchor = saved_anchor;
    app->fav_page_direction = saved_direction;
    app->fav_page_focus = saved_focus;
    app->fav_page_number = saved_number;
    return stepped;
}

void amiidb_fav_select_page_load(app_amiidb_t *app) {
    amiidb_fav_info_t saved_anchor = app->fav_page_anchor;
    int8_t saved_direction = app->fav_page_direction;
    uint8_t saved_focus = app->fav_page_focus, saved_mode = app->fav_page_mode;
    uint16_t saved_number = app->fav_page_number;
    app->fav_page_anchor = app->fav_select_anchor;
    app->fav_page_direction = app->fav_select_direction;
    app->fav_page_focus = 0;
    app->fav_page_mode = 1;
    amiidb_fav_page_load(app, true);
    app->fav_select_anchor = app->fav_page_anchor;
    app->fav_select_direction = app->fav_page_direction;
    app->fav_page_anchor = saved_anchor;
    app->fav_page_direction = saved_direction;
    app->fav_page_focus = saved_focus;
    app->fav_page_mode = saved_mode;
    app->fav_page_number = saved_number;
}

static bool fav_focus_visible(app_amiidb_t *app, const amiidb_fav_t *favorite) {
    mui_list_view_t *list = app->p_list_view;
    for (uint32_t i = 0; i < mui_list_view_item_size(list); i++) {
        const mui_list_item_t *row = mui_list_item_array_get(list->items, i);
        if (row->icon != ICON_FILE || !row->user_data ||
            fav_record_compare(row->user_data, favorite) != 0) continue;
        if (mui_list_view_get_focus(list) != i) mui_list_view_set_focus(list, i);
        app->fav_page_focus = i;
        return true;
    }
    return false;
}

typedef struct {
    amiidb_fav_info_t target, predecessor;
    bool found, have_predecessor;
} fav_seek_context_t;

static void fav_seek_read_cb(amiidb_fav_info_t *info, void *context) {
    fav_seek_context_t *seek = context;
    int cmp = fav_key_compare(info, &seek->target);
    if (cmp == 0) seek->found = true;
    else if (cmp < 0 && (!seek->have_predecessor ||
                        fav_key_compare(info, &seek->predecessor) > 0)) {
        seek->predecessor = *info;
        seek->have_predecessor = true;
    }
}

bool amiidb_fav_page_focus(app_amiidb_t *app, const amiidb_fav_t *favorite) {
    if (fav_focus_visible(app, favorite)) return true;
    fav_seek_context_t seek = {.target = {.fav_type = FAV_TYPE_FAV}};
    seek.target.fav_data.fav = *favorite;
    int32_t result = amiidb_api_fav_list_dir(string_get_cstr(app->cur_fav_dir), fav_seek_read_cb, &seek);
    if (result != VFS_OK) { amiidb_fav_show_error(app, result); return false; }
    if (!seek.found) return false;
    /* One bounded scan finds the actual predecessor, without synthetic ID
     * arithmetic or loading every favorite into RAM. The new page contains
     * the selected favorite first; already-visible selections keep their page. */
    amiidb_fav_page_reset(app);
    if (seek.have_predecessor) {
        app->fav_page_anchor = seek.predecessor;
        app->fav_page_direction = 1;
    }
    amiidb_fav_page_load(app, false);
    return fav_focus_visible(app, favorite);
}

static void amiidb_scene_fav_list_reload(app_amiidb_t *app) {
    amiidb_fav_page_load(app, false);
    mui_list_view_set_selected_cb(app->p_list_view, amiidb_scene_fav_list_list_view_on_selected);
    mui_list_view_set_user_data(app->p_list_view, app);
    mui_view_dispatcher_switch_to_view(app->p_view_dispatcher, AMIIDB_VIEW_ID_LIST);
}

void amiidb_scene_fav_list_item_clear_cb(mui_list_item_t *p_item) {
    if (p_item->icon == ICON_FILE) {
        amiidb_fav_t *p_fav_item = (amiidb_fav_t *)p_item->user_data;
        mui_mem_free(p_fav_item);
    }
}

void amiidb_scene_fav_list_on_enter(void *user_data) {
    app_amiidb_t *app = (app_amiidb_t *)user_data;
    amiidb_scene_fav_list_reload(app);
}

void amiidb_scene_fav_list_on_exit(void *user_data) {
    app_amiidb_t *app = (app_amiidb_t *)user_data;
    fav_hide_page_hint(app);
    app->fav_page_focus = mui_list_view_get_focus(app->p_list_view);
    mui_list_view_set_selected_cb(app->p_list_view, NULL);
    mui_list_view_clear_items_with_cb(app->p_list_view, amiidb_scene_fav_list_item_clear_cb);
}
