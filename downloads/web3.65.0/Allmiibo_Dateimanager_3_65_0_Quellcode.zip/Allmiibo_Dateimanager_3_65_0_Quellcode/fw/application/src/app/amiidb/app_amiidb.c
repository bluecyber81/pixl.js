#include "ntag_emu.h"
#include "app_amiidb.h"
#include "mini_app_registry.h"

#include "mui_include.h"

#include "amiidb_scene.h"

#include "mui_list_view.h"

#include "cache.h"
#include "m-string.h"
#include "settings.h"

#include "amiibo_helper.h"
#include "app_amiidb_resume.h"
#include "amiibo_model_details.h"

static void catalog_card_back(amiibo_view_event_t event, amiibo_view_t *view) {
    if (event != AMIIBO_VIEW_EVENT_MENU) return;
    app_amiidb_t *app = view->user_data;
    mui_view_dispatcher_switch_to_view(app->p_view_dispatcher, AMIIDB_VIEW_ID_LIST);
}

bool amiidb_show_catalog_card(app_amiidb_t *app, const db_amiibo_t *entry, mui_list_view_event_t event) {
    if (!entry || (event != MUI_LIST_VIEW_EVENT_SELECTED && event != MUI_LIST_VIEW_EVENT_LONG_SELECTED))
        return false;
    amiibo_detail_model_t model = amiibo_detail_model(entry->head, entry->tail);
    if (model == MODEL_DEFAULT || (event == MUI_LIST_VIEW_EVENT_SELECTED &&
                                   !is_valid_amiibo_v3(entry->head, entry->tail))) return false;
    /* Keep the current list scene and its focus. Metadata has no tag, slot or
     * NFC session, so V3 catalog browsing cannot reach tag generation. */
    amiibo_view_t *view = app->p_amiibo_view;
    view->catalog_entry = entry;
    view->info_page = 1;
    view->game_id = model == OOT_YOUNG_LINK || model == OOT_YOUNG_ZELDA ? OOT_GAME_ID : AIR_RIDERS_GAME_ID;
    amiibo_view_set_event_cb(view, catalog_card_back);
    mui_view_dispatcher_switch_to_view(app->p_view_dispatcher, AMIIDB_VIEW_ID_DETAIL);
    return true;
}

static void app_amiidb_on_run(mini_app_inst_t *p_app_inst);
static void app_amiidb_on_kill(mini_app_inst_t *p_app_inst);
static void app_amiidb_on_event(mini_app_inst_t *p_app_inst, mini_app_event_t *p_event);

static void app_amiidb_try_mount_drive(app_amiidb_t *p_app_inst) {
    vfs_driver_t *p_driver = vfs_get_driver(VFS_DRIVE_EXT);
    if (p_driver->mounted()) {
        amiibo_helper_try_load_amiibo_keys_from_vfs();
    } else {
        int32_t err = p_driver->mount();
        amiibo_helper_try_load_amiibo_keys_from_vfs();
    }

    p_driver->create_dir("/amiibo");
    p_driver->create_dir("/amiibo/fav");
    p_driver->create_dir("/amiibo/data");
}

void app_amiidb_on_run(mini_app_inst_t *p_app_inst) {

    app_amiidb_t *p_app_handle = mui_mem_malloc(sizeof(app_amiidb_t));
    if (!p_app_handle) { p_app_inst->p_handle = NULL; return; }
    memset(p_app_handle, 0, sizeof(app_amiidb_t));
    /* Construct every owned UI object before any app activation. */
    p_app_handle->p_view_dispatcher = mui_view_dispatcher_create();
    if (!p_app_handle->p_view_dispatcher) goto startup_failed;
    p_app_handle->p_list_view = mui_list_view_create();
    if (!p_app_handle->p_list_view) goto startup_failed;
    p_app_handle->p_text_input = mui_text_input_create();
    if (!p_app_handle->p_text_input) goto startup_failed;
    p_app_handle->p_msg_box = mui_msg_box_create();
    if (!p_app_handle->p_msg_box) goto startup_failed;
    p_app_handle->p_amiibo_view = amiibo_view_create();
    if (!p_app_handle->p_amiibo_view) goto startup_failed;
    p_app_handle->p_toast_view = mui_toast_view_create();
    if (!p_app_handle->p_toast_view) goto startup_failed;
    p_app_handle->p_scene_dispatcher = mui_scene_dispatcher_create();
    if (!p_app_handle->p_scene_dispatcher) goto startup_failed;
    p_app_handle->p_scene_dispatcher->transition_guard = ntag_emu_prepare_change;
    p_app_handle->p_view_dispatcher_toast = mui_view_dispatcher_create();
    if (!p_app_handle->p_view_dispatcher_toast) goto startup_failed;
    p_app_inst->p_handle = p_app_handle;

    

    mui_list_view_set_user_data(p_app_handle->p_list_view, p_app_handle);
    mui_text_input_set_user_data(p_app_handle->p_text_input, p_app_handle);
    mui_msg_box_set_user_data(p_app_handle->p_msg_box, p_app_handle);
    p_app_handle->p_amiibo_view->user_data = p_app_handle;
    mui_toast_view_set_user_data(p_app_handle->p_toast_view, p_app_handle);
    
    string_init(p_app_handle->cur_fav_dir);
    string_init(p_app_handle->search_str);
    p_app_handle->in_fav_folders = true;

    amiidb_fav_array_init(p_app_handle->fav_array);


    mui_scene_dispatcher_set_user_data(p_app_handle->p_scene_dispatcher, p_app_handle);
    mui_scene_dispatcher_set_scene_defines(p_app_handle->p_scene_dispatcher, amiidb_scene_defines, AMIIDB_SCENE_MAX);
    mui_mui_scene_dispatcher_set_default_scene_id(p_app_handle->p_scene_dispatcher, AMIIDB_SCENE_MAIN);

    mui_view_dispatcher_add_view(p_app_handle->p_view_dispatcher, AMIIDB_VIEW_ID_LIST,
                                 mui_list_view_get_view(p_app_handle->p_list_view));
    mui_view_dispatcher_add_view(p_app_handle->p_view_dispatcher, AMIIDB_VIEW_ID_DETAIL,
                                 amiibo_view_get_view(p_app_handle->p_amiibo_view));
    mui_view_dispatcher_add_view(p_app_handle->p_view_dispatcher, AMIIDB_VIEW_ID_INPUT,
                                 mui_text_input_get_view(p_app_handle->p_text_input));
    mui_view_dispatcher_add_view(p_app_handle->p_view_dispatcher, AMIIDB_VIEW_ID_MSG_BOX,
                                 mui_msg_box_get_view(p_app_handle->p_msg_box));

    mui_view_dispatcher_attach(p_app_handle->p_view_dispatcher, MUI_LAYER_FULLSCREEN);

    mui_view_dispatcher_add_view(p_app_handle->p_view_dispatcher_toast, AMIIDB_VIEW_ID_TOAST,
                                 mui_toast_view_get_view(p_app_handle->p_toast_view));
    mui_view_dispatcher_attach(p_app_handle->p_view_dispatcher_toast, MUI_LAYER_TOAST);
    mui_view_dispatcher_switch_to_view(p_app_handle->p_view_dispatcher_toast, AMIIDB_VIEW_ID_TOAST);

    app_amiidb_try_mount_drive(p_app_handle);

    extern const ntag_t default_ntag215;
    APP_ERROR_CHECK(ntag_emu_init(&default_ntag215));

    if (!app_amiidb_restore_cache(p_app_handle, p_app_inst->p_retain_data))
        mui_scene_dispatcher_next_scene(p_app_handle->p_scene_dispatcher, AMIIDB_SCENE_MAIN);

    return;

startup_failed:
    mui_view_dispatcher_free(p_app_handle->p_view_dispatcher_toast);
    mui_scene_dispatcher_free(p_app_handle->p_scene_dispatcher);
    mui_toast_view_free(p_app_handle->p_toast_view);
    amiibo_view_free(p_app_handle->p_amiibo_view);
    mui_msg_box_free(p_app_handle->p_msg_box);
    mui_text_input_free(p_app_handle->p_text_input);
    mui_list_view_free(p_app_handle->p_list_view);
    mui_view_dispatcher_free(p_app_handle->p_view_dispatcher);
    mui_mem_free(p_app_handle);
    p_app_inst->p_handle = NULL;
}

void app_amiidb_on_kill(mini_app_inst_t *p_app_inst) {
    app_amiidb_t *p_app_handle = p_app_inst->p_handle;
    if (!p_app_handle) return;

    /* Complete pending NFC persistence before recording IDs or releasing UI. */
    if (!ntag_emu_prepare_change()) return;
    uint32_t current_scene_id = mui_scene_dispatcher_current_scene(p_app_handle->p_scene_dispatcher);
    if (p_app_inst->p_retain_data && app_amiidb_info.hibernate_enabled)
        app_amiidb_save_cache(p_app_handle, p_app_inst->p_retain_data, current_scene_id);
    else if (p_app_inst->p_retain_data)
        memset(p_app_inst->p_retain_data, 0, CACHEDATASIZE);
    /* App3 reconstructs generated tags or reloads persisted slots. Never retain
     * their plaintext contents in the common App2 tag cache. */
    memset(&(cache_get_data()->ntag), 0, sizeof(ntag_t));

    /* Stop scene-owned timers/callbacks while all views and app data are alive. */
    mui_scene_dispatcher_exit(p_app_handle->p_scene_dispatcher);

    mui_view_dispatcher_detach(p_app_handle->p_view_dispatcher, MUI_LAYER_FULLSCREEN);
    mui_view_dispatcher_free(p_app_handle->p_view_dispatcher);
    mui_list_view_free(p_app_handle->p_list_view);
    mui_text_input_free(p_app_handle->p_text_input);
    mui_msg_box_free(p_app_handle->p_msg_box);
    amiibo_view_free(p_app_handle->p_amiibo_view);
    mui_toast_view_free(p_app_handle->p_toast_view);
    mui_scene_dispatcher_free(p_app_handle->p_scene_dispatcher);

    mui_view_dispatcher_detach(p_app_handle->p_view_dispatcher_toast, MUI_LAYER_TOAST);
    mui_view_dispatcher_free(p_app_handle->p_view_dispatcher_toast);

    string_clear(p_app_handle->cur_fav_dir);
    string_clear(p_app_handle->search_str);
    amiidb_fav_array_clear(p_app_handle->fav_array);

    mui_mem_free(p_app_handle);

    p_app_inst->p_handle = NULL;
}

void app_amiidb_on_event(mini_app_inst_t *p_app_inst, mini_app_event_t *p_event) {}

const mini_app_t app_amiidb_info = {.id = MINI_APP_ID_AMIIDB,
                                    .name = "Amiibo数据库",
                                    .name_i18n_key = _L_APP_AMIIDB,
                                    .icon = 0xe0ba,
                                    .sys = false,
                                    .deamon = false,
                                    .hibernate_enabled = true,
                                    .icon_32x32 = &app_amiibo_database_32x32,
                                    .run_cb = app_amiidb_on_run,
                                    .kill_cb = app_amiidb_on_kill,
                                    .on_event_cb = app_amiidb_on_event};
