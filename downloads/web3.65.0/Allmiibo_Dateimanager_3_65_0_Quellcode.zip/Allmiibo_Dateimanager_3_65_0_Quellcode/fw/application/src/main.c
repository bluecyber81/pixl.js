/**
 * Copyright (c) 2017 - 2020, Nordic Semiconductor ASA
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form, except as embedded into a Nordic
 *    Semiconductor ASA integrated circuit in a product or a software update for
 *    such product, must reproduce the above copyright notice, this list of
 *    conditions and the following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. Neither the name of Nordic Semiconductor ASA nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * 4. This software, with or without modification, must only be used with a
 *    Nordic Semiconductor ASA integrated circuit.
 *
 * 5. Any software provided in binary form under this license must not be reverse
 *    engineered, decompiled, modified and/or disassembled.
 *
 * THIS SOFTWARE IS PROVIDED BY NORDIC SEMICONDUCTOR ASA "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NORDIC SEMICONDUCTOR ASA OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

/** @file
 *
 * @defgroup nfc_writable_ndef_msg_example_main main.c
 * @{
 * @ingroup nfc_writable_ndef_msg_example
 * @brief The application main file of NFC writable NDEF message example.
 *
 */

#include "app_error.h"
#include "app_scheduler.h"
#include "boards.h"
#if defined(PIXL_SMALL_CREATE_ENABLE) && defined(VFS_PACKED_LFS_ENABLE)
#include "df_proto_vfs.h"
#endif
#include "nfc_ndef_msg.h"
#include "nfc_t4t_lib.h"
#include "nordic_common.h"
#include "nrf_error.h"
#include "nrf_log_ctrl.h"
#include <stdbool.h>
#include <stdint.h>

#include "app_button.h"
#include "app_timer.h"
#include "bsp.h"
#include "bsp_nfc.h"
#include "nrf_delay.h"
#include "nrf_drv_clock.h"
#include "nrf_gpio.h"
#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"
#include "nrf_power.h"

#include "ntag_emu.h"

#include "ntag_store.h"

#include "bat.h"
#include "mod/runtime_diag.h"
#include "mod/fault_note.h"
#include "ble_main.h"
#include "ble_remote.h"

#include "nrf_sdh.h"

#include "mem_manager.h"
#include "nrf_crypto.h"

#include "nrf_pwr_mgmt.h"

#include "amiibo_helper.h"
#include "amiibo_scene.h"

#include "mini_app_launcher.h"
#include "mini_app_registry.h"
#include "mui_include.h"
#include "mui_mem.h"

#include "hal_spi_bus.h"
#include "hal_nfc_t2t.h"
#include "hal_spi_flash.h"

#include "tag_helper.h"

#include "cache.h"
#include "i18n/language.h"
#include "settings.h"
#ifdef VFS_PACKED_LFS_ENABLE
#include "vfs_packed_runtime.h"
#endif

#define APP_SCHED_MAX_EVENT_SIZE 4 /**< Maximum size of scheduler events. */
#define APP_SCHED_QUEUE_SIZE 16    /**< Maximum number of events in the scheduler queue. */

#define BTN_ID_SLEEP 1 /**< ID of button used to put the application into sleep mode. */
#define BTN_ACTION_KEY1_LONGPUSH BSP_EVENT_KEY_LAST + 9

#define APP_SHUTDOWN_HANDLER_PRIORITY 1

int8_t g_usb_led_marquee_enable = 0; /** dummy for chameleon */

static bool is_emulating_app(mini_app_launcher_t *p_launcher) {
    mini_app_inst_t *p_inst = p_launcher->p_main_app_inst;
    if (!p_inst) {
        return false;
    }
    uint32_t id = p_inst->p_app->id;
    return id == MINI_APP_ID_AMIIBO || id == MINI_APP_ID_AMIIDB ||
           id == MINI_APP_ID_AMIIBOLINK || id == MINI_APP_ID_CHAMELEON ||
           id == MINI_APP_ID_BLE;
}

// #define SPI_FLASH

/**
 *@brief Function for initializing logging.
 */
static void log_init(void) {
    ret_code_t err_code = NRF_LOG_INIT(NULL);
    APP_ERROR_CHECK(err_code);

    NRF_LOG_DEFAULT_BACKENDS_INIT();
}

void bsp_evt_execute(void *p_event_data, uint16_t event_size) {

    bsp_event_t *evt_p = (bsp_event_t *)p_event_data;
    bsp_event_t evt = *evt_p;
    NRF_LOG_DEBUG("bsp event: %d\n", evt);
    // mui_input_on_bsp_event(evt);

    switch (evt) {
    case BSP_EVENT_KEY_0:
    case BSP_EVENT_KEY_1:
    case BSP_EVENT_KEY_2:
    case BTN_ACTION_KEY1_LONGPUSH:
        nrf_pwr_mgmt_feed();
        break;
    default:
        break;
    }
}

void bsp_evt_handler(bsp_event_t evt) { app_sched_event_put(&evt, sizeof(evt), bsp_evt_execute); }

/**
 * @brief Function for shutdown events.
 *
 * @param[in]   event       Shutdown type.
 */
static bool shutdown_handler(nrf_pwr_mgmt_evt_t event) {
    ret_code_t err_code;

    switch (event) {
    case NRF_PWR_MGMT_EVT_PREPARE_WAKEUP:

        NRF_LOG_DEBUG("go sleep");

        /* Flush accepted NFC writes before app retention/teardown, even if the
         * RF field is still present. Then close BLE before flash sleep. */
        if (!mini_app_launcher_prepare_exit(mini_app_launcher(), MINI_APP_EXIT_SLEEP)) {
            nrf_pwr_mgmt_cancel_shutdown();
            return false;
        }
        ble_remote_shutdown();
        ble_disable();
        ble_process_pending();

        if (!mini_app_launcher_sleep(mini_app_launcher())) {
            mini_app_launcher_cancel_exit(mini_app_launcher());
            nrf_pwr_mgmt_cancel_shutdown();
            return false;
        }

        // save ntag to cache
        cache_data_t *p_cache_data = cache_get_data();
#ifdef VFS_PACKED_LFS_ENABLE
        if (vfs_packed_recovery_required()) {
            /* NFC was intentionally not initialized. Do not mark its zeroed
             * RAM as a valid retained tag for the first normal restart. */
            extern const ntag_t default_ntag215;
            memset(p_cache_data, 0, sizeof(*p_cache_data));
            memcpy(&p_cache_data->ntag, &default_ntag215, sizeof(ntag_t));
        } else
#endif
        {
            memcpy(&p_cache_data->ntag, ntag_emu_get_current_tag(), sizeof(ntag_t));
        }

        cache_save();

        // Complete the journal while the filesystem is awake. A failed save must
        // not trap a low-battery device awake; existing recovery data is retained.
        int32_t save_result = settings_save();
        if (save_result != NRF_SUCCESS) {
            NRF_LOG_WARNING("Settings save before sleep failed: %ld", (long)save_result);
        }

        mui_deinit(mui());

        hal_spi_flash_sleep();

        // Button teardown resets GPIO to a disconnected input without a pull.
        // The SDK wake helper only sets SENSE, so restore the input first.
        nrf_gpio_cfg_input(bsp_board_button_idx_to_pin(BTN_ID_SLEEP), BUTTON_PULL);
        err_code = bsp_wakeup_button_enable(BTN_ID_SLEEP);
        APP_ERROR_CHECK(err_code);

        // NFC is not initialized while storage recovery owns the application.
#ifdef VFS_PACKED_LFS_ENABLE
        if (!vfs_packed_recovery_required())
#endif
        {
            err_code = bsp_nfc_sleep_mode_prepare();
            APP_ERROR_CHECK(err_code);
        }

        // Turn off LED to indicate that the device entered System OFF mode.
        bsp_board_leds_off();

        break;

    default:
        break;
    }

    return true;
}

NRF_PWR_MGMT_HANDLER_REGISTER(shutdown_handler, APP_SHUTDOWN_HANDLER_PRIORITY);

/**
 *@brief :检测唤醒源
 */
static uint32_t check_wakeup_src(void) {
    uint32_t rr = nrf_power_resetreas_get();
    NRF_LOG_INFO("nrf_power_resetreas_get: 0x%04x", rr);
#ifdef VFS_PACKED_LFS_ENABLE
    if (vfs_packed_recovery_required()) {
        /* No retained or default tag may become active against an incomplete
         * collection. The recovery UI is reached even after an NFC wake. */
        nrf_power_resetreas_clear(rr);
        return rr;
    }
#endif

    // 如果卡模拟器设置了默认卡，这里就不开启模拟NTAG
    if (tag_helper_valid_default_slot() && (rr & NRF_POWER_RESETREAS_NFC_MASK) && tag_emulation_init() &&
        tag_emulation_active_data_ready()) {
        hal_nfc_set_nrfx_irq_enable(true);
        tag_emulation_sense_run();
    } else {

        extern const ntag_t default_ntag215;
        ret_code_t err_code = ntag_emu_init(&default_ntag215);
        APP_ERROR_CHECK(err_code);

        if (cache_valid()) {
            cache_data_t *p_cache = cache_get_data();
            ntag_emu_set_tag(&(p_cache->ntag));
        } else {
            cache_clean();
        }
    }

    if (rr == 0) {
        NRF_LOG_INFO("WeakUp from button")
        // p_cache->enabled = 0;
    } else if (rr & (NRF_POWER_RESETREAS_NFC_MASK | NRF_POWER_RESETREAS_LPCOMP_MASK)) {
        NRF_LOG_INFO("WakeUp from rfid field");
    } else {
        NRF_LOG_INFO("First power system");
    }
    nrf_power_resetreas_clear(nrf_power_resetreas_get());

    return rr;
}

/**
 * @brief   Function for application main entry.
 */
static void prepare_storage_recovery_ui(void) {
#ifdef VFS_PACKED_LFS_ENABLE
    if (vfs_packed_recovery_required()) {
        /* Temporary RAM defaults only. settings_save is blocked until reboot,
         * so a restored settings.bin cannot be overwritten by these values. */
        settings_data_t *settings = settings_get_data();
        settings->lcd_backlight = 30;
        settings->sleep_timeout_sec = 180;
    }
#endif
}

#if defined(PIXL_RUNTIME_DIAGNOSTICS)
static uint32_t startup_started;
static uint32_t startup_elapsed_ms(uint32_t started) {
    uint32_t ticks = app_timer_cnt_diff_compute(app_timer_cnt_get(), started);
    uint64_t ms = (uint64_t)ticks * 1000u * (APP_TIMER_CONFIG_RTC_FREQUENCY + 1u) /
                  APP_TIMER_CLOCK_FREQ;
    return ms > UINT32_MAX ? UINT32_MAX : (uint32_t)ms;
}

void startup_storage_checkpoint(enum startup_storage_checkpoint step) {
    runtime_diag_storage_mark(step, startup_elapsed_ms(startup_started));
}
#endif

int main(void) {
    runtime_diag_stack_init();
    runtime_diag_boot_capture(nrf_power_resetreas_get());
#if defined(BOARD_LCD) && defined(PIXL_RUNTIME_DIAGNOSTICS)
    fault_note_on_boot();
#endif
    ret_code_t err_code;

    log_init();

    APP_SCHED_INIT(APP_SCHED_MAX_EVENT_SIZE, APP_SCHED_QUEUE_SIZE);

    err_code = nrf_drv_clock_init();
    APP_ERROR_CHECK(err_code);
    nrf_drv_clock_lfclk_request(NULL);

    // Initialize timer module, making it use the scheduler
    err_code = app_timer_init();
    APP_ERROR_CHECK(err_code);

    /* Configure LED-pins as outputs */
    err_code = bsp_init(BSP_INIT_LEDS, bsp_evt_handler);
    APP_ERROR_CHECK(err_code);

    err_code = bsp_event_to_button_action_assign(1, BSP_BUTTON_ACTION_LONG_PUSH, BTN_ACTION_KEY1_LONGPUSH);
    APP_ERROR_CHECK(err_code);

    err_code = nrf_crypto_init();
    APP_ERROR_CHECK(err_code);

    err_code = nrf_mem_init();
    APP_ERROR_CHECK(err_code);

    /* Settings/VFS startup may need the application allocator before mui_init. */
    mui_mem_init();

    err_code = nrf_pwr_mgmt_init();
    APP_ERROR_CHECK(err_code);

    hal_spi_bus_init();

    // enable sd to enable pwr mgmt
    err_code = nrf_sdh_enable_request();
    APP_ERROR_CHECK(err_code);

    // cache_clean(); //FOR TESTING

#if defined(PIXL_RUNTIME_DIAGNOSTICS)
    /* The existing power-management timer runs RTC1 by this point. With
     * APP_TIMER_KEEPS_RTC_ACTIVE=0, app_timer_init alone is not a time origin.
     * The 24-bit counter span is sufficient for this synchronous startup;
     * this trace deliberately excludes bootloader and early SDK startup. */
    startup_started = app_timer_cnt_get();
    runtime_diag_startup_mark(STARTUP_STORAGE_BEGIN, 0);
#endif
    err_code = settings_init();
#if defined(PIXL_RUNTIME_DIAGNOSTICS)
    runtime_diag_startup_mark(STARTUP_STORAGE_DONE, startup_elapsed_ms(startup_started));
#endif
#ifdef VFS_PACKED_LFS_ENABLE
    vfs_packed_latch_recovery();
#endif
    prepare_storage_recovery_ui();
    // we ignore error here, cause flash may not be presented or settings.bin did not exist
    NRF_LOG_INFO("settings init: %d", err_code);
    // APP_ERROR_CHECK(err_code);

    uint32_t wakeup_reason = check_wakeup_src();

    chrg_init();

    settings_data_t *p_settings = settings_get_data();
    nrf_pwr_mgmt_set_timeout(p_settings->sleep_timeout_sec);

#ifdef VFS_PACKED_LFS_ENABLE
    if (!vfs_packed_recovery_required())
#endif
        amiibo_helper_try_load_amiibo_keys_from_vfs();

    NRF_LOG_DEBUG("init done");

    setLanguage(p_settings->language);

    mui_t *p_mui = mui();
#if defined(PIXL_RUNTIME_DIAGNOSTICS)
    runtime_diag_startup_mark(STARTUP_DISPLAY_BEGIN, startup_elapsed_ms(startup_started));
#endif
    mui_init(p_mui);
#if defined(PIXL_RUNTIME_DIAGNOSTICS)
    runtime_diag_startup_mark(STARTUP_DISPLAY_DONE, startup_elapsed_ms(startup_started));
#endif

    mini_app_launcher_t *p_launcher = mini_app_launcher();
    mini_app_launcher_init(p_launcher, wakeup_reason);
#if defined(PIXL_RUNTIME_DIAGNOSTICS)
    runtime_diag_startup_mark(STARTUP_LAUNCHER_DONE, startup_elapsed_ms(startup_started));
    bool startup_dispatched = false;
#endif

    NRF_LOG_FLUSH();

    while (1) {

        ntag_emu_process_pending();
        ble_process_pending();
        app_sched_execute();
#if defined(PIXL_SMALL_CREATE_ENABLE) && defined(VFS_PACKED_LFS_ENABLE)
        df_proto_vfs_expire_small();
#endif
        mui_tick(p_mui);
        ble_remote_poll();
#if defined(PIXL_RUNTIME_DIAGNOSTICS)
        if (!startup_dispatched) {
            /* First event dispatch, not a measurement of visible LCD pixels. */
            runtime_diag_startup_mark(STARTUP_DISPATCH_DONE, startup_elapsed_ms(startup_started));
            startup_dispatched = true;
        }
#endif
        NRF_LOG_FLUSH();

        // The device keeps emulating a NFC tag in all modes (amiibo/amiibolink/chameleon),
        // and BLE transfer may be active at any time. When no_sleep_mode is enabled,
        // keep the standby timeout armed but reset the activity counter while
        // emulating or transferring over BLE, so the timeout still applies
        // afterwards. Manual sleep is not affected.
        if (ntag_emu_save_pending() || (p_settings->no_sleep_mode &&
            (is_emulating_app(p_launcher) || (ble_is_connected() && !ble_remote_mode_active())))) {
            nrf_pwr_mgmt_feed();
        }

        /* Between file commits, service keys, BLE and the power timer. */
        if (amiibo_batch_step()) nrf_pwr_mgmt_feed();
        else nrf_pwr_mgmt_run();
    }
}

/** @} */
