#include "app_settings.h"
#include "settings_scene.h"
#include "settings.h"
#include "nrf_log.h"
#include "i18n/language.h"
#include "mui_nav_diag.h"

static void app_settings_on_run(mini_app_inst_t *p_app_inst);
static void app_settings_on_kill(mini_app_inst_t *p_app_inst);
static void app_settings_on_event(mini_app_inst_t *p_app_inst, mini_app_event_t *p_event);

/* Shared by both settings scenes instead of duplicating this code in flash. */
int32_t settings_storage_snapshot_read(settings_storage_snapshot_t *snapshot,
                                       vfs_driver_t *driver, vfs_stat_t *stat) {
    if (!snapshot->valid || snapshot->driver != driver) {
        vfs_stat_t fresh = {0};
        snapshot->result = driver && driver->stat ? driver->stat(&fresh) : VFS_ERR_NODEV;
        /* Do not retain partially filled values after a failed measurement. */
        snapshot->stat = snapshot->result == VFS_OK ? fresh : (vfs_stat_t){0};
        snapshot->driver = driver;
        snapshot->valid = true;
    }
    *stat = snapshot->stat;
    return snapshot->result;
}

void app_settings_on_run(mini_app_inst_t *p_app_inst) {

    app_settings_t *p_app_handle = mui_mem_malloc(sizeof(app_settings_t));
    if (!p_app_handle) { p_app_inst->p_handle = NULL; return; }
    memset(p_app_handle, 0, sizeof(app_settings_t));
    /* Construct every owned UI object before any app activation. */
    p_app_handle->p_view_dispatcher = mui_view_dispatcher_create();
    if (!p_app_handle->p_view_dispatcher) goto startup_failed;
    p_app_handle->p_list_view = mui_list_view_create();
    if (!p_app_handle->p_list_view) goto startup_failed;
    p_app_handle->p_progress_bar = mui_progress_bar_create();
    if (!p_app_handle->p_progress_bar) goto startup_failed;
    p_app_handle->p_msg_box = mui_msg_box_create();
    if (!p_app_handle->p_msg_box) goto startup_failed;
    p_app_handle->p_scene_dispatcher = mui_scene_dispatcher_create();
    if (!p_app_handle->p_scene_dispatcher) goto startup_failed;
    p_app_handle->p_toast_view = mui_toast_view_create();
    if (!p_app_handle->p_toast_view) goto startup_failed;
    p_app_handle->p_view_dispatcher_toast = mui_view_dispatcher_create();
    if (!p_app_handle->p_view_dispatcher_toast) goto startup_failed;
    p_app_inst->p_handle = p_app_handle;


    mui_list_view_set_user_data(p_app_handle->p_list_view, p_app_handle);
    mui_progress_bar_set_user_data(p_app_handle->p_progress_bar, p_app_handle);

    mui_msg_box_set_user_data(p_app_handle->p_msg_box, p_app_handle);


    mui_scene_dispatcher_set_user_data(p_app_handle->p_scene_dispatcher, p_app_handle);
    mui_scene_dispatcher_set_scene_defines(p_app_handle->p_scene_dispatcher, settings_scene_defines,
                                           SETTINGS_SCENE_MAX);

    mui_view_dispatcher_add_view(p_app_handle->p_view_dispatcher, SETTINGS_VIEW_ID_MAIN,
                                 mui_list_view_get_view(p_app_handle->p_list_view));
    mui_view_dispatcher_add_view(p_app_handle->p_view_dispatcher, SETTINGS_VIEW_ID_PROGRESS_BAR,
                                 mui_progress_bar_get_view(p_app_handle->p_progress_bar));
                                 mui_view_dispatcher_add_view(p_app_handle->p_view_dispatcher, SETTINGS_VIEW_ID_MSG_BOX,
                                 mui_msg_box_get_view(p_app_handle->p_msg_box));

    mui_view_dispatcher_attach(p_app_handle->p_view_dispatcher, MUI_LAYER_FULLSCREEN);

    mui_toast_view_set_user_data(p_app_handle->p_toast_view, p_app_handle);

    mui_view_dispatcher_add_view(p_app_handle->p_view_dispatcher_toast, SETTINGS_VIEW_ID_TOAST,
                                 mui_toast_view_get_view(p_app_handle->p_toast_view));
    mui_view_dispatcher_attach(p_app_handle->p_view_dispatcher_toast, MUI_LAYER_TOAST);
    mui_view_dispatcher_switch_to_view(p_app_handle->p_view_dispatcher_toast, SETTINGS_VIEW_ID_TOAST);

    mui_scene_dispatcher_next_scene(p_app_handle->p_scene_dispatcher, SETTINGS_SCENE_MAIN);

    return;

startup_failed:
    mui_view_dispatcher_free(p_app_handle->p_view_dispatcher_toast);
    mui_toast_view_free(p_app_handle->p_toast_view);
    mui_scene_dispatcher_free(p_app_handle->p_scene_dispatcher);
    mui_msg_box_free(p_app_handle->p_msg_box);
    mui_progress_bar_free(p_app_handle->p_progress_bar);
    mui_list_view_free(p_app_handle->p_list_view);
    mui_view_dispatcher_free(p_app_handle->p_view_dispatcher);
    mui_mem_free(p_app_handle);
    p_app_inst->p_handle = NULL;
}

void app_settings_on_kill(mini_app_inst_t *p_app_inst) {
    mui_nav_diag_end();

    app_settings_t *p_app_handle = p_app_inst->p_handle;
    if (!p_app_handle || !p_app_handle->exit_saved) {
        int32_t result = settings_save();
        if (result != NRF_SUCCESS) NRF_LOG_WARNING("Settings could not be saved on app exit: %d", result);
    }
    if (!p_app_handle) return;
    mui_scene_dispatcher_free(p_app_handle->p_scene_dispatcher);
    mui_view_dispatcher_detach(p_app_handle->p_view_dispatcher, MUI_LAYER_FULLSCREEN);

    mui_view_dispatcher_free(p_app_handle->p_view_dispatcher);
    mui_list_view_free(p_app_handle->p_list_view);
    mui_progress_bar_free(p_app_handle->p_progress_bar);
    mui_msg_box_free(p_app_handle->p_msg_box);

    mui_toast_view_free(p_app_handle->p_toast_view);
    mui_view_dispatcher_detach(p_app_handle->p_view_dispatcher_toast, MUI_LAYER_TOAST);
    mui_view_dispatcher_free(p_app_handle->p_view_dispatcher_toast);

    mui_mem_free(p_app_handle);

    p_app_inst->p_handle = NULL;
}

void app_settings_on_event(mini_app_inst_t *p_app_inst, mini_app_event_t *p_event) {}

mini_app_t app_settings_info = {.id = MINI_APP_ID_SETTINGS,
                                      .name = "系统设置",
                                      .name_i18n_key = _L_APP_SET,
                                      .icon = 0xe02b,
                                      .deamon = false,
                                      .sys = false,
                                      .hibernate_enabled = false,
                                      .icon_32x32 = &app_settings_32x32,
                                      .run_cb = app_settings_on_run,
                                      .kill_cb = app_settings_on_kill,
                                      .on_event_cb = app_settings_on_event};
