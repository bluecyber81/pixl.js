//
// Created by solos on 8/19/2023.
//
#include "amiidb_api_slot.h"
#include "amiibo_helper.h"
#include "db_header.h"
#include "settings.h"
#include "vfs.h"
#include "vfs_persist.h"
#include "vfs_meta.h"
#include <stdio.h>
#include <string.h>

static ntag_type_t amiidb_api_slot_get_tag_type(int32_t size, vfs_meta_t *meta, ntag_t *p_ntag) {
    if (size == NTAG_I2C_2K_DATA_SIZE) {
        uint32_t head = meta->has_amiibo_id ? meta->amiibo_head : to_little_endian_int32(&p_ntag->data[84]);
        uint32_t tail = meta->has_amiibo_id ? meta->amiibo_tail : to_little_endian_int32(&p_ntag->data[88]);

        if (!is_valid_amiibo_v3(head, tail)) {
            return NTAG_215;
        }
    }

    return _ntag_type(size);
}

int32_t amiidb_api_slot_read(uint8_t slot, ntag_t *p_ntag) {
    if (!p_ntag || slot >= MAX_SLOT_COUNT) return VFS_ERR_FAIL;
    char path[VFS_MAX_PATH_LEN];
    vfs_obj_t fd;
    vfs_meta_t meta;
    snprintf(path, sizeof(path), "/amiibo/data/%02u.bin", (unsigned)slot);
    vfs_driver_t *p_vfs_driver = vfs_get_driver(VFS_DRIVE_EXT);
    if (!p_vfs_driver) return VFS_ERR_NODEV;
    int32_t recovery = vfs_persist_recover(p_vfs_driver);
    if (recovery != VFS_OK) return recovery;
    int32_t stat_result = p_vfs_driver->stat_file(path, &fd);
    if (stat_result != VFS_OK) return stat_result;
    if (fd.type != VFS_TYPE_REG || !is_valid_amiibo_ntag_by_size(fd.size)) return VFS_ERR_CRPT;

    memset(&meta, 0, sizeof(vfs_meta_t));
    vfs_meta_decode((uint8_t *)fd.meta, sizeof(fd.meta), &meta);
    memset(p_ntag, 0, sizeof(ntag_t));
    int32_t res = p_vfs_driver->read_file_data(path, p_ntag->data, fd.size);
    if (res != (int32_t)fd.size) return res < 0 ? res : VFS_ERR_CRPT;

    p_ntag->type = amiidb_api_slot_get_tag_type(res, &meta, p_ntag);

    if (meta.has_notes) {
        memcpy(p_ntag->notes, meta.notes, sizeof(meta.notes));
        p_ntag->notes[sizeof(meta.notes)] = 0;
    }

    if (meta.has_flags && (meta.flags & VFS_OBJ_FLAG_READONLY)) {
        p_ntag->read_only = true;
    }

    return 0;
}

int32_t amiidb_api_slot_write(uint8_t slot, ntag_t *p_ntag) {
    if (!p_ntag || slot >= MAX_SLOT_COUNT) return VFS_ERR_FAIL;
    char path[VFS_MAX_PATH_LEN];
    vfs_meta_t meta;
    uint8_t meta_encoded[VFS_MAX_META_LEN];

    snprintf(path, sizeof(path), "/amiibo/data/%02u.bin", (unsigned)slot);
    vfs_driver_t *p_vfs_driver = vfs_get_driver(VFS_DRIVE_EXT);
    if (!p_vfs_driver) return VFS_ERR_NODEV;
    int32_t recovery = vfs_persist_recover(p_vfs_driver);
    if (recovery != VFS_OK) return recovery;
    memset(&meta, 0, sizeof(meta));
    meta.has_amiibo_id = true;
    meta.amiibo_head = to_little_endian_int32(&p_ntag->data[84]);
    meta.amiibo_tail = to_little_endian_int32(&p_ntag->data[88]);

    // TODO write only flag???
    meta.has_flags = true;
    if (p_ntag->read_only) {
        meta.flags |= VFS_OBJ_FLAG_READONLY;
    } else {
        meta.flags &= ~VFS_OBJ_FLAG_READONLY;
    }

    vfs_meta_encode(meta_encoded, sizeof(meta_encoded), &meta);
    size_t tag_size = _ntag_data_size(p_ntag);
    int32_t result = vfs_persist_write_meta(p_vfs_driver, path, p_ntag->data, tag_size, meta_encoded);
    if (result != (int32_t)tag_size) return result < 0 ? result : VFS_ERR_FAIL;

    return 0;
}

int32_t amiidb_api_slot_update(uint8_t slot, ntag_t *p_ntag) {
    if (!p_ntag || slot >= MAX_SLOT_COUNT) return VFS_ERR_FAIL;
    char path[VFS_MAX_PATH_LEN];
    vfs_obj_t obj;
    vfs_meta_t meta;
    snprintf(path, sizeof(path), "/amiibo/data/%02u.bin", (unsigned)slot);
    vfs_driver_t *driver = vfs_get_driver(VFS_DRIVE_EXT);
    if (!driver) return VFS_ERR_NODEV;
    int32_t result = vfs_persist_recover(driver);
    if (result != VFS_OK) return result;
    result = driver->stat_file(path, &obj);
    /* An empty data slot can be emulated before its first NFC save. */
    if (result == VFS_ERR_NOOBJ) return amiidb_api_slot_write(slot, p_ntag);
    if (result != VFS_OK) return result;
    if (obj.type != VFS_TYPE_REG || !is_valid_amiibo_ntag_by_size(obj.size)) return VFS_ERR_CRPT;
    vfs_meta_decode((uint8_t *)obj.meta, sizeof(obj.meta), &meta);
    if (amiidb_api_slot_get_tag_type(obj.size, &meta, p_ntag) != p_ntag->type) return VFS_ERR_CRPT;

    /* Preserve all 128 metadata bytes, 532-byte formats and 572-byte signatures.
     * Explicitly choosing another figure still uses slot_write to replace it. */
    result = vfs_persist_write(driver, path, p_ntag->data, obj.size);
    return result == (int32_t)obj.size ? VFS_OK : result < 0 ? result : VFS_ERR_FAIL;
}

int32_t amiidb_api_slot_remove(uint8_t slot) {
    if (slot >= MAX_SLOT_COUNT) return VFS_ERR_FAIL;
    char path[VFS_MAX_PATH_LEN];
    snprintf(path, sizeof(path), "/amiibo/data/%02u.bin", (unsigned)slot);
    vfs_driver_t *p_vfs_driver = vfs_get_driver(VFS_DRIVE_EXT);
    if (!p_vfs_driver) return VFS_ERR_NODEV;
    int32_t recovery = vfs_persist_recover(p_vfs_driver);
    if (recovery != VFS_OK) return recovery;
    int32_t res = p_vfs_driver->remove_file(path);
    if (res < 0) {
        return -1;
    }
    return 0;
}

int32_t amiidb_api_slot_info(uint8_t slot, amiidb_slot_info_t *p_info) {
    if (!p_info || slot >= MAX_SLOT_COUNT) return VFS_ERR_FAIL;
    memset(p_info, 0, sizeof(*p_info));
    char path[VFS_MAX_PATH_LEN];
    vfs_meta_t meta;
    vfs_obj_t obj;

    snprintf(path, sizeof(path), "/amiibo/data/%02u.bin", (unsigned)slot);
    vfs_driver_t *p_vfs_driver = vfs_get_driver(VFS_DRIVE_EXT);
    if (!p_vfs_driver) return VFS_ERR_NODEV;
    int32_t recovery = vfs_persist_recover(p_vfs_driver);
    if (recovery != VFS_OK) return recovery;
    int32_t res = p_vfs_driver->stat_file(path, &obj);
    if (res < 0) {
        if (res != VFS_ERR_NOOBJ) return res;
        p_info->slot = slot;
        p_info->is_empty = true;
        return 0;
    }

    memset(&meta, 0, sizeof(vfs_meta_t));
    vfs_meta_decode((uint8_t *)obj.meta, sizeof(obj.meta), &meta);

    p_info->slot = slot;
    p_info->is_empty = false;
    p_info->is_readonly = meta.has_flags && meta.flags & VFS_OBJ_FLAG_READONLY;
    p_info->amiibo_head = meta.amiibo_head;
    p_info->amiibo_tail = meta.amiibo_tail;

    return 0;
}

int32_t amiidb_api_slot_list(amiibo_slot_info_cb_t cb, void *ctx) {
    vfs_dir_t dir;
    vfs_obj_t obj;
    vfs_meta_t meta;

    uint8_t max_slot_num = settings_get_data()->amiidb_data_slot_num;
    if (!cb || max_slot_num > MAX_SLOT_COUNT) return VFS_ERR_FAIL;

    amiidb_slot_info_t slots[MAX_SLOT_COUNT];
    for (uint8_t i = 0; i < MAX_SLOT_COUNT; i++) {
        slots[i].slot = i;
        slots[i].is_empty = true;
        slots[i].is_readonly = false;
        slots[i].amiibo_head = 0;
        slots[i].amiibo_tail = 0;
    }

    vfs_driver_t *p_vfs_driver = vfs_get_driver(VFS_DRIVE_EXT);
    if (!p_vfs_driver) return VFS_ERR_NODEV;
    int32_t recovery = vfs_persist_recover(p_vfs_driver);
    if (recovery != VFS_OK) return recovery;
    int32_t res = p_vfs_driver->open_dir("/amiibo/data", &dir);
    if (res < 0) {
        return -1;
    }
    while ((res = p_vfs_driver->read_dir(&dir, &obj)) == VFS_OK) {
        if (obj.type == VFS_TYPE_REG) {
            int32_t index = 0;
            if (obj.name[0] >= '0' && obj.name[0] <= '9' && obj.name[1] >= '0' && obj.name[1] <= '9' &&
                memcmp(obj.name + 2, ".bin", 5) == 0 && (index = (obj.name[0] - '0') * 10 + obj.name[1] - '0') < max_slot_num) {
                memset(&meta, 0, sizeof(vfs_meta_t));
                vfs_meta_decode((uint8_t *)obj.meta, sizeof(obj.meta), &meta);
                if (meta.has_amiibo_id) {
                    slots[index].is_empty = false;
                    slots[index].amiibo_head = meta.amiibo_head;
                    slots[index].amiibo_tail = meta.amiibo_tail;
                }
                if (meta.has_flags && (meta.flags & VFS_OBJ_FLAG_READONLY)) {
                    slots[index].is_readonly = true;
                }
            }
        }
    }
    int32_t close_result = p_vfs_driver->close_dir(&dir);
    if (res != VFS_ERR_EOF) return res;
    if (close_result != VFS_OK) return close_result;

    for (uint8_t i = 0; i < max_slot_num; i++) {
        cb(&slots[i], ctx);
    }

    return 0;
}

int32_t amiidb_api_slot_set_readonly(uint8_t slot, bool readonly) {
    if (slot >= MAX_SLOT_COUNT) return VFS_ERR_FAIL;
    char path[VFS_MAX_PATH_LEN];
    vfs_meta_t meta;
    vfs_obj_t obj;
    uint8_t meta_buf[VFS_MAX_META_LEN];

    snprintf(path, sizeof(path), "/amiibo/data/%02u.bin", (unsigned)slot);
    vfs_driver_t *p_vfs_driver = vfs_get_driver(VFS_DRIVE_EXT);
    if (!p_vfs_driver) return VFS_ERR_NODEV;
    int32_t recovery = vfs_persist_recover(p_vfs_driver);
    if (recovery != VFS_OK) return recovery;
    int32_t res = p_vfs_driver->stat_file(path, &obj);
    if (res < 0) {
        return -1;
    }

    memset(&meta, 0, sizeof(vfs_meta_t));
    vfs_meta_decode((uint8_t *)obj.meta, sizeof(obj.meta), &meta);

    meta.has_flags = true;
    if (readonly) {
        meta.flags |= VFS_OBJ_FLAG_READONLY;
    } else {
        meta.flags &= ~VFS_OBJ_FLAG_READONLY;
    }

    vfs_meta_encode(meta_buf, sizeof(meta_buf), &meta);
    if (p_vfs_driver->update_file_meta(path, meta_buf, sizeof(meta_buf)) == VFS_OK) {
        return NRF_SUCCESS;
    } else {
        return -1;
    }
}
