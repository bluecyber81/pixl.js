#ifndef AMIIDB_DATA_H
#define AMIIDB_DATA_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include "db_note_index.h"

typedef struct {
    uint32_t head;
    uint32_t tail;
    const char *name_en;
    const char *name_cn;

} db_amiibo_t;

struct _db_link_t;

typedef struct _db_game_t {
    uint8_t game_id;
    uint8_t parent_game_id;
    const char *name_en;
    const char *name_cn;
    
    uint8_t order;
    uint16_t link_cnt;
} db_game_t;

typedef struct {
    const char *en;
    const char *cn;
    const char *it;
} db_notes_t;

typedef struct _db_link_t {
    /* Internal ROM indices, independent of tag/slot formats. */
    uint16_t amiibo_index;
    uint8_t game_id;
    db_note_index_t note_index;
    
} db_link_t;

_Static_assert(sizeof(db_link_t) == 2 + 2 * sizeof(db_note_index_t), "unexpected ROM link padding");

typedef struct _db_v3_t {
    uint32_t head;
    uint32_t tail;
} db_v3_t;

extern const db_amiibo_t amiibo_list[];
extern const size_t amiibo_list_size;
extern const db_game_t game_list[];
extern const db_link_t link_list[];
extern const db_notes_t db_usage_notes[];

const db_amiibo_t * get_amiibo_by_id(uint32_t head, uint32_t tail);
const db_link_t* get_link_by_id(uint8_t game_id, uint32_t head, uint32_t tail);
bool is_valid_amiibo_v3(uint32_t head, uint32_t tail);

const char* get_amiibo_display_name(const db_amiibo_t *amiibo);

#endif
