/**
 * Copyright (c) 2016 - 2020, Nordic Semiconductor ASA
 *
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form, except as embedded into a Nordic
 *    Semiconductor ASA integrated circuit in a product or a software update for
 *    such product, must reproduce the above copyright notice, this list of
 *    conditions and the following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. Neither the name of Nordic Semiconductor ASA nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * 4. This software, with or without modification, must only be used with a
 *    Nordic Semiconductor ASA integrated circuit.
 *
 * 5. Any software provided in binary form under this license must not be reverse
 *    engineered, decompiled, modified and/or disassembled.
 *
 * THIS SOFTWARE IS PROVIDED BY NORDIC SEMICONDUCTOR ASA "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NORDIC SEMICONDUCTOR ASA OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
/** @file
 *
 * @defgroup bootloader_secure_ble main.c
 * @{
 * @ingroup dfu_bootloader_api
 * @brief Bootloader project main file for secure DFU.
 *
 */

#include "app_error.h"
#include "app_error_weak.h"
#include "app_scheduler.h"
#include "boards.h"
#include "lcd_drv.h"
#include "nrf_bootloader.h"
#include "nrf_bootloader_app_start.h"
#include "nrf_bootloader_dfu_timers.h"
#include "nrf_bootloader_info.h"
#include "nrf_delay.h"
#include "nrf_dfu.h"
#include "nrf_gpio.h"
#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"
#include "nrf_mbr.h"
#include <stdint.h>

static void on_error(void) {
    NRF_LOG_FINAL_FLUSH();

#if NRF_MODULE_ENABLED(NRF_LOG_BACKEND_RTT)
    // To allow the buffer to be flushed by the host.
    nrf_delay_ms(100);
#endif
#ifdef NRF_DFU_DEBUG_VERSION
    NRF_BREAKPOINT_COND;
#endif
    NVIC_SystemReset();
}

void app_error_handler(uint32_t error_code, uint32_t line_num, const uint8_t *p_file_name) {
    NRF_LOG_ERROR("%s:%d", p_file_name, line_num);
    on_error();
}

void app_error_fault_handler(uint32_t id, uint32_t pc, uint32_t info) {
    NRF_LOG_ERROR("Received a fault! id: 0x%08x, pc: 0x%08x, info: 0x%08x", id, pc, info);
    on_error();
}

void app_error_handler_bare(uint32_t error_code) {
    NRF_LOG_ERROR("Received an error: 0x%08x!", error_code);
    on_error();
}

/* Transport and flash-completion notifications may run in an IRQ. Neither
 * draw nor tear down SPI there: a main-context transfer may still be active.
 * Keep one deferred update; newer lifecycle events determine its action. */
enum { DISPLAY_INACTIVE, DISPLAY_READY, DISPLAY_WAITING };
static volatile uint8_t m_display_state;
static volatile bool m_display_queued;

static void display_waiting(void) {
    lcd_clear();
    lcd_draw_str_1608(25, 18, "DFU Update");
    lcd_draw_str_1608(25, 35, "Waiting...");
}

static void display_update_deferred(void *event_data, uint16_t event_size) {
    (void)event_data;
    (void)event_size;
    m_display_queued = false;
    if (m_display_state == DISPLAY_INACTIVE) {
        lcd_uninit();
    } else if (m_display_state == DISPLAY_WAITING) {
        display_waiting();
    }
}

static void display_update_schedule(void) {
    if (!m_display_queued) {
        m_display_queued = true;
        if (app_sched_event_put(NULL, 0, display_update_deferred) != NRF_SUCCESS) {
            /* Cosmetic refresh/cleanup must not reset or block DFU. The SDK
             * reset still restores hardware if terminal cleanup is skipped. */
            m_display_queued = false;
        }
    }
}

/**
 * @brief Function notifies certain events in DFU process.
 */
static void dfu_observer(nrf_dfu_evt_type_t evt_type) {
    switch (evt_type) {
    case NRF_DFU_EVT_DFU_FAILED:
        if (m_display_state != DISPLAY_READY) break;
        /* A request queued before link loss can finish after the disconnect
         * IRQ. Ignore it until a new link activates the display state. */
        /* A rejected request does not exit the SDK DFU loop. Keep the LCD
         * initialized so the next request can show Receiving again. */
        lcd_clear();
        lcd_draw_str_1608(25, 18, "DFU Error");
        lcd_draw_str_1608(25, 35, "Retry...");
        break;
    case NRF_DFU_EVT_DFU_ABORTED:
    case NRF_DFU_EVT_DFU_COMPLETED:
        m_display_state = DISPLAY_INACTIVE;
        display_update_schedule();
        break;

    case NRF_DFU_EVT_DFU_INITIALIZED:
        m_display_state = DISPLAY_READY;
        lcd_init();
        display_waiting();
        break;
    case NRF_DFU_EVT_TRANSPORT_ACTIVATED:
        if (m_display_state != DISPLAY_INACTIVE) m_display_state = DISPLAY_READY;
        break;
    case NRF_DFU_EVT_DFU_STARTED:
        if (m_display_state != DISPLAY_READY) break;
        lcd_clear();
        lcd_draw_str_1608(25, 18, "DFU Update");
        lcd_draw_str_1608(25, 35, "Receiving...");
        break;
    case NRF_DFU_EVT_TRANSPORT_DEACTIVATED:
        if (m_display_state == DISPLAY_INACTIVE) break;
        m_display_state = DISPLAY_WAITING;
        display_update_schedule();
        break;
    case NRF_DFU_EVT_OBJECT_RECEIVED:
    default:
        break;
    }
}

/**@brief Function for application main entry. */
int main(void) {
    uint32_t ret_val;

    // Must happen before flash protection is applied, since it edits a protected page.
    nrf_bootloader_mbr_addrs_populate();

    // Protect MBR and bootloader code from being overwritten.
    ret_val = nrf_bootloader_flash_protect(0, MBR_SIZE);
    APP_ERROR_CHECK(ret_val);
    ret_val = nrf_bootloader_flash_protect(BOOTLOADER_START_ADDR, BOOTLOADER_SIZE);
    APP_ERROR_CHECK(ret_val);

    (void)NRF_LOG_INIT(nrf_bootloader_dfu_timer_counter_get);
    NRF_LOG_DEFAULT_BACKENDS_INIT();

    NRF_LOG_INFO("Inside main");

    nrf_gpio_cfg_input(NRF_BL_DFU_ENTER_METHOD_BUTTON_PIN, NRF_GPIO_PIN_PULLUP);

    // Loop for at most 3 seconds if DFU button is pressed (active low)
    // After 3 seconds, if the button is still pressed, enter DFU mode.
    // This is to allow the user to wake up the device as normal using the DFU button.
    uint32_t loop_count = 0;
    const uint32_t max_loops = 300;  // 300 * 10ms = 3 seconds
    while (nrf_gpio_pin_read(NRF_BL_DFU_ENTER_METHOD_BUTTON_PIN) == 0 && loop_count < max_loops) {
        nrf_delay_ms(10);
        loop_count++;
    }

    ret_val = nrf_bootloader_init(dfu_observer);
    APP_ERROR_CHECK(ret_val);

    NRF_LOG_FLUSH();

    NRF_LOG_ERROR("After main, should never be reached.");
    NRF_LOG_FLUSH();

    APP_ERROR_CHECK_BOOL(false);
}

/**
 * @}
 */
