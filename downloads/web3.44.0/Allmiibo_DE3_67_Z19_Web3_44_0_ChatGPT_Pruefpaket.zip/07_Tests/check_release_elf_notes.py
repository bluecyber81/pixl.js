"""Exercise compiled DE3.67 note routing for every CSV association on a Cortex-M4 model."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys
from unicorn import Uc, UC_ARCH_ARM, UC_MODE_MCLASS, UC_MODE_THUMB, UC_PROT_READ, UC_PROT_EXEC
from unicorn.arm_const import UC_ARM_REG_LR, UC_ARM_REG_PC, UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_SP

RAM = 0x20000000
STOP = 0x7F000
VIEW = 0x21000000
TAG = VIEW + 0x100
SCRATCH = VIEW + 0x1000
SCRATCH_BYTES = 152
CANARY = b"\xA5" * (SCRATCH_BYTES + 16)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--source", type=Path, required=True)
    p.add_argument("--build", type=Path, required=True)
    p.add_argument("--toolchain", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    if not __debug__:
        raise ValueError("Run with assertions enabled")
    fw = args.source.resolve() / "fw"
    sys.path.insert(0, str(fw/"scripts"))
    from amiibo_db_gen import read_catalog
    from production_id import fingerprint, source_hashes
    elf_path = args.build/"pixljs.out"
    report = json.loads((args.build/"BUILD_RESULT.json").read_bytes())
    assert report["version"] == "2.22.0-DE3.67" and report["counter"] == 639
    assert report["status"] == "passed" and report["mode"] == "release" and not report["signed"]
    assert report["matches_archived_release_binary"] and report["expected_bin_sha256"] == "db1ec1258c05aacf6fcdea83d29ea5962424d50c56d28b6c7b249a7f0766a236"
    assert report["artifacts_sha256"]["pixljs.out"] == digest(elf_path)
    assert fingerprint(source_hashes(fw)) == report["source_id_sha256"]
    symbols = subprocess.check_output([str(args.toolchain/"bin/arm-none-eabi-nm"),
                                       "--defined-only", str(elf_path)], text=True)
    addrs = {s[2]:int(s[0],16) for line in symbols.splitlines() if len(s:=line.split()) == 3}
    cpu = Uc(UC_ARCH_ARM, UC_MODE_MCLASS | UC_MODE_THUMB)
    cpu.mem_map(0, 512*1024)
    cpu.mem_map(RAM, 65536)
    cpu.mem_map(VIEW, 0x2000)
    elf = elf_path.read_bytes()
    assert elf[:6] == b"\x7fELF\x01\x01"
    ph = struct.unpack_from("<I",elf,28)[0]
    size,count = struct.unpack_from("<HH",elf,42)
    for i in range(count):
        typ, offset, va, _, nbytes, _, _, _ = struct.unpack_from("<8I",elf,ph+i*size)
        if typ == 1 and nbytes:
            cpu.mem_write(va,elf[offset:offset+nbytes])
    cpu.mem_protect(0,512*1024,UC_PROT_READ|UC_PROT_EXEC)
    cpu.mem_write(VIEW+4, struct.pack("<I",TAG))
    args_text = json.loads((fw/"data/usage-translations.de.json").read_bytes())["texts"]
    assert len(args_text)==54 and max(len(d.encode())+1 for d in args_text.values())==SCRATCH_BYTES
    figs, games, links = read_catalog(fw/"data")

    def lookup(game_id, figure, language, want):
        cpu.mem_write(TAG+84,bytes.fromhex(figure))
        cpu.mem_write(VIEW+15, bytes([game_id]))
        cpu.mem_write(addrs["currentLanguage"],bytes([language]))
        cpu.mem_write(SCRATCH-8,CANARY)
        cpu.reg_write(UC_ARM_REG_SP,RAM+65536-8)
        cpu.reg_write(UC_ARM_REG_LR,STOP|1)
        cpu.reg_write(UC_ARM_REG_R0,VIEW)
        cpu.reg_write(UC_ARM_REG_R1,SCRATCH)
        cpu.emu_start(addrs["amiibo_view_usage"]|1,STOP,count=40000)
        assert cpu.reg_read(UC_ARM_REG_PC)==STOP
        ptr = cpu.reg_read(UC_ARM_REG_R0)
        assert bytes(cpu.mem_read(ptr,len(want.encode())+1))==want.encode()+b"\0",(game_id,figure,language,want)
        guard = bytes(cpu.mem_read(SCRATCH-8,len(CANARY)))
        assert guard[:8]==CANARY[:8] and guard[-8:]==CANARY[-8:]
        if want and language == 0:
            assert ptr==SCRATCH
        else:
            assert guard==CANARY
        assert bytes(cpu.mem_read(TAG+84,8))==bytes.fromhex(figure)
        assert cpu.reg_read(UC_ARM_REG_SP)==RAM+65536-8

    for row in links:
        english = row.note_en or ""
        lookup(int(row.game_id),row.amiibo_id,0,args_text.get(english,english))
        lookup(int(row.game_id),row.amiibo_id,1,english)
    for language in (0,1):
        lookup(255,"fffffffffffffffe",language,"")
    out = {"version": report["version"],"counter": report["counter"],"sourceFingerprint":report["source_id_sha256"],
           "elfSha256":digest(elf_path),"binSha256":digest(args.build/"pixljs.bin"),
           "figures":len(figs),"groups":len(games),"associations":len(links),"withNote":sum(bool(r.note_en) for r in links),
           "distinctEnglishNotes":len({r.note_en for r in links if r.note_en}),"translatedDistinct":len(args_text),
           "localeCalls":2*len(links),"unknownGroupAndFigureCases":2,
           "result":"passed","hardware":False,"emulator":"Unicorn Cortex-M (Thumb), real release-optimized ELF instructions",
           "checked":"Original English or reviewed German per association, byte for byte, plus stack return, protected flash, output guards and immutable input ID."}
    args.output.write_text(json.dumps(out,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(out,ensure_ascii=False))

if __name__=="__main__":
    main()
