# Allmiibo LCD DE3.87, Z21 und Dateimanager 3.58.0

Dieses öffentliche Prüfpaket gehört zum LCD/ST7567 mit PFS1, Bootloader Z21 und Nordic S112 7.3.0. Es enthält das signierte Anwendungsupdate App660 und die Nachweise der Hosttests. Der Browser-Dateimanager führt zusätzlich das separate öffentliche OLED-Angebot bis App84.

## Download prüfen

Die Dateien `Allmiibo_Dateimanager_3_58_0_Quellcode.zip` und `Allmiibo_Dateimanager_3_58_0_Portable.zip` aus dem Web-Release in einen gemeinsamen Ordner legen. Das Prüfpaket vollständig entpacken. Im entpackten Prüfordner unter Windows ausführen:

```console
py -3 pruefe_release.py "C:\Pfad\zu\den\Downloads"
```

Unter Linux oder macOS lautet der Aufruf `python3 pruefe_release.py /Pfad/zu/den/Downloads`. Der Prüfer liest die Archive lokal. Er überprüft beide Katalogvarianten (Root/Pages), die LCD-App und sämtliche registrierten Dateien im Portable und im Quellstand. Die Buildkennung findest du in `PRUEFSTAND.json`.

## Softwaretests wiederholen

Das Quellcode-ZIP entpacken, im Unterordner `web` mit Node.js ab 22.12 und npm arbeiten und die folgenden Befehle nacheinander ausführen.

```console
npm ci
npm test
npm run build
npm run build:pages
```

Die Lizenzhinweise stehen in den jeweiligen Paketverzeichnissen. Die Build- und Simulatoranleitungen sind im Quellarchiv enthalten. Die Hosttests verwenden unter anderem virtuelle Dateisysteme, simulierte Bluetooth-Verbindungen und echte Vue-Komponenten. `Nachweise/DE3_87_PFS.json` bindet den Simulator und die ARM-Artefakte an diese Version. Die Z21-Simulation prüft die Wiederaufnahme einer unterbrochenen Übertragung.

## Offene Geräteprüfung

1. Unter Windows das Portable vollständig entpacken und `Start-Dateimanager.cmd` ausführen. Die Website im Browser öffnen, dann mit `Stop-Dateimanager.cmd` beenden.
2. Am kompatiblen LCD über Android und nRF Device Firmware Update ausschließlich die unveränderte App-ZIP aus `LCD/` auswählen. Nach erneutem Verbinden Board LCD, Version 2.22.0-DE3.87, App660, Z21 und S112 7.3.0 ablesen.
3. Einen mehrseitigen Favoritenordner öffnen, zu einer späteren Seite wechseln, schlafen lassen und wieder aufwecken. Sichtbare Seite und Auswahl auch bei Einträgen aus einem alten Import vergleichen.
4. In der mobilen Fernbedienung Displayfoto, vier Tasten und Bildoptionen prüfen. Die Ausrichtung ändern, ein neues Foto anfordern und einen vorübergehenden Lesefehler beobachten. Die letzte erfolgreiche Aufnahme soll mit ihrer Zeit sichtbar bleiben. Das automatische Foto bleibt zuschaltbar.
5. Vor und nach dem Update mit unveränderter Sammlung mehrere Neustarts messen. Diagnoseexporte mit Firmwareversion und Versuchszahl aufbewahren.

Das Ergebnis der Windows-, Android- und LCD-Prüfung ist offen. Das öffentliche Firmware-Prüfpaket mit weiteren ARM-Nachweisen hat den Namen `Allmiibo_LCD_DE3_87_App660_Pruefpaket.zip` und gehört zum Firmware-Tag `de3.87-lcd-test1`. Quellreferenz des Dateimanagers: 9c33c67690fb5b3e4c08196374f2e56e8f118f6a.
