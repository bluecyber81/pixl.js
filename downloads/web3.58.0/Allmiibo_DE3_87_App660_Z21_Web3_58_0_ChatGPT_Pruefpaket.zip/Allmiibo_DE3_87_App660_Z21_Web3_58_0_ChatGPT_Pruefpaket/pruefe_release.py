"""Prüft den öffentlichen Dateimanager, Quellstand und die signierte LCD-App."""
from pathlib import Path
from zipfile import ZipFile
from hashlib import sha256
import argparse
import json

def check(ok, reason):
    if not ok:
        raise ValueError(reason)

def read_json(archive, name):
    return json.loads(archive.read(name))

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('downloads', type=Path, help='Ordner mit den Web-Release-ZIPs für 3.58.0')
    folder = ap.parse_args().downloads
    kit = Path(__file__).resolve().parent
    record = json.loads((kit/'PRUEFSTAND.json').read_bytes())
    for key in ('portable', 'quellcode'):
        asset = record['archive'][key]
        with (folder/asset['name']).open('rb') as handle:
            calc = sha256()
            for block in iter(lambda: handle.read(1024*1024), b''):
                calc.update(block)
        check(calc.hexdigest() == asset['sha256'], 'Archivprüfsumme: '+asset['name'])
    portable = record['archive']['portable']
    with ZipFile(folder/portable['name']) as z:
        prefix = portable['prefix']+'/'
        manifest = read_json(z, prefix+'PORTABLE-MANIFEST.json')
        for name, digest in manifest['filesSha256'].items():
            check(sha256(z.read(prefix+name)).hexdigest() == digest, 'Portable-Datei: '+name)
        for build in ['dist/', 'dist-pages/']:
            items = read_json(z, prefix+build+'firmware/releases.json')['packages']
            lcd = next(p for p in items if p['board'] == 'LCD' and p['counter'] == 660)
            oled = [p['counter'] for p in items if p['board']=='OLED']
            check(84 in oled and 85 not in oled, 'Öffentlicher OLED-Katalog')
            firmware=z.read(prefix+build+'firmware/'+lcd['file'])
            check(sha256(firmware).hexdigest() == lcd['sha256'] == record['lcd']['otaSha256'], 'LCD-Paket: '+build)
    source = record['archive']['quellcode']
    with ZipFile(folder/source['name']) as z:
        prefix=source['prefix']+'/'
        manifest=read_json(z,prefix+'QUELLSTAND.json')
        check(manifest['commit'] == record['commit'], 'Quellcommit')
        for name,digest in manifest['filesSha256'].items():
            check(sha256(z.read(prefix+name)).hexdigest() == digest,'Quelldatei: '+name)
    local_app = (kit/'LCD'/record['lcd']['datei']).read_bytes()
    check(sha256(local_app).hexdigest()==record['lcd']['otaSha256'],'LCD-App im Prüfpaket')
    print('Portable, beide Betriebsarten, Quellcode, LCD-App und öffentlicher OLED-Katalog stimmen überein.')
if __name__ == '__main__':
    main()
