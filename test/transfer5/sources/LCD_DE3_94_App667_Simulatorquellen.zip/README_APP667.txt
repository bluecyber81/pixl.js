Allmiibo LCD DE3.94 / App667 – Simulatorquellen
================================================

Dieses Archiv enthält die vollständigen Quellen, Lizenzen, Compilerpins,
das Reproduktionsskript und die Referenz-WASM für den Kapazitätssimulator.
Die neue Anwendung ist an diese tatsächlichen Builddaten gebunden:

Board: LCD
Version / Counter: 2.22.0-DE3.94 / 667
Produktionscommit: 1d606c9faeedbb1fe31fb2c4547ad47818c04b75
SourceID: 1f5864e1279b7378d3cc685b73d80a3257aad8f6a29db27d1c880800b30c4e90
Anwendungs-BIN: 361032 Byte
BIN-SHA-256: 99aa4dbe6f2bba9771b8b51d9e80cc26b4f38a96ad09ee3391ab13ed5fdf676f

Zuordnung der gemeinsamen Simulatorquelle
-----------------------------------------
Die Engine ist gegenüber App666 unverändert. Deshalb behalten der Snapshot,
die WASM und das Buildskript ihre bestehenden de393-Dateinamen. Alle Einträge
des vorherigen Simulatorquellenarchivs sind hier bytegleich enthalten.
SOURCE.txt im Snapshot dokumentiert weiterhin dessen historische App666-
Herkunft. Die zusätzliche APP667_BINDING.json und docs/validation/DE3_94_PFS.json
weisen die neue Bindung an die tatsächliche App667-SourceID und deren ARM-ELF,
BIN und HEX nach. Die vier ARM-Layoutfälle wurden für App667 neu ausgeführt;
der vorhandene Crossmount-Nachweis gehört zur identischen Speicherengine.

Reproduktion
------------
Zuerst den in SOURCE_BINDING.json und SOURCE.txt benannten offiziellen WASI
SDK 34.0 anhand des angegebenen Archivhashes prüfen und entpacken. Aus dem
Wurzelverzeichnis dieses entpackten Quellenpakets ausführen:

python3 web/scripts/build-capacity-de393.py --sdk /path/to/wasi-sdk-34.0-x86_64-linux --output /path/to/new-evidence-directory

Das Skript verlangt die gepinnten Compiler-/Linkerbytes, prüft alle zwölf
Quelldateien und vergleicht das Ergebnis mit der enthaltenen Referenz-WASM.
GPL-2.0-LICENSE und LITTLEFS-LICENSE.md befinden sich beim Quellensnapshot.

Geltungsbereich
--------------
Die Simulation berechnet Speicherbedarf im Browser. Die ARM-Layoutprüfung
modelliert Mountzustand und Flashgeometrie. Physischer freier Speicher,
Übertragungsgeschwindigkeit und die Abnahme am Gerät bleiben gesonderte
Prüfungen. Das signierte Firmwareupdate wird als separates OTA-Paket geführt;
dieses Quellenarchiv enthält keine OTA- oder öffentlichen Release-Metadaten.
