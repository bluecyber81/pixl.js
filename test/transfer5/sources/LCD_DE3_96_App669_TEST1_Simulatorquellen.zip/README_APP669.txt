Allmiibo LCD DE3.96 / App669 TEST1 – Simulatorquellen
====================================================

Dieses Archiv enthält die vollständigen Simulatorquellen, Lizenzen,
Compilerpins, das Reproduktionsskript und die Referenz-WASM. Der Simulator
ist an die tatsächliche LCD-Testanwendung gebunden:

Board: LCD
Version / Counter: 2.22.0-DE3.96 / 669
Öffentlicher Produktionscommit: feb6c58ad14998f31aef07dc84d8dc0732e32ede
SourceID: dea06409b9ff20a12f446a7baed683b6442573ed427c5dc87cd4bed2885df858
Anwendungs-BIN: 363312 Byte
BIN-SHA-256: 32d3a83b0692ea06b65af48c236bcffa4eb3469c0e98e9bb6840965cc1dabb80
Speicherengine-SHA-256: 3574b8ea61e7c1563a77eb806eb2ae1fbe3f2d94196d3a2d72e89ca3a6b3b21d

Exakte Profilbindung und Prüfumfang
-----------------------------------
DE3.96 besitzt das eigene de396-Profil und einen neuen Quellensnapshot.
Die sechs Kern-/LittleFS-Dateien stimmen mit dem App669-Produktionsbuild
überein. Alle zwölf Simulatorquellen sind einzeln gehasht. Das enthaltene
Manifest der 709 Firmware-Produktionseingaben dokumentiert die SourceID;
es ersetzt nicht die Firmwarequellen im öffentlichen Projekt-Repository.
Die App668- und älteren Simulatorquellen, WASM-Dateien und Pins bleiben erhalten.

APP669_BINDING.json verbindet diese Dateien mit SourceID und den geprüften
ARM-ELF-, BIN- und HEX-Dateien. DE3_96_PFS.json enthält vier Linked-ARM-
Layoutfälle. DE3_96_CROSS_MOUNT.json enthält sechs neue wechselseitige
Lese-/Schreibprüfungen zwischen App668 und App669 mit 1131 synthetischen
Dateien und 77 Ordnern, vollständigen Daten-/raw128-Prüfungen und Remount.
Die vollständige 1208-Einträge-Simulation belegt 238 von 512 Blöcken;
mit konservativer Transaktionsreserve beträgt der Spitzenwert 279 Blöcke.
Diese Werte beziehen sich ausschließlich auf die synthetische Testkollektion.

Die WASM wird ohne BOARD_LCD und PIXL_TEST_DIAGNOSTICS gebaut. SDK-
Zeitmessung und zusätzlicher GC-Diagnosespeicher sind nicht enthalten.
Der gemeldete Simulator-Heap ist keine Messung des Firmware-RAM-Verbrauchs.
Mountzustand, Flashgeometrie und Dateiinhalte der Prüfungen sind modelliert.

Reproduktion
------------
Das offizielle WASI SDK 34.0 anhand des Archivhashes in SOURCE_BINDING.json
prüfen und entpacken. Im Wurzelverzeichnis dieses Quellenpakets ausführen:

python3 web/scripts/build-capacity-de396.py --sdk /path/to/wasi-sdk-34.0-x86_64-linux --output /path/to/new-evidence-directory

Das Skript verlangt die gepinnten Compiler-/Linkerbytes, prüft alle zwölf
Quelldateien und vergleicht das Ergebnis mit der enthaltenen Referenz-WASM.
GPL-2.0-LICENSE und LITTLEFS-LICENSE.md liegen beim Quellensnapshot.

Geltungsbereich
--------------
Die Simulation prüft Platzbedarf im Browser. Für jedes echte Archiv und
das aktuelle Zielgerät bleiben die eigenen Prüfungen erforderlich.
Physischer freier Speicher, Übertragungsgeschwindigkeit, Stromausfallverhalten
und Abnahme am Gerät sind nicht nachgewiesen. Die Firmware ist TEST1 und
noch nicht als Normalbuild am Gerät abgenommen. Das signierte Update ist
ein separates OTA-Paket. Dieses Archiv enthält keine Signierschlüssel,
OTA-Pakete oder öffentlichen Release-Metadaten.
