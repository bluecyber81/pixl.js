LCD DE3.100 / App673: Simulatorquellen und tatsächliche Firmwarebindung

Die PFS1-Engine und lfs-capacity-de399.wasm sind unverändert zu App672.
Das neue de3100-Profil bindet dieselbe Engine ausschließlich an DE3.100 / 673.
APP673_BINDING.json nennt den tatsächlichen Produktionscommit 6039c163b3d4c52338e708fd0fb39e0606ce7fbf,
die SourceID, den signierten OTA-Hash und den BIN-Hash.
Vollständige Firmwarequellen: https://github.com/bluecyber81/pixl.js/tree/6039c163b3d4c52338e708fd0fb39e0606ce7fbf

Die zwölf gepinnten Simulatorquelldateien, beide Identitätsdateien, Lizenzen
und build-capacity-de399.py sind bytegleich zur bisherigen App672-Lieferung.
Das Buildskript und SOURCE.txt enthalten den ursprünglichen Compilerpin.
Es wurde für App673 kein neuer WASM-Build erfunden oder umetikettiert.

DE3_100_PFS.json dokumentiert vier frisch ausgeführte Layoutfälle aus dem
finalen App673-ARM-ELF, den ELF/BIN/HEX-Abgleich und 720 Produktionsinputs.
Die sechs Cross-Mount-Fälle in DE3_99_CROSS_MOUNT.json sind historische,
bereits ausgeführte App672-Tests. Die sechs Enginequelldateien, Geometrie,
Speicheradapter und WASM stimmen unverändert überein; dies ist ausdrücklich
keine Wiederholung dieser sechs Fälle für App673.

Reproduktion der neuen ARM-Bindung bei vorhandenen finalen Buildartefakten:
python web/scripts/qualify-lcd-capacity.py --profile de3100 --source FIRMWARE_QUELLE
  --build FINALER_BUILD --reuse-cross-report docs/validation/DE3_99_CROSS_MOUNT.json
  --output DE3_100_PFS.json
Benötigt die vollständige Webquelle, Python mit Unicorn2 und ARM GNU nm/objcopy.

Keine Gerätemessung, keine physische Speicherfreigabe und keine native
Windows-Abnahme werden durch diese Softwarebelege behauptet. Das Archiv
enthält weder private Schlüssel noch Nutzerdateien noch eine OTA-Paketkopie.
