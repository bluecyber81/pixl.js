Allmiibo LCD DE3.95 / App668 – Simulatorquellen
================================================

Dieses Archiv enthält die vollständigen Simulatorquellen, Lizenzen,
Compilerpins, das Reproduktionsskript und die Referenz-WASM. Der Simulator
ist an die tatsächliche LCD-Anwendung gebunden:

Board: LCD
Version / Counter: 2.22.0-DE3.95 / 668
Produktionscommit: 2bcb743180e645bdf0d84fa0dc0148a15bd07f00
SourceID: 75dafc809b6e2c883062f7c52d6e418bbabb83d404fde562d057bfab5acf7fec
Anwendungs-BIN: 361992 Byte
BIN-SHA-256: cf1a310059338da51bc4acdcfc2cb4dd97ddbe6fb63491db6ea7d0de41b59bc9
Speicherengine-SHA-256: a9bdec38eaa41680e1c9fdebd5fd12995e9d38ff070560ff605fd387d471dabd

Neue Speicherengine und eigene Profilbindung
--------------------------------------------
DE3.95 verwendet ein eigenes de395-Profil und einen eigenen Quellensnapshot.
Die sechs Kern-/LittleFS-Dateien stimmen mit dem App668-Produktionsbuild
überein. Alle zwölf Simulatorquellen sind einzeln gehasht. Der enthaltene
Hashmanifest aller 709 Firmware-Produktionseingaben dokumentiert die
SourceID-Bindung; er ersetzt nicht die Firmwarequellen im Projekt-Repository.
Die alten App667-/App665-/App664-Simulatorquellen bleiben unverändert.

APP668_BINDING.json verbindet diese Dateien mit der tatsächlichen App668-
SourceID und den erneut geprüften ARM-ELF-, BIN- und HEX-Dateien.
docs/validation/DE3_95_PFS.json dokumentiert vier Linked-ARM-Layoutfälle.
DE3_95_CROSS_MOUNT.json dokumentiert sechs neue Cross-Mount-Schritte zwischen
App667- und App668-Engine, mit 1131 synthetischen Dateien und 77 Ordnern.
Mountzustand, Flashgeometrie und Dateiinhalte wurden im Testmodell erzeugt.

Reproduktion
------------
Zuerst das in SOURCE_BINDING.json und SOURCE.txt benannte offizielle WASI
SDK 34.0 anhand des angegebenen Archivhashes prüfen und entpacken. Aus dem
Wurzelverzeichnis dieses entpackten Quellenpakets ausführen:

python3 web/scripts/build-capacity-de395.py --sdk /path/to/wasi-sdk-34.0-x86_64-linux --output /path/to/new-evidence-directory

Das Skript verlangt die gepinnten Compiler-/Linkerbytes, prüft alle zwölf
Quelldateien und vergleicht das Ergebnis mit der enthaltenen Referenz-WASM.
GPL-2.0-LICENSE und LITTLEFS-LICENSE.md befinden sich beim Quellensnapshot.

Geltungsbereich
--------------
Die Simulation berechnet Speicherbedarf im Browser. Physischer freier
Speicher, Übertragungsgeschwindigkeit, Stromausfallverhalten und Abnahme am
Gerät bleiben gesonderte Prüfungen. Das signierte Firmwareupdate ist ein
separates OTA-Paket. Dieses Quellenarchiv enthält keine Signierschlüssel,
OTA-Pakete oder öffentlichen Release-Metadaten.
