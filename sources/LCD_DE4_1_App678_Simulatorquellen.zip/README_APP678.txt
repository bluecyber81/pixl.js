LCD DE4.1 / App678 – Simulatorquellen und tatsächliche Firmwarebindung

PFS1-Engine und lfs-capacity-de399.wasm sind unverändert zur App672-Lieferung.
Das de41-Profil bindet diese Engine ausschließlich an DE4.1 / Zähler 678.
APP678_BINDING.json nennt den tatsächlichen Produktionscommit, dessen Tree,
SourceID, signierten OTA-Hash und BIN-Hash. Vollständige Firmwarequellen:
https://github.com/bluecyber81/pixl.js/tree/2437a3a4cf15afbc108ae66b28cec03f29da8602

Die zwölf Simulatorquelldateien, Identitätsdateien, Lizenzen und das
Buildskript build-capacity-de399.py entsprechen unverändert der App672-Lieferung.
Für App678 wurde kein neuer WASM-Build erzeugt oder behauptet.

DE4_1_PFS.json bindet vier frisch ausgeführte Layoutfälle des App678-ARM-ELF,
den ELF/BIN/HEX-Abgleich und 720 Produktionsinputs.
Die sechs Cross-Mount-Fälle in DE3_99_CROSS_MOUNT.json sind unveränderte,
bereits ausgeführte App672-Tests. Sie wurden nicht erneut für App678 ausgeführt.
Enginequellen, Geometrie, Speicheradapter und WASM wurden bytegleich abgeglichen.

Reproduktion mit vorhandenem passenden App678-Build:
python web/scripts/qualify-lcd-capacity.py --profile de41 --source FIRMWARE_QUELLE
  --build FINALER_BUILD --reuse-cross-report docs/validation/DE3_99_CROSS_MOUNT.json
  --output docs/validation/DE4_1_PFS.json
Benötigt vollständige Webquellen, Python mit Unicorn2 und ARM GNU nm/objcopy.

Archiv erneut erstellen, nachdem lcd-release-reference.mjs den richtigen
öffentlichen Produktionscommit und Tree enthält:
python web/scripts/package-lcd-simulator-sources.py --profile de41 --build FINALER_BUILD
Das Archiv enthält den tatsächlich geprüften BUILD_RESULT_APP678.json.
Dessen unsigned_candidate-Status beschreibt den unveränderten Qualifikationsbuild;
die signierte OTA-Identität steht separat in APP678_BINDING.json.

Keine Gerätemessung oder physische Speicherfreigabe wird behauptet.
Das Archiv enthält keine privaten Schlüssel, Nutzerdateien oder Firmware-ZIP.
