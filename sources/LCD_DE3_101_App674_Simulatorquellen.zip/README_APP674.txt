LCD DE3.101 / App674 – Simulatorquellen und tatsächliche Firmwarebindung

Die PFS1-Engine und lfs-capacity-de399.wasm sind unverändert zu App672 und App673.
Das de3101-Profil bindet diese Engine ausschließlich an DE3.101 / Zähler 674.
APP674_BINDING.json enthält den tatsächlichen Produktionscommit, dessen Tree,
SourceID, signierten OTA-Hash und BIN-Hash. Vollständige Firmwarequellen:
https://github.com/bluecyber81/pixl.js/tree/c1aa53ed902e164a391e158b6cf45ba78f7bcab6

Die zwölf Simulatorquelldateien, Identitätsdateien, Lizenzen und das
Buildskript build-capacity-de399.py entsprechen unverändert der App672-Lieferung.
Für App674 wurde kein neuer WASM-Build erzeugt oder behauptet.

DE3_101_PFS.json bindet vier frisch ausgeführte Layoutfälle des finalen
App674-ARM-ELF, den ELF/BIN/HEX-Abgleich und 720 Produktionsinputs.
Die sechs Cross-Mount-Fälle in DE3_99_CROSS_MOUNT.json sind unveränderte,
bereits ausgeführte App672-Tests. Sie wurden nicht erneut für App674 ausgeführt.
Enginequellen, Geometrie, Speicheradapter und WASM wurden bytegleich abgeglichen.

Reproduktion mit vorhandenem aktuellen App674-Build:
python web/scripts/qualify-lcd-capacity.py --profile de3101 --source FIRMWARE_QUELLE
  --build FINALER_BUILD --reuse-cross-report docs/validation/DE3_99_CROSS_MOUNT.json
  --output DE3_101_PFS.json
Benötigt vollständige Webquellen, Python mit Unicorn2 und ARM GNU nm/objcopy.

Keine Gerätemessung oder physische Speicherfreigabe wird behauptet.
Das Archiv enthält keine privaten Schlüssel, Nutzerdateien oder Firmware-ZIP.
