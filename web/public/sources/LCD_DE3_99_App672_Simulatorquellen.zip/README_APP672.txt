Allmiibo LCD DE3.99 / App672 – Simulatorquellen und Firmwarebindung

Normale signierte LCD-Anwendung; Geräteabnahme separat.
Produktionscommit: 9fb9d84b51365cf33f745896243f4cd6e934e637
SourceID: 1a60ea8e4804a958d2e0e4415a5a7a9643eca6abce788d7394e2155976da1c0d

Die sechs Speicherquellen stimmen mit der echten Firmware überein.
Das PFS1-Format bleibt erhalten; die Engine besitzt eine neue Quellidentität.
Dieses Archiv enthält Simulatorquellen, Lizenzen, Toolchain-Pins, WASM,
Produktionsinput-Hashes sowie frische ARM-Layout- und Cross-Mount-Nachweise.

Reproduktion vom entpackten Archiv aus:
python web/scripts/build-capacity-de399.py --sdk /pfad/wasi-sdk-34.0-x86_64-linux --output /neuer/nachweisordner

Nur der in SOURCE_BINDING.json festgelegte WASI SDK34 wird akzeptiert.
Keine Nutzerdateien, Firmware-OTA oder Schlüssel sind enthalten.
Der Simulator arbeitet im RAM und misst weder Funk- noch physische Flashzeiten.
