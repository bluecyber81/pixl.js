LCD DE3.98 / App671 corresponding simulator sources.
Firmware production source: https://github.com/bluecyber81/pixl.js/tree/7ab8d1343d609ecb5bec93863d60f038583f0ba0
Reproduce: python3 web/scripts/build-capacity-de398.py --sdk /path/to/wasi-sdk-34.0-x86_64-linux --output /new/evidence
The archive contains no device contents or signing key. It binds the RAM-only simulator to the signed LCD application.
This source package does not establish physical device acceptance.
