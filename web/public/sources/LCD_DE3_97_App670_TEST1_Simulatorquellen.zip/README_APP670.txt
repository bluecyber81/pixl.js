Allmiibo LCD DE3.97 / App670 TEST1 – Simulatorquellen
====================================================
Dieses Archiv enthält vollständige Simulatorquellen, Lizenzen, Compilerpins,
das Reproduktionsskript und die Referenz-WASM. Der Simulator ist an die
geprüfte LCD-Testanwendung gebunden:

Board: LCD
Version / Counter: 2.22.0-DE3.97 / 670
Öffentlicher Produktionscommit: d34ecb44fa058a149b58de2dcbffbb751c015864
SourceID: b5da931da1f22110ed60d36af7cfdfda090f5191a070acb6e8c550b8b77eddbe
Anwendungs-BIN: 363888 Byte
BIN-SHA-256: 2e0db2e1303730d1042bb88619c0f6364f2824d59e306b69fb244b6fc8cbe9b9
Speicherengine-SHA-256: a5aa9c1b7374c77a0a66f44e1287fd5e18f69a43f46797ed74b99e01de631788

DE3.97 besitzt einen eigenen de397-Snapshot. Die sechs Kern-/LittleFS-Dateien
stimmen bytegenau mit dem finalen App670-Build überein. Alle zwölf Simulator-
quellen sind einzeln gehasht. Das Manifest der 709 Firmware-Produktionseingaben
dokumentiert die SourceID; es ersetzt nicht die Firmwarequellen im Repository.
App669 und ältere Simulatorprofile und ihre Artefakte bleiben erhalten.

APP670_BINDING.json verbindet Quellen und WASM mit der endgültigen SourceID,
ARM-ELF, BIN und HEX. DE3_97_PFS.json enthält vier Linked-ARM-Layoutfälle.
DE3_97_CROSS_MOUNT.json enthält sechs neue wechselseitige Lese-/Schreibphasen
zwischen App669 und App670 mit 1131 synthetischen Dateien und 77 Ordnern,
vollständigen Daten-/raw128-Prüfungen und Remount. Verifizierende Nur-Lese-
Phasen erzeugen keine Flash-Programme/Erases und ändern den Imagehash nicht.
Die 1208-Einträge-Testkollektion belegt 238 von 512 Blöcken; die konservative
Spitze einschließlich Transaktionsreserve beträgt 279 Blöcke. Diese Zahlen
beziehen sich ausschließlich auf die synthetische Kollektion.

Die WASM wird ohne BOARD_LCD und PIXL_TEST_DIAGNOSTICS gebaut. SDK-Zeitmessung
und zusätzlicher GC-Diagnosespeicher sind nicht enthalten. Simulator-Heap
und simulierte Dateiinhalte messen weder Firmware-RAM noch reale Gerätedaten.

Reproduktion
------------
Offizielles WASI SDK 34.0 anhand des Archivhashes in SOURCE_BINDING.json prüfen
und entpacken. Im Wurzelverzeichnis dieses Quellenpakets ausführen:

python3 web/scripts/build-capacity-de397.py --sdk /path/to/wasi-sdk-34.0-x86_64-linux --output /path/to/new-evidence-directory

Das Skript prüft die gepinnten Compiler-/Linkerbytes, sämtliche zwölf Quellen,
die Engine und die exakten Ausgabe-WASM-Bytes. GPL-2.0-LICENSE und
LITTLEFS-LICENSE.md liegen beim Snapshot.

Geltungsbereich
--------------
Jedes echte Archiv und das aktuelle Zielgerät benötigen weiterhin ihre
eigenen Prüfungen. Physischer freier Speicher, Funkgeschwindigkeit,
Stromausfallverhalten und Abnahme am Gerät sind hier nicht nachgewiesen.
Die Firmware ist TEST1 und noch nicht als Normalbuild am Gerät abgenommen.
Das signierte Update ist ein separates OTA-Paket. Dieses Quellenarchiv
enthält keine Signierschlüssel, OTA-Pakete oder Release-Metadaten.
